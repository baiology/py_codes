from tkinter.ttk import Progressbar, Style
import copy
import ibm_db_dbi as db
import os
import pyodbc
import datetime
import time
import pandas as pd
import difflib
import xlsxwriter
from sqlalchemy import create_engine

from tkinter import *
from tkinter import messagebox as msg

sUserName = ''
sPassword = ''
sDB2_Server = ''
sDB2_Port  = ''
sDB2_Env = ''
sDB2_DB = ''
sTD_DB = ''
progressForm = ''
progress_var  = ''
progress_bar  = ''
lblTable  = ''
lblText = ''
d = difflib.Differ()
# engine = create_engine('teradata://t033270:Welcome3#@TDTEST/' + '?authentication=LDAP')
# result = engine.execute("select * from DMSD2V_CLM_MSTR.D_FULL_COMMENT")
# print(result.keys)
# print()

def printRuntime(seconds,finished=False):
    seconds = int(seconds)
    status = 'has been running for'
    if finished == True:
        status = 'finished in'

    if seconds < 60:
        print('The script {} {} seconds'.format(status,seconds))
        return
    elif seconds < 3600:
        minutes = seconds // 60
        seconds = seconds - 60*minutes
        print('The script {} {} minutes & {} seconds'.format(status,minutes,seconds))
        return
    else:
        hours = seconds // 3600
        minutes = (seconds - 3600*hours) // 60
        seconds = seconds - 3600*hours - 60*minutes
        print('The script {} {} hours, {} minutes & {} seconds'.format(status,hours,minutes,seconds))
        return

def readTableListFile(fn):
    newline = []
    with open(fn, "r") as myfile:
        for line in myfile:
            # sTbl = line.strip().split(",")[0].strip()
            # sKey = line.strip().split(",")[1].strip()
            # lineTemp = sTbl + "," + sKey
            newline.append(line)
        return newline

def closeExcelApp(filename):
    if os.path.exists(filename):
        try:
            f = open(filename, 'w')
            f.close()
        except IOError:
            return True
    return False

def getDateTimeStamp(msg, log):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    strMsgLog =  now + ": " + msg
    log.write(strMsgLog + "\n")

def checkandgetPK_DB2(pktd):
    with open(cwd + "\\TD_Reserved_Words.txt", "r") as fl_ResWord:
        for line in fl_ResWord:
            ResWord_TD = line.split(',')[1].rstrip()
            if ResWord_TD == pktd:
                PK_DB2 = line.split(',')[0]
                return PK_DB2
                break

def tableCompare(uname, pwd, db2server, db2port, db2env, db2db, btddb, tddbs):
    # Start task timer
    now = datetime.datetime.now()
    start = time.time()
    print("Start time: " + now.strftime("%Y-%m-%d %H:%M"))

    # get the list of reserved list from file
    # Sample 3 - a more pythonic way with efficient memory usage. Proper usage of with and file iterators.
    reserved_list_td = []
    reserved_list_db2 = []
    with open(cwd + '/TD_Reserved_Words.txt', 'r') as file:
        for line in file:
            reserved_db2 = line.strip().split(',')[0]
            reserved_td = line.strip().split(',')[1]
            reserved_list_db2.append(reserved_db2)
            reserved_list_td.append(reserved_td)
    # Start reading the table list one by one
    tbl_ctr = 1
    noPKcount = 0
    columnCountNotMatchedCtr = 0
    cnt_Matched = 0
    cnt_NotMatched = 0
    cnt_RowNotMatched = 0
    fl_Summary = open(outPath + "\\Table_Compare_Summary.txt", "w+", encoding="utf-8")
    fl_Summary.close()
    fl_OverAllLog = open(outPath + "\\Table_Compare_Log_Summary.txt", "w+", encoding="utf-8")
    getDateTimeStamp('Execution started with ' + str(tbl_count) + ' table(s) to compare', fl_OverAllLog)
    progress_step = 0
    progress = 0
    progress2 = 0
    tblNotFound_ctr = 0
    otherErrorFile = open(outPath + "\\" + "Table_Compare_Other_Error_Rpt.txt", "w+", encoding="utf-8")
    for tbl in lstTables:
        tbl = tbl.rstrip()
        withPKey = False
        if tbl.find(',') != -1:
            tbltmp = tbl.split(',')[0]
            tkey = tbl.split(',')[1]
            tbl = tbltmp
            withPKey = True
        # lblText.set('Processing table: ' + str(tbl) + str(tbl_ctr) + "/" + str(tbl_count))
        lblTable.config(text='Processing table: ' + str(tbl) + ' ('+ str(tbl_ctr) + "/" + str(tbl_count) + ')');
        progressForm.update()

        # TD Connection - Get Fields
        TD_conn = pyodbc.connect('DSN=TDTest64;UID=' + uname + ';PWD=' + pwd)
        TD_Cursor = TD_conn.cursor()
        strTDDBArr = tddbs.split(",")
        db_ctr = 0
        tblNotFound = False
        for dbTemp in strTDDBArr:
            strQueryGetFields_TD = 'select TRIM(ColumnName) from dbc.columns where databasename=\'' + dbTemp + '\' AND tablename=\'' + str(tbl.upper()) + '\' order by 1;'
            resultTD = TD_Cursor.execute(strQueryGetFields_TD)
            db_ctr += 1
            if resultTD.rowcount > 0:
                tddb = dbTemp
                break
            else:
                TD_Cursor.close
                if len(strTDDBArr) == db_ctr:
                    tblNotFound_ctr += 1
                    tblNotFound = True
                    break
        lstFlds = []
        for fld_TD in resultTD:
            strTemp = ''.join(fld_TD)
            lstFlds.append(strTemp)

        # ========================================
        # Get the primary key
        # ========================================
        # strQueryGetPK = "SELECT ColumnName FROM DBC.IndicesV WHERE TABLENAME='" + str(tbl.upper()) +  "' AND DatabaseName = " + "'" + btddb + "'" + ' AND IndexType = ' + "'P' AND ColumnPosition = 1;"
        strQueryGetPK = 'select trim(table_pk1), trim(table_pk2), trim(table_pk3), trim(table_pk4), trim(table_pk5), trim(table_pk6) from LAB_BI.TABLE_KEY where table_name=\'' + str(tbl.upper()) + '\' order by 1;'
        resultPK = TD_Cursor.execute(strQueryGetPK)
        noPrimaryKey = False
        if resultPK.rowcount != 1:
            noPrimaryKey = True
            TD_Cursor.close
            noPKcount += 1
        else:
            strPK_T = resultPK.fetchone()
            strPK = []
            for col in strPK_T:
                if col != None:
                    strPK.append(col)
            # strPK = strPK_T.ColumnName
            # ========================================
            # if len(strPK) == 1:
            key_TD = strPK[0] #','.join(strPK)
            # else:
            # Check if Primary Key is provided
            if withPKey == True:
                key_TD = tkey

            flds_TD = [x for x in lstFlds if x != key_TD]
            flds_TD.insert(0, key_TD)
            # ========================================
            # Close connection
            # ========================================
            TD_Cursor.close
            # ========================================

            # DB2 Connection - Get Fields
            DB2_conn = db.connect("DATABASE=SYSDM;HOSTNAME=" + db2server + ";PORT=" + db2port + ";PROTOCOL=TCPIP;UID=" + uname + ";PWD=" + pwd + ";", "", "")
            strQueryGetFields_DB2 = 'Select TRIM(NAME) FROM SYSIBM.SYSCOLUMNS WHERE TBCREATOR=\'' + str(db2db) + '\' AND  TBNAME=\'' + str(tbl.upper()) + '\' order by 1;'
            DB2Session = DB2_conn.cursor()
            DB2Session.execute(strQueryGetFields_DB2)
            resultDB2 = DB2Session.fetchall()
            lstFlds = []
            for fld_DB2 in resultDB2:
                strTemp = ''.join(fld_DB2)
                lstFlds.append(strTemp)
            try:
                key_DB2 = reserved_list_db2[reserved_list_td.index(key_TD)]
            except ValueError:
                key_DB2 = key_TD
            flds_DB2 = [x for x in lstFlds if x != key_DB2]
            flds_DB2.insert(0, key_DB2)
            DB2Session.close()

            x = 0
            y = 0
            flds_DB2_Temp = []
            while x < len(flds_DB2):
                y = 0
                while y < len(flds_TD):
                    if flds_DB2[x] == flds_TD[y] or flds_DB2[x] in reserved_list_db2:
                        flds_DB2_Temp.append(flds_DB2[x])
                        break
                    y += 1
                x += 1
            flds_DB2 = list(flds_DB2_Temp)

            x = 0
            flds_TD_Temp = []
            while x < len(flds_TD):
                y = 0
                while y < len(flds_DB2):
                    flds_TDx = flds_TD[x]
                    flds_DBy = flds_DB2[y]
                    if flds_TDx == flds_DBy:
                        flds_TD_Temp.append(flds_TDx)
                        break
                    elif flds_TDx in reserved_list_td:
                        flds_TD_Temp.append(reserved_list_td[reserved_list_td.index(flds_TDx)])
                        break
                    y += 1
                x += 1
            flds_TD = list(flds_TD_Temp)

            x = 0
            y = 0
            while x < len(flds_DB2):
                flds_DB2x = flds_DB2[x]
                flds_TDy = flds_TD[y]
                if flds_DB2x in reserved_list_db2:
                    fldidx = flds_DB2.index(flds_DB2x)
                    fldval_TD = reserved_list_td[reserved_list_db2.index(flds_DB2x)]
                    flds_TD.remove(fldval_TD)
                    flds_TD[fldidx:fldidx] = [fldval_TD]
                x += 1

            columnCountNotMatched = False
            if len(flds_DB2) != len(flds_TD):
                columnCountNotMatched = True
                columnCountNotMatchedCtr += 1

            strPkeys = list(strPK)
            for strPkey in strPkeys:
                try:
                    strPKey_DB2 = reserved_list_db2[reserved_list_td.index(strPkey)]
                except ValueError:
                    strPKey_DB2 = strPkey
                if strPKey_DB2 in flds_DB2:
                    flds_DB2.remove(strPKey_DB2)
                if strPkey in flds_TD:
                    flds_TD.remove(strPkey)

            strPkeys.reverse()
            for fld in strPkeys:
                try:
                    fld_DB2 = reserved_list_db2[reserved_list_td.index(fld)]
                except ValueError:
                    fld_DB2 = fld
                flds_DB2.insert(0,fld_DB2)
                flds_TD.insert(0,fld)

        if tblNotFound:
            otherErrorFile.write(str(tbl.upper()) + ' - Table not found in ' + ','.join(strTDDBArr) + '\n')
        elif noPrimaryKey:
            otherErrorFile.write(str(tbl.upper()) + ' - No Primary Key' + '\n')
        elif columnCountNotMatched:
            otherErrorFile.write(str(tbl.upper()) + ' - Columns not matched (Please check the Reserved Words and update the list' + ')\n')
        else:

            sqlQuery_DB2 = 'SELECT COUNT(*) FROM ' + db2db + '.' + str(tbl.upper()) + ' ORDER BY 1;'
            sqlQuery_TD = 'SELECT COUNT(*) FROM ' + tddb + '.' + str(tbl.upper()) + ' ORDER BY 1;'

            # get DB2 record count
            DB2Session = DB2_conn.cursor()
            DB2Session.execute(sqlQuery_DB2)
            resultDB2 = DB2Session.fetchone()
            rowcount_DB2 = int(''.join(str(resultDB2[0])))
            DB2Session.close()
            # get TD record count
            TD_Cursor = TD_conn.cursor()
            resultTD = TD_Cursor.execute(sqlQuery_TD).fetchone()
            rowcount_TD = int(''.join(str(resultTD[0])))
            TD_Cursor.close

            Process_TS = 'PROCESS_TS'
            if (Process_TS in flds_TD and Process_TS in flds_DB2) and (rowcount_DB2 > 1000000 and rowcount_TD > 1000000):
                sqlQuery_DB2 = 'SELECT ' + ','.join([j for j in flds_DB2]) + ' FROM ' + db2db + '.' + str(tbl.upper()) + ' ' + ' WHERE DAYS(CURRENT_DATE) - DAYS(' + Process_TS + ') <= 365 ORDER BY 1;'
                sqlQuery_TD = 'SELECT ' + ','.join([j for j in flds_TD]) + ' FROM ' + tddb + '.' + str(tbl.upper()) + ' ' + ' WHERE (CURRENT_DATE - CAST(' + Process_TS + ' as DATE)) <= 365 ORDER BY 1;'
            else:
                sqlQuery_DB2 = 'SELECT ' + ','.join([j for j in flds_DB2]) + ' FROM ' + db2db + '.' + str(tbl.upper()) + ' ORDER BY 1;'
                sqlQuery_TD = 'SELECT ' + ','.join([j for j in flds_TD]) + ' FROM ' + tddb + '.' + str(tbl.upper()) + ' ORDER BY 1;'

            # create the log file
            logfn = outPath + "\\" + tbl + "_log.txt"
            log = open(logfn, "w+", encoding="utf-8")
            # create the log file
            sSQLFileNm = outPath + "\\" + tbl + "_SQLQuery.txt"
            sSQLFile = open(sSQLFileNm, "w+", encoding="utf-8")
            sSQLFile.write(sqlQuery_DB2 + '\n' + sqlQuery_TD + '\n' + 'Primary Key(s) used: ' + ''.join(strPK).upper() + '\n' + 'DB2 Fields: ' + strQueryGetFields_DB2 + '\n' + 'TD  Fields: ' + strQueryGetFields_TD + '\n' + 'Get PK: ' + strQueryGetPK)
            sSQLFile.close()
            # DB2 - Get records from query
            getDateTimeStamp("Started getting result set from DB2 query.", log)
            getDateTimeStamp("Primary Key Used: " + str(key_DB2), log)
            DB2Session = DB2_conn.cursor()
            DB2Session.execute(sqlQuery_DB2)
            # resultDB2 = DB2Session.fetchall()
            start = time.time()
            df_db2 = pd.DataFrame(DB2Session.fetchall())
            # df_db2 = pd.read_sql(sqlQuery_DB2, DB2_conn)
            DB2_conn.close()
            print(str(df_db2[0].count()))
            printRuntime(time.time() - start)

            # rowcount_DB2 = len(resultDB2)
            # lstResDB2 = list(resultDB2)
            DB2Session.close()
            getDateTimeStamp("Completed acquiring result set from the DB2 query with " + str(rowcount_DB2) + " record(s).", log)

            # TD - Get records from query
            getDateTimeStamp("Started getting result set from TD query.", log)
            getDateTimeStamp("Primary Key Used: " + str(key_TD), log)
            TD_Cursor = TD_conn.cursor()
            resultTD = TD_Cursor.execute(sqlQuery_TD)
            rowcount_TD = resultTD.rowcount
            lstResTD = list(resultTD)
            TD_Cursor.close
            getDateTimeStamp("Completed acquiring result set from the TD query with " + str(rowcount_TD) + " record(s).", log)

            colcnt = len(resultTD.description) #- 1 # minus 1 for the index
            strStatus = ""
            rowctr = 0
            ctr = 0
            mismatchRowCtr = 0
            liMismatchValue = []
            progress_bar2['maximum'] = rowcount_DB2

            diff = d.compare(lstResDB2, lstResTD)
            print('\n'.join(diff))

            if mismatchRowCtr > 0:
                strPrintStatus = "Not Matched"
                strStatusToWrite = strStatus[0:len(strStatus)-1]
                cnt_NotMatched += 1
            else:
                if rowcount_DB2 == rowcount_TD:
                    strPrintStatus = "Matched"
                    cnt_Matched += 1
                else:
                    strPrintStatus = "Data matched but row count not matched. DB2: " + str(rowcount_DB2) + " TD: " + str(rowcount_TD) + " (Difference: " + str(rowcount_DB2 - rowcount_TD) + ")"
                    cnt_RowNotMatched += 1
                strStatusToWrite = strPrintStatus
            fl_Summary = open(outPath + "\\Table_Compare_Summary.txt", "a", encoding="utf-8")
            fl_Summary.write(str(tbl) + ',' + key_TD + ',' + strPrintStatus + ',' + str(mismatchRowCtr) + '\n')
            fl_Summary.close()
            xlsxPath = outPath + '/' + str(tbl.upper()) + '_Error_Report.xlsx'
            df = pd.DataFrame(liMismatchValue, columns=['Table Name', 'Column Primary Key', 'Primary Key Value', 'Column Name', 'DB2 Value', 'TD Value', 'DB2 Length', 'TD Length', 'Mismatch Reason'])
            writer = pd.ExcelWriter(xlsxPath, engine='xlsxwriter')
            df.to_excel(writer,"Report",header=True,index=False)
            writer.save()
            # file = open(outPath + "\\" + str(tbl.upper()) + "_Error_Rpt.txt", "w+", encoding="utf-8")
            # file.write(strStatusToWrite)
            getDateTimeStamp("Table compare ended.", log)
            getDateTimeStamp("Log file path: " + logfn, log)
            getDateTimeStamp("No. of unique rows mismatched: " + str(mismatchRowCtr), log)
            writer.close()
            # file.close()
            log.close()
            # print("==================================================================================================")
            # print("Table Comparison Report:")
            # print(strPrintStatus)
            # print("==================================================================================================")
            # print("No.of rows mismatched: " + str(mismatchRowCtr))
            # print("==================================================================================================")
        progress += 1
        progress_var.set(progress)
        tblprog = round((tbl_ctr / tbl_count) * 100,2)
        style.configure('text.Horizontal.TProgressbar', text='{:g} %'.format(tblprog))  # update label
        tbl_ctr += 1
    #     progressbar.step(tbl_ctr)
    #     progressbar.update()
    # progressForm.after(100, tableCompare(sUserName, sPassword, sDB2_Server, sDB2_Port, sDB2_Env, sDB2_DB, sTD_DB))
    lblTable.config(text='Table Compare: COMPLETE')
    lblTableRec.config(text='Processing record: COMPLETE')
    endN = datetime.datetime.now()
    end = time.time()
    elapsed = (end - start) / 60
    # elapsed = divmod(elapsedTmp.total_seconds(), 60)
    print("\n End time: " + endN.strftime("%Y-%m-%d %H:%M"))
    strElapsed = 'Total execution time: %.2f minute(s)' %elapsed
    getDateTimeStamp('Execution complete.', fl_OverAllLog)
    getDateTimeStamp(strElapsed, fl_OverAllLog)
    getDateTimeStamp('                        DB2 Environment: ' + str(db2env), fl_OverAllLog)
    getDateTimeStamp('                          TD Base Table: ' + str(btddb), fl_OverAllLog)
    getDateTimeStamp('                      Semantic Layer DB: ' + str(tddbs), fl_OverAllLog)
    getDateTimeStamp('                    Total no. of tables: ' + str(tbl_count), fl_OverAllLog)
    getDateTimeStamp('         Total no. of tables with no PK: ' + str(noPKcount), fl_OverAllLog)
    getDateTimeStamp(' Total no. of tables with uneven column: ' + str(columnCountNotMatchedCtr), fl_OverAllLog)
    getDateTimeStamp('          Total no. of tables not found: ' + str(tblNotFound_ctr), fl_OverAllLog)
    getDateTimeStamp('            Total no. of tables MATCHED: ' + str(cnt_Matched), fl_OverAllLog)
    getDateTimeStamp('        Total no. of tables NOT MATCHED: ' + str(cnt_NotMatched), fl_OverAllLog)
    fl_OverAllLog.close()
    otherErrorFile.close()
    lblTable.config(text='Table Comparison: COMPLETE');
    # strCompareStatus = "Table Comparison Report: " + str(strPrintStatus)
    # strMatch = "No.of rows mismatched: " + str(mismatchRowCtr)
    ans = msg.askyesno("Execution Complete!", "Completed table comparison for [" + str(tbl_ctr - 1) + "] table(s)." + '\n'
                       + 'Tables with no Primary Key:\t' + str(noPKcount) + "\n" \
                       + '                  Tables Matched:\t' + str(cnt_Matched) + "\n" \
                       + '           Tables Not Matched:\t' + str(cnt_NotMatched) + "\n" \
                       + '\n' + str(strElapsed)
                       + '\n\n' + 'Do you want to open the results folder?')
    if ans:
        os.startfile(os.path.realpath(outPath))
    sys.exit()

def objEntry(frame, textvar, v_row, v_col):
    txtEntry = Entry(frame, textvariable=textvar)
    txtEntry.grid(row=v_row, column=v_col, padx=5, pady=5)
    txtEntry.config(width=50)
    return txtEntry

def objLabel(frame, v_text, v_row):
    lblLabel = Label(frame, text=v_text)
    lblLabel.grid(row=v_row, sticky=E, padx=5)
    return lblLabel

def objButton(frame, v_text, cmd, v_row, v_col):
    btnButton = Button(frame, command=cmd, width=9)
    btnButton.config(text=v_text)
    btnButton.bind('<Return>', cmd)
    btnButton.grid(row=v_row, column=v_col, padx=10, pady=10)
    return btnButton

def getCredentials(*event):
    b1.config(text="Running")
    b1.configure(state=DISABLED)
    sUserName = txtUsername.get()
    sPassword = txtPassword.get()
    sDB2_Server = txtDB2Server.get()
    sDB2_Port = txtDB2Port.get()
    sDB2_Env = txtDB2Env.get()
    sDB2_DB = txtDB2DB.get()
    sTD_BDB = txtBTDDB.get()
    sTD_DB = txtTDDB.get()

    main.withdraw()
    progressForm.deiconify()
    # startTableCompare()
    tableCompare(sUserName, sPassword, sDB2_Server, sDB2_Port, sDB2_Env, sDB2_DB, sTD_BDB, sTD_DB)
    root.destroy()

def startTableCompare():
    tableCompare(sUserName, sPassword, sDB2_Server, sDB2_Port, sDB2_Env, sDB2_DB, sTD_DB)
    root.destroy()

def quit(*event):
    main.destroy()

#======================================================================================
# create the output directory where to dump the error report files
#======================================================================================
cwd = sys.path[0]
now = datetime.datetime.now()
strDate = now.strftime("%m%d%Y_%H%M%S")
outPath = cwd + "\\" + strDate
if not os.path.exists(outPath):
    os.makedirs(outPath)

#======================================================================================
# get the list of tables from file
#======================================================================================
lstTables = readTableListFile(cwd + '/table_list.txt')
tbl_count = len(lstTables)
#=========================================== Start the forms ===========================================
sUserName = ''
sPassword = ''
root = Tk()
main = Toplevel(root)
w = main.winfo_reqwidth()
h = main.winfo_reqheight()
ws = main.winfo_screenwidth()
hs = main.winfo_screenheight()
x = (ws/2) - (w/2)
y = (hs/2) - (h/2)
main.geometry('+%d+%d' % (x, y))
main.geometry('440x290') # Size 200, 200

main.title('Table Compare')
main.resizable(width=FALSE, height=FALSE)
# ================================
# Progress bar form
# ================================
progressForm = Toplevel()
progressForm.geometry('380x150')  # Size 200, 200
progressForm.title("Table Compare Progress")

top_frame = Frame(progressForm, width=100, height=50, pady=3)
center = Frame(progressForm, width=100, height=50, padx=3, pady=3)
btm_frame = Frame(progressForm, width=100, height=10, pady=3)
btm_frame2 = Frame(progressForm, width=100, height=10, pady=3)

top_frame.grid(row=0, sticky="ew")
center.grid(row=1, sticky="nsew")
btm_frame.grid(row=2, sticky="news")
btm_frame2.grid(row=3, sticky="news")

lblTable = Label(top_frame)
lblTable.grid(row=0, column=0)

Label(center, text="Progress: ").grid(row=1, column=0)

# lblBlank = Label(btm_frame, bg='blue')
# lblBlank.grid(row=0, column=0, sticky="ew")
# lblBlank.grid_columnconfigure(0, weight=1)
# lblBlank.config(text='                     ')
# lblBlank2 = Label(btm_frame, bg='green', )
# lblBlank2.grid(row=1, column=0, sticky="ew")
# lblBlank2.grid_columnconfigure(1, weight=1)
# lblBlank2.config(text='                     ')

lblTableRec = Label(btm_frame, width=40)
lblTableRec.grid(row=0, column=1, sticky="e")
lblTableRec.grid_columnconfigure(0, weight=1)
lblTableRec.config(text='Processing record: ')
btm_frame.grid_propagate()

style = Style(root)
# add label in the layout
style.layout('text.Horizontal.TProgressbar',
             [('Horizontal.Progressbar.trough',
               {'children': [('Horizontal.Progressbar.pbar',
                              {'side': 'left', 'sticky': 'ns'})],
                'sticky': 'nswe'}),
              ('Horizontal.Progressbar.label', {'sticky': ''})])
# set initial text
style.configure('text.Horizontal.TProgressbar', text='0 %')

progress_var = DoubleVar()
progress_bar = Progressbar(center, style='text.Horizontal.TProgressbar', orient="horizontal", length=300, variable=progress_var, maximum=tbl_count)
progress_bar.grid(row=1, column=1)  # .pack(fill=tk.X, expand=1, side=tk.BOTTOM)

progress_var2 = DoubleVar()
progress_bar2 = Progressbar(btm_frame2, orient="horizontal", length=150, variable=progress_var2)
progress_bar2.grid(row=0, column=0, sticky="ew")  # .pack(fill=tk.X, expand=1, side=tk.BOTTOM)

progressForm.pack_slaves()

root.withdraw()
progressForm.withdraw()
# progressForm.withdraw()

lbltxtFrame = Frame(main, width=100, height=120)
lbltxtFrame.grid(row=0, columnspan=1, sticky='news', padx=5, pady=5)
lbltxtFrame.columnconfigure(0, weight=1)
lbltxtFrame.rowconfigure(0, weight=1)

lblText = StringVar()
lblTextRec = StringVar()
txtDB2Server_e = StringVar()
txtDB2Port_e = StringVar()
txtDB2Env_e = StringVar()
txtDB2DB_e = StringVar()
txtBTDDB_e = StringVar()
txtTDDB_e = StringVar()
txtUsername_e = StringVar()
txtPassword_e = StringVar()

lblDB2Server = objLabel(lbltxtFrame, "DB2 Server", 0)   #Label(lbltxtFrame, text="DB2 Server:")
lblDB2Port = objLabel(lbltxtFrame, "DB2 Port", 1)
lblDB2Env = objLabel(lbltxtFrame, "DB2 Environment", 2)
lblDB2DB = objLabel(lbltxtFrame, "DB2 Database", 3)
lblBTDDB = objLabel(lbltxtFrame, "TD Base Table", 4)
lblTDDB = objLabel(lbltxtFrame, "Semantic Layer DB", 5)
lblUsername = objLabel(lbltxtFrame, "Username", 6)
lblPassword = objLabel(lbltxtFrame, "Password", 7)

txtDB2Server = objEntry(lbltxtFrame, txtDB2Server_e, 0, 1)
txtDB2Port = objEntry(lbltxtFrame, txtDB2Port_e, 1, 1)
txtDB2Env = objEntry(lbltxtFrame, txtDB2Env_e, 2, 1)
txtDB2DB = objEntry(lbltxtFrame, txtDB2DB_e, 3, 1)
txtBTDDB = objEntry(lbltxtFrame, txtBTDDB_e, 4, 1)
txtTDDB = objEntry(lbltxtFrame, txtTDDB_e, 5, 1)
txtUsername = objEntry(lbltxtFrame, txtUsername_e, 6, 1)
txtPassword = objEntry(lbltxtFrame, txtPassword_e, 7, 1)
txtPassword.config(show='*')
txtPassword.bind('<Return>', getCredentials)

txtDB2Server_e.set('HODWDBTST01')
txtDB2Port_e.set('50002')
txtDB2Env_e.set('SYSDM')
txtDB2DB_e.set('AMDBTBL')
txtBTDDB_e.set('DMSD5T_BSE')
txtTDDB_e.set('DMSD5V_CLM_121,DMSD5V_POL_121')

sUname = os.getenv('username')
txtUsername.insert(INSERT, sUname)
txtPassword.focus_set()

btnFrame = Frame(main, width=100, height=100)
btnFrame.grid(row=1, columnspan=1, sticky='news', padx=5)
btnFrame.columnconfigure(1, weight=1)
btnFrame.rowconfigure(1, weight=1)
b1 = objButton(btnFrame, "Start", getCredentials, 1,1)
# b1 = Button(btnFrame, command=getCredentials, width=9)
# b1.config(text="Start")
# b1.bind('<Return>', getCredentials)
# b1.grid(row=1, column=0, padx=10, pady=10)


# frame = Frame(main, height="250", width="120", bg="green").pack
# b1 = Button(main, text="Start", command=getCredentials, width=9)
# b1.bind('<Return>', getCredentials)
# b1.grid(row=3, column=0, padx=10, pady=10)
# b1.place(relx=.5, rely=.5, anchor="center")

# progress_var = DoubleVar()  # here you have ints but when calc. %'s usually floats
# progressbar = Progressbar(progressForm, variable=progress_var, maximum=tbl_count)
# progressbar.pack(fill=X, expand=1)
#
# progressbar.after(1, getCredentials())
root.mainloop()
