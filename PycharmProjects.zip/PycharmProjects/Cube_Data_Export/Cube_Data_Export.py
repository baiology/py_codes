from mstrio import microstrategy
import os
import sys
import time
import datetime
import pandas as pd
import numpy as np

'Functions'
def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

def createFolder(cwd):
    now = datetime.datetime.now()
    strDate = now.strftime("%m%d%Y_%H%M%S")
    outPath = cwd + "\\" + strDate
    if not os.path.exists(outPath):
        os.makedirs(outPath)
    return outPath


def replaceChars(mainString, toReplace, newString):
    # Iterate over the strings to be replaced
    for elem in toReplace:
        # Check if string is in the main string
        if elem in mainString:
            # Replace the string
            mainString = mainString.replace(elem, newString)
    return mainString

baseurl = "http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api"
LEFT_project_name = "Claims Management Reporting"
LEFT_project_abbrv = "CLM"
RIGHT_project_name = "Claims Management Reporting_PRV"
RIGHT_project_abbrv = "CLM_PRV"
username = 't033270'
password = 'test'

time_format = '%m/%d/%y %H:%M:%S'
start_time = str(datetime.datetime.now().strftime(time_format))
print('Start time: ' + start_time)
oall_start = time.time()
'Create directory by date if not exist'
cwd = sys.path[0]
outPath = createFolder(cwd)
'Create MSTR connection'
conn_LEFT = microstrategy.Connection(base_url=baseurl, username=username, password=password, project_name=LEFT_project_name, login_mode=1)
conn_RIGHT = microstrategy.Connection(base_url=baseurl, username=username, password=password, project_name=RIGHT_project_name, login_mode=1)
cube_list_file = cwd + "\\cube_list.txt"
ctr = 0
# cube_list = [line.rstrip('\n').rstrip('\r') for line in open(cube_list_file)]
# with open(cube_list, 'r') as lstCube:
with open(cube_list_file) as f: # Open file on read mode
    cube_list = f.read().splitlines() # Create a list containing all lines
for cube in cube_list:
    currCubeName_orig = cube.split(',')[0]
    currCubeName = replaceChars(cube.split(',')[0],' /\\<>?|*"', '_').rstrip()
    currCubeID_LEFT = cube.split(',')[1].rstrip()
    currCubeID_RIGHT = cube.split(',')[2].rstrip()
    conn_LEFT.connect()
    print('Exporting cube: ' + str(currCubeName_orig) + ' (' + LEFT_project_name + ')')
    cube_LEFT = conn_LEFT.get_cube(cube_id=currCubeID_LEFT)
    cube_LEFT.columns = cube_LEFT.columns.str.replace(' ', '_')
    cube_LEFT_column_list = cube_LEFT.columns.tolist()
    xlsx_Output = outPath + "\\" + currCubeName + '_' + LEFT_project_abbrv + '.xlsx'
    xlsxFile = os.path.normpath(xlsx_Output)
    writer = pd.ExcelWriter(xlsxFile, engine='xlsxwriter')
    cube_LEFT.to_excel(writer, LEFT_project_abbrv, index=False)
    writer.save()
    conn_LEFT.close()

    # RIGHT Data
    conn_RIGHT.connect()
    print('Exporting cube: ' + str(currCubeName_orig) + ' (' + RIGHT_project_name + ')')
    cube_RIGHT = conn_RIGHT.get_cube(cube_id=currCubeID_RIGHT)
    cube_RIGHT.columns = cube_RIGHT.columns.str.replace(' ', '_')
    cube_RIGHT_column_list = cube_RIGHT.columns.tolist()
    conn_RIGHT.close()

    rowCount_LEFT = cube_RIGHT.shape[0]
    rowCount_RIGHT = cube_LEFT.shape[0]
    xlsx_Output = outPath + "\\" + currCubeName + '_' + RIGHT_project_abbrv + '.xlsx'
    xlsxFile = os.path.normpath(xlsx_Output)
    writer = pd.ExcelWriter(xlsxFile, engine='xlsxwriter')
    cube_RIGHT.to_excel(writer, RIGHT_project_abbrv, index=False)
    writer.save()
    print('\tExport Complete!')
    # logWriter(currCubeName_orig + ',' + str(df.shape[0]) + '\n', fl_Log)
    ctr += 1

print('Cube export completed for ' + str(ctr) + ' cube(s).')
print('End time: ' + time.strftime("%H:%M:%S"))
print('Elapsed time: ' + printRuntime(time.time() - oall_start))
sys.exit()