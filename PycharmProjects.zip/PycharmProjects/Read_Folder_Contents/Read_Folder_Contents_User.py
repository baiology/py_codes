from collections import OrderedDict
import requests
import json
import pandas as pd

# Variable assignments
username = 't033270'
password = 'test'
# ------------------------------ change folder if needed -----------------------------------------#
MSTR_Target_Folder_GUID = '08BBB3A54F5F686434DFBBBC9C2C29CA' #'08BBB3A54F5F686434DFBBBC9C2C29CA' #'Policy Management Reporting\Public Objects\Reports\Pilot'
Project_GUID = 'AF9F62054258210C513AD4A7BC50F277'
# ------------------------------Need to change the user group text-----------------------------------------#
user_names = ['t033270']
# ------------------------------Need to change the subject text-----------------------------------------#
subject = 'Notification: Report Found in Pilot Folder (Policy Management Reporting\Public Objects\Reports\Pilot)'
# ------------------------------Connection details-----------------------------------------#
url = 'http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api' # wcmsenwqa01, homsenwprd01
response = requests.post(url + '/auth/login', data={'username': username, 'password': password, 'loginMode': 1})
authToken = response.headers['X-MSTR-AuthToken']
cookies = dict(response.cookies)
folder_response = requests.get(url + '/folders/' + str(MSTR_Target_Folder_GUID),
                          headers={'X-MSTR-AuthToken': authToken, 'X-MSTR-ProjectID': Project_GUID},
                          params={'id': MSTR_Target_Folder_GUID},
                          cookies=cookies)
folder_contents = json.loads(folder_response.text)
if len(folder_contents) != 0:
    items_list = []
    if isinstance(folder_contents, list):
        for items in folder_contents:
            try:
                item_desc = items['description']
            except KeyError:
                item_desc = ''
            items_str = items['id'] + ',' + items['name'] + ',' + item_desc
            items_list.append(items_str.split(','))
        df = pd.DataFrame(items_list, columns=['GUID', 'Name', 'Description'])
        pd.set_option('display.max_colwidth', -1)
        html_table_report = df.to_html(index=False) #(buf=str_io, classes='table table-striped', index=False)
        # User details
        user_name_list = []
        for user_name in user_names:
            user_name_response = requests.get(url + '/users',
                                              headers={'X-MSTR-AuthToken': authToken},
                                              params={'abbreviationBegins': user_name,
                                                      'limit': -1},
                                              cookies=cookies)
            user_name_json = json.loads(user_name_response.text)[0]
            user_name_id = user_name_json['id']
            user_id_response = requests.get(url + '/users/' + user_name_id,
                                              headers={'X-MSTR-AuthToken': authToken},
                                              params={'id': user_name_id},
                                              cookies=cookies)

            user_id_json = json.loads(user_id_response.text)
            user_fullname = user_id_json['fullName']
            user_enabled = user_id_json['enabled']
            user_name_final = str(user_fullname) + '|' + str(user_name_id) + '|' + str(user_enabled)
            user_name_list.append(user_name_final.split('|'))
        df = pd.DataFrame(user_name_list, columns=['name', 'id', 'enabled'])
        enabled_user_df = df.loc[df['enabled'] == 'True']
        # user_ID_list = list(OrderedDict.fromkeys(enabled_user_df['id'].values.tolist()))
        # user_Name_list = list(OrderedDict.fromkeys(enabled_user_df['name'].values.tolist()))
        head = {"X-MSTR-AuthToken": authToken}
        for i in range(len(enabled_user_df)):
        # for index, user_ID in enumerate(user_ID_list):
            # ------------------------------Need to change the html text-----------------------------------------#
            # Email format
            html = """
            <html>
            <head>
            <style> 
              body {{font-family: Arial; font-size: 12px; }}
              table, th, td {{border: 1px solid black; border-collapse: collapse; }}
              th, td {{font-family: Arial; font-size: 12px; padding: 4px; }}
            </style>
            </head>
            <body><p>Hi {}, </p>
            {}
            <p>Regards,</p>
            <p>MSTR Admin</p>
            </body></html>
            """
            user_ID = enabled_user_df.loc[i, "id"]
            uname_temp = enabled_user_df.loc[i, "name"] # user_Name_list[index].strip()
            if ',' in uname_temp:
                uname = uname_temp.split(',')[1].strip()
            elif ' ' in uname_temp:
                uname = uname_temp.rsplit(' ', 1)[0].strip()
            else:
                uname = uname_temp
            html = html.format(uname, html_table_report)
            data = {"notificationType": "1", "userIds": [user_ID], "subject": subject, "content": html, "isHTML": True,
                    "extraProperties": {}}
            send_email = requests.post(url + '/emails', json=data, headers=head, cookies=cookies)
        print(send_email)