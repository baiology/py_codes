import xlsxwriter


wfolder = '//hofile02/microstrategy/Teradata/Misc/Python/Table_compare/D5_Dimension/03282019_231944_LargeTables_1/'
fExcel = wfolder + 'Table_Compare_Mismatch_Summary.xlsx'
wb = xlsxwriter.Workbook(fExcel)
ws = wb.add_worksheet('Mismatch')
with open(wfolder + 'Table_Compare_Summary.txt', 'r') as file:
    irow = 1
    ws.write(0, 0, 'Table')
    ws.write(0, 1, 'Primary Key')
    ws.write(0, 2, 'Match Status')
    ws.write(0, 3, '# of Unique Rows Mismatched')
    ws.write(0, 4, 'Error Report File Location')
    for line in file:
        line_tmp = line.split(',')
        if line_tmp[2] == 'Not Matched':
            for col in range(len(line_tmp)):
                if col == (len(line_tmp) - 1):
                    ws.write(irow, col, line_tmp[col])
                    ws.write_url(irow, col + 1, wfolder + line_tmp[0] + '_Error_Report.xlsx', string='link')

                else:
                    ws.write(irow,col,line_tmp[col])
            irow += 1
file.close()
wb.close()