# -*- coding: utf-8 -*-
import io
import json
import pyodbc
import pandas as pd
import requests
from collections import OrderedDict

#############################################################################
# Parameters
#############################################################################

TBLLIST = ['F_ADJ_SURVEY', 'F_APP_SURVEY', 'F_GLASS_SURVEY', 'F_CQAP_SURVEY', 'F_SCS_SURVEY', 'F_REL_SURVEY']
database = 'DMSP2V_POL_MSTR'
# Variable
username = 't033270'
password = 'test'
# ------------------------------Need to change the user group text-----------------------------------------#
usergroup_names = ['Test1', 'Test2']
# ------------------------------Need to change the subject text-----------------------------------------#
subject = 'NPS Fact Table Validation - Teradata'

def FACTANALYSIS(table):
    conn_TD = pyodbc.connect('DSN=TDPROD64;Trusted_Connection=yes;')
    strQuery_TD = 'select * from ' + database.upper() + '.' + table + " where END_DT='9999-12-31'"
    df = pd.read_sql(strQuery_TD, conn_TD)
    print(table.upper() + ' Record Count: ' + str(df.shape[0]))

    field_list = []
    result = []
    for col in df:
        df_temp = df.loc[df[col] == 0]
        if df_temp.shape[0] > 0:
            field_list.append(col)
    result.append(table.strip())
    result.append(','.join(field_list))
    return result
    # print("DMSP2V." + table.lstrip() + " -- ", field_list)

pd.set_option('display.max_colwidth', -1) # Turn off the auto-truncate of 50 characters
res_list = []
for table in TBLLIST:
    KEYS = []
    L = []
    res_list.append(FACTANALYSIS(table))

if len(res_list) != 0:
    df_fact = pd.DataFrame(res_list, columns=['Table', 'Columns'])
    str_io = io.StringIO()
    report_str = df_fact.to_html(buf=str_io, classes='table table-striped', index=False)
    html_str = str_io.getvalue()

    # Connect
    url = 'http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api'
    response = requests.post(url + '/auth/login', data={'username': 't17655', 'password': 't17655', 'loginMode': 1})
    authToken = response.headers['X-MSTR-AuthToken']
    cookies = dict(response.cookies)

    # User Group details
    df = pd.DataFrame()
    for usergroup_name in usergroup_names:
        usergroup_response = requests.get(url + '/usergroups',
                                          headers={'X-MSTR-AuthToken': authToken},
                                           params={'nameBegins': usergroup_name,
                                                 'limit': -1},
                                          cookies=cookies)

        usergroup_json = json.loads(usergroup_response.text)[0]
        usergroup_id = usergroup_json['id']

        # User Group Members details
        usergroup_members_response = requests.get(url + '/usergroups/' + usergroup_id + '/members',
                                          headers={'X-MSTR-AuthToken': authToken},
                                           params={'id': usergroup_id,
                                                 'includeAccess': False},
                                          cookies=cookies)

        usergroup_members_response_json = json.loads(usergroup_members_response.text)
        df = df.append(usergroup_members_response_json)

    enabled_user_df = df.loc[df['enabled'] == True]
    # user_ID_list = enabled_user_df['id'].values.tolist()
    # user_Name_list = enabled_user_df['name'].values.tolist()
    user_ID_list = list(OrderedDict.fromkeys(enabled_user_df['id'].values.tolist()))
    user_Name_list = list(OrderedDict.fromkeys(enabled_user_df['name'].values.tolist()))

    head = {"X-MSTR-AuthToken": authToken}
    for index, user_ID in enumerate(user_ID_list):
        # Email
        # ------------------------------Need to change the html text-----------------------------------------#
        html = """
            <html>
            <head>
            <style> 
              body {{font-family: Arial; font-size: 15px; }}
              table, th, td {{border: 1px solid black; border-collapse: collapse; }}
              th, td {{font-family: Arial; font-size: 15px; padding: 5px; }}
            </style>
            </head>
            <body>
            <p>Hi {}, </p>
            <p></p>
            <P>Refer below for the list of tables</P>
    
            <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
            <HTML><HEAD><TITLE></TITLE>
            <META content="text/html; charset=unicode" http-equiv=Content-Type>
            <META name=GENERATOR content="MSHTML 8.00.6001.19019"></HEAD>
            <BODY>
            <P>{}</P>
            </BODY></HTML>            
            <p>Regards,</p>
            <p>MSTR Admin</p>
            <p>microstrategy@amica.com</p>
            </body></html>
            """
        uname_temp = user_Name_list[index].strip()
        if ',' in uname_temp:
            uname = uname_temp.split(',')[1].strip()
        elif ' ' in uname_temp:
            uname = uname_temp.rsplit(' ', 1)[0].strip()
        else:
            uname = uname_temp
        html = html.format(uname, html_str)
        data = {"notificationType": "1", "userIds": [user_ID], "subject": subject, "content": html, "isHTML": True, "extraProperties": {}}
        send_email = requests.post(url + '/emails', json=data, headers=head, cookies=cookies)
    response = requests.post(url=url + '/auth/logout', headers=head, cookies=cookies)
