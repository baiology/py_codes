from webdriver_manager.firefox import GeckoDriverManager
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.support.ui import WebDriverWait as wait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Firefox(executable_path=GeckoDriverManager().install())
driver.get('http://intranet.amica.com/Claims/claimsreporting/Documents/TV_Image.html')
wait(driver, 2).until(EC.alert_is_present())
alert = driver.switch_to.alert
alert.send_keys('t033270')
alert.send_keys(Keys.TAB)
alert.send_keys('Welcome8*')
alert.accept()
driver.close()