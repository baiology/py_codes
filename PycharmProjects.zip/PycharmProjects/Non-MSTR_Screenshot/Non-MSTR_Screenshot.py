import contextlib
import os
import sys
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.expected_conditions import staleness_of
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait, TimeoutException
from webdriver_manager.microsoft import IEDriverManager
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from selenium  import webdriver
from configparser import ConfigParser
from PIL import Image
from selenium.webdriver.common.keys import Keys

# from Screenshot import Screenshot_Clipping

class MicroStrategyReportCapture:
    CONNECTION_NOT_PRIVATE = '//*[@id="main-message"]/h1'
    ADVANCED_BUTTON = '//*[@id="details-button"]'
    PROCEED_LINK = '//*[@id="proceed-link"]'
    TOOLBAR_ELEMENT_XPATH = '//[@id="rootView"]div[@class="mstrmojo-RootView-toolbar"]'

    def __init__(self, settings):
        # Variables
        settings = settings
        # Read and Get config values
        config = ConfigParser()
        config.read(settings)
        config.sections()
        # Get browser and load driver
        for r in config.sections():
            report_section = config[r]
            image = str(report_section['imgname'])
            url = str(report_section['url'])
            image_locations = [e.strip() for e in str(report_section['image_locations']).split(',')]
            self.open_and_capture_job(url, r,  image, image_locations)

    @contextlib.contextmanager
    def wait_for_page_load(self, timeout=10):
        self.log.debug("Waiting for page to load at {}.".format(self.driver.current_url))
        old_page = self.find_element_by_tag_name('html')
        yield
        WebDriverWait(self, timeout).until(staleness_of(old_page))

    def wait_for_ec(self, expected_condition, driver, wait_in_secs):
        try:
            return WebDriverWait(driver, wait_in_secs).until(expected_condition)
        except TimeoutException:
            return 1

    def fullpage_screenshot(self, driver, file):
        print("Starting chrome full page screenshot workaround ...")
        total_width = driver.execute_script("return document.body.offsetWidth")
        total_height = driver.execute_script("return document.body.parentNode.scrollHeight")
        viewport_width = driver.execute_script("return document.body.clientWidth")
        viewport_height = driver.execute_script("return window.innerHeight")
        print(
            "Total: ({0}, {1}), Viewport: ({2},{3})".format(total_width, total_height, viewport_width, viewport_height))
        rectangles = []

        i = 0
        while i < total_height:
            ii = 0
            top_height = i + viewport_height

            if top_height > total_height:
                top_height = total_height

            while ii < total_width:
                top_width = ii + viewport_width

                if top_width > total_width:
                    top_width = total_width

                print("Appending rectangle ({0},{1},{2},{3})".format(ii, i, top_width, top_height))
                rectangles.append((ii, i, top_width, top_height))

                ii = ii + viewport_width

            i = i + viewport_height

        stitched_image = Image.new('RGB', (total_width, total_height))
        previous = None
        part = 0

        for rectangle in rectangles:
            if not previous is None:
                driver.execute_script("window.scrollTo({0}, {1})".format(rectangle[0], rectangle[1]))
                print("Scrolled To ({0},{1})".format(rectangle[0], rectangle[1]))
                time.sleep(0.2)

            file_name = "part_{0}.png".format(part)
            print("Capturing {0} ...".format(file_name))

            driver.get_screenshot_as_file(file_name)
            screenshot = Image.open(file_name)

            if rectangle[1] + viewport_height > total_height:
                offset = (rectangle[0], total_height - viewport_height)
            else:
                offset = (rectangle[0], rectangle[1])

            print("Adding to stitched image with offset ({0}, {1})".format(offset[0], offset[1]))
            stitched_image.paste(screenshot, offset)

            del screenshot
            os.remove(file_name)
            part = part + 1
            previous = rectangle

        stitched_image.save(file)
        print("Finishing chrome full page screenshot workaround...")
        return True

    def open_and_capture_job(self, report_url, report_section, image_name, image_locations):
        options = webdriver.ChromeOptions()
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        options.add_argument("--headless")
        if report_section == 'TV Image':
            options.add_argument("window-size=2048,1200")  # 2048,1200 # 1920,1080
        else:
            options.add_argument("window-size=1920,900")  # 2048,1200 # 1920,1080
        options.add_argument('--ignore-ssl-errors=yes')
        options.add_argument('--ignore-certificate-errors')
        # options.add_argument("--start-fullscreen") # only applies to non-headless chrome
        # options.add_argument("--start-maximized")
        # driver = webdriver.Firefox(executable_path=GeckoDriverManager().install())
        # driver = webdriver.Ie(IEDriverManager().install())
        driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
        # driver.set_window_size(1920, 900)
        # ob = Screenshot_Clipping.Screenshot()
        driver.get(report_url)
        time.sleep(5)
        # self.wait_for_page_load(timeout=10) # timeout for loading the page
        # time.sleep(10) # timeout to wait after loading the page

        for l in image_locations:
            output_file = l + "\\" + image_name
            self.fullpage_screenshot(driver, output_file)
            # driver.get_screenshot_as_file(output_file)
            # ob.full_Screenshot(driver, l, image_name)
        driver.close()

if __name__ == '__main__':
    # Get Current directory
    cwd = sys.path[0]  # Get current working directory
    reporter = MicroStrategyReportCapture(cwd + '/settings.ini')