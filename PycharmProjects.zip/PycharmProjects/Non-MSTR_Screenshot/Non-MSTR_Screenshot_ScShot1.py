import contextlib
import subprocess
import sys
import time
import ctypes

from selenium.webdriver.common.by import By
from selenium.webdriver.support.expected_conditions import staleness_of
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait, TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
from selenium  import webdriver
from configparser import ConfigParser

class MicroStrategyReportCapture:
    CONNECTION_NOT_PRIVATE = '//*[@id="main-message"]/h1'
    ADVANCED_BUTTON = '//*[@id="details-button"]'
    PROCEED_LINK = '//*[@id="proceed-link"]'
    TOOLBAR_ELEMENT_XPATH = '//[@id="rootView"]div[@class="mstrmojo-RootView-toolbar"]'

    def __init__(self, settings):
        # Variables
        settings = settings
        # Read and Get config values
        config = ConfigParser()
        config.read(settings)
        config.sections()
        # Get browser and load driver
        for r in config.sections():
            report = config[r]
            image = str(report['imgname'])
            url = str(report['url'])
            image_locations = [e.strip() for e in str(report['image_locations']).split(',')]
            self.open_and_capture_job(url, image, image_locations)

    @contextlib.contextmanager
    def wait_for_page_load(self, timeout=10):
        self.log.debug("Waiting for page to load at {}.".format(self.driver.current_url))
        old_page = self.find_element_by_tag_name('html')
        yield
        WebDriverWait(self, timeout).until(staleness_of(old_page))

    def wait_for_ec(self, expected_condition, driver, wait_in_secs):
        try:
            return WebDriverWait(driver, wait_in_secs).until(expected_condition)
        except TimeoutException:
            return 1

    def open_and_capture_job(self, report_url, image_name, image_locations):
        options = webdriver.ChromeOptions()
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        options.add_argument("--headless")
        options.add_argument('--ignore-ssl-errors=yes')
        options.add_argument('--ignore-certificate-errors')
        options.add_argument("window-size=2048,1200")
        driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
        driver.get(report_url)
        self.wait_for_page_load(timeout=10) # timeout for loading the page
        time.sleep(10) # timeout to wait after loading the page

        for l in image_locations:
            output_file = l + "\\" + image_name
            driver.get_screenshot_as_file(output_file)
        driver.close()

if __name__ == '__main__':
    # Get Current directory
    cwd = sys.path[0]  # Get current working directory
    reporter = MicroStrategyReportCapture(cwd + '/settings.ini')