import datetime
import time
import re
import subprocess
import xml.etree.ElementTree as ET
import lxml.etree
import os
import sys
import pyodbc
import pandas as pd
from fpdf import FPDF

def wait_for_file_in_folder(max_wait_in_secs, file_path):
    time_counter = 0
    while not os.listdir(file_path):
        time.sleep(1)
        time_counter += 1
        if time_counter > max_wait_in_secs:
            break
    time.sleep(1)

def check_and_create_file(max_wait_in_secs, file_path):
    time_counter = 0
    exists = True
    while not os.path.exists(file_path):
        time.sleep(1)
        time_counter += 1
        if time_counter > max_wait_in_secs:
            exists = False
            break
    if exists:
        os.remove(file_path)
        time.sleep(1)
    with open(file_path, 'w+') as file: pass
    return 0

def check_for_file_only(max_wait_in_secs, file_path):
    time_counter = 0
    while not os.path.exists(file_path):
        time.sleep(1)
        time_counter += 1
        if time_counter > max_wait_in_secs:
            return False
            break
    return True

def remExtraSpace(input_string):
    output_string = []
    space_flag = False  # Flag to check if spaces have occured
    for index in range(len(input_string)):
        if input_string[index] != ' ':
            if space_flag == True:
                if (input_string[index] == '.'
                    or input_string[index] == '?'
                    or input_string[index] == ','):
                    pass
                else:
                    output_string.append(' ')
                space_flag = False
            output_string.append(input_string[index])
        elif input_string[index - 1] != ' ':
            space_flag = True
    return ''.join(output_string)

def createFolder(cwd, static_foldername):
    outPath = cwd + "\\" + static_foldername
    if not os.path.exists(outPath):
        os.makedirs(outPath)
    return outPath

def parse_xml(xml_file, list_sub=False):
    global cols
    cols = []
    tree = lxml.etree.parse(xml_file)
    root = tree.getroot()
    if list_sub == False:
        rows = root.xpath("//CommandManagerResults/ListDependents/Row")
        row_header = root.xpath("//CommandManagerResults/ListDependents/Row")
    else:
        rows = root.xpath("//CommandManagerResults/ListSubscriptions/Row")
        row_header = root.xpath("//CommandManagerResults/ListSubscriptions/Row")
    for header in row_header[0]:
        if not len(header):
            cols.append(header.tag)
        else:
            cols.append('Not Used')
    row_value_final = []
    for row in rows:
        row_value = []
        for child in row:
            row_value.append(child.text)
        row_value_final.append(row_value)
    return row_value_final

# Main Program
MSTR_Server = 'homseniprd01'
cmd_user = 'administrator'
cmd_pwd = 'micro'

keepchars = (' ', '.', '_')
cwd = sys.path[0]  # Get current working directory

# Create excel for list of Security Roles and Privileges
# Create Command Manager script to create the subscription
CMD_Cube_Dep_Reports_File = os.path.normpath(cwd + '/CMD_Cube_Dep_Reports_File.scp')
CMD_log_Cube_Dep_Reports_File = os.path.normpath(cwd + '/CMD_Cube_Dep_Reports_File.log')
CMD_xml_Cube_Dep_Reports_File = os.path.normpath(cwd + '/CMD_Cube_Dep_Reports_File.xml')
CMD_Subscription_List_File = os.path.normpath(cwd + '/CMD_Subscription_List_File.scp')
CMD_log_Subscription_List_File = os.path.normpath(cwd + '/CMD_Subscription_List_File.log')
CMD_xml_Subscription_List_File = os.path.normpath(cwd + '/CMD_Subscription_List_File.xml')
Project_Name = 'Claims Management Reporting'
Cube_Name = 'Overall Claims Report Cube'
Cube_Folder = '\Public Objects\Cubes'
check_and_create_file(2, CMD_Cube_Dep_Reports_File)
check_and_create_file(2, CMD_log_Cube_Dep_Reports_File)
check_and_create_file(2, CMD_xml_Cube_Dep_Reports_File)
check_and_create_file(2, CMD_Subscription_List_File)
check_and_create_file(2, CMD_log_Subscription_List_File)
check_and_create_file(2, CMD_xml_Subscription_List_File)
# Create and run command amanager script for list cube dependent reports
with open(CMD_Cube_Dep_Reports_File, 'w+') as cube_dep_reports_file:
    cube_dep_reports_file.write('CONNECT SERVER "' + MSTR_Server + '" USER "' + cmd_user + '" PASSWORD "' + cmd_pwd + '";\n')
    cube_dep_reports_file.write('LIST ALL DEPENDENTS FOR REPORT "' + Cube_Name + '" IN FOLDER "' + Cube_Folder + '" IN PROJECT "' + Project_Name + '";\n')
    cube_dep_reports_file.write('DISCONNECT SERVER;')
time.sleep(1)
subprocess.check_output(['cmdmgr','-connlessMSTR', '-f', CMD_Cube_Dep_Reports_File, '-or', CMD_log_Cube_Dep_Reports_File, '-xml', CMD_xml_Cube_Dep_Reports_File])
check_for_file_only(3, CMD_xml_Cube_Dep_Reports_File)
list_cube_dep = parse_xml(CMD_xml_Cube_Dep_Reports_File, False)
df_cube_dep_temp = pd.DataFrame(list_cube_dep, columns=cols)
df_cube_dep = df_cube_dep_temp[['Name', 'Id', 'ObjectType']]
df_cube_dep = df_cube_dep[df_cube_dep['ObjectType'] == 'Grid Report']
# Create and run command manager for list subscription
with open(CMD_Subscription_List_File, 'w+') as list_subscription_file:
    list_subscription_file.write('CONNECT SERVER "' + MSTR_Server + '" USER "' + cmd_user + '" PASSWORD "' + cmd_pwd + '";\n')
    for index, row in df_cube_dep.iterrows():
        list_subscription_file.write('LIST SUBSCRIPTIONS FOR CONTENT GUID ' + row['Id'] + ' FOR PROJECT "' + Project_Name + '";\n')
    list_subscription_file.write('DISCONNECT SERVER;')
time.sleep(1)
subprocess.check_output(['cmdmgr','-connlessMSTR', '-f', CMD_Subscription_List_File, '-or', CMD_log_Subscription_List_File, '-xml', CMD_xml_Subscription_List_File])
check_for_file_only(3, CMD_xml_Subscription_List_File)
list_subscription = parse_xml(CMD_xml_Subscription_List_File, True)
df_list_subscription = pd.DataFrame(list_subscription, columns=cols)
df_list_subscription.to_excel(cwd + '/Cube_Dependent_Reports_Subscription.xlsx', index=False)
# new_out_file_list_sec_role = parse_xml(CMD_xml_Sec_Role_filepath, is_sec_role=True)
# sec_priv_list_all_by_group.append(new_out_file_list_sec_priv)
# master_sec_role_list.append(new_out_file_list_sec_role)
# master_sec_role_list = sum(master_sec_role_list, [])
# master_sec_priv_list = sum(sec_priv_list_all_by_group, [])
# df_sec_role = pd.DataFrame(master_sec_role_list, columns=cols_sec_role)
# df_sec_priv = pd.DataFrame(master_sec_priv_list, columns=cols_sec_priv)
# df_sec_role.to_excel(cwd + '/Step_2.xlsx', index=None, header=True)  # Don't forget to add '.xlsx' at the end of the path
# df_sec_priv.to_excel(cwd + '/Step_3.xlsx', index=None, header=True)  # Don't forget to add '.xlsx' at the end of the path
