import sys
import pyodbc
import pandas as pd
import time
import datetime as dt
import numpy as np
import teradata

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg
# ======================================== VARIABLES ========================================
strQuery_SQLServer = """SELECT [YEAR_ID],[DAY_ID] FROM [EntManager].[dbo].[DT_DAY] where YEAR_ID >= '2018'"""
strQuery_TD = """select YEAR_KEY as YEAR_ID, DATE_KEY as DAY_ID from dmsd2v_clm_mstr.d_date where year_key = '2018'"""
strSQLServer_Server = 'HOSQL16VDPRD02\MSTRATEGYEN01'
strSQLServer_DB = 'EntManager'
strTD_Database = 'LAB_BI'
strCSV_Separator = ','
strTD_table_name = 'DO_NOT_SURVEY'
# ======================================== END VARIABLES ========================================
cwd = sys.path[0]  # Get current working directory
st_time = time.time() # Start timer

# ======================================== Step 1: SQL Server Connection And Extract Data ========================================
conn_SQLServer = pyodbc.connect('Driver={SQL Server};Server=' + strSQLServer_Server + ';Database=' + strSQLServer_DB + ';Trusted_Connection=yes;')
df_SQLServer = pd.read_sql(strQuery_SQLServer, conn_SQLServer)
# ======================================== Step 2: Export Dataframe to CSV file ========================================
df_SQLServer.to_csv(cwd + '/Step2_SQL_Server_Data.csv', sep=strCSV_Separator, encoding='utf-8', index=False)
conn_SQLServer.close()

# ======================================== Step 3: Teradata Connection And Extract Data ========================================
conn_TD = pyodbc.connect('DSN=TDTest64;Trusted_Connection=yes;')
df_TD = pd.read_sql(strQuery_TD, conn_TD)
# ======================================== Step 4: Export Dataframe to CSV file ========================================
df_TD.to_csv(cwd + '/Step4_TD_Data.csv', sep=strCSV_Separator, encoding='utf-8', index=False)
conn_TD.close

# ======================================== Step 5: Left Outer Join Dataframes ========================================
df_merged = df_SQLServer.merge(df_TD, indicator='exists_in', how='outer').query('exists_in == "left_only"').drop('exists_in', 1)
# ======================================== Step 6: Export the result set to CSV file ========================================
df_merged.to_csv(cwd + '/Step6_Joined.csv', sep=strCSV_Separator, encoding='utf-8', index=False)
# ======================================== Step 7: Load Results to TD table ========================================
# Chck if table is created, if yes get the last UID/sequence ID, if not create the table and insert data
conn = pyodbc.connect('DSN=TDTEST64;Trusted_Connection=yes', autocommit=True)
cursor = conn.cursor()
measurer = np.vectorize(len)
udaExec = teradata.UdaExec(appName="MyApp", version="1.0", logConsole=True)
# session = udaExec.connect(method="odbc", system="TDTEST", username="t033270", password="Welcome7&", authentication="LDAP")
session = udaExec.connect(method="odbc", dsn="TDTEST64", Trusted_Connection="Yes", autocommit=True)
time_format = '%m/%d/%y %H:%M:%S'
insert_ts = str(dt.datetime.now().strftime(time_format))
df_merged.insert(loc=len(df_merged.columns), column='Insert_TS', value=insert_ts)
if cursor.tables(table=strTD_table_name, tableType='TABLE').fetchone(): # table exists
    strCheckTableQuery = 'SELECT MAX(UID) FROM ' + strTD_Database + '.' + strTD_table_name + ';'
    cursor.execute(strCheckTableQuery)
    last_row_ID = cursor.fetchone()[0]
    if last_row_ID:
        last_row_ID = last_row_ID + 1  # Start from this row UID
    else:
        last_row_ID = 1
    df_merged.insert(loc=0, column='UID', value=range(last_row_ID, last_row_ID + len(df_merged)))
else: # table not exists
    df_merged.insert(loc=0, column='UID', value=range(1, 1 + len(df_merged)))
    col_dtypes = df_merged.dtypes
    dtype_list = []
    for i, v in col_dtypes.items():
        if v == 'int64' or v == 'int32':
            dtype_t = i + ' INTEGER'
        elif v == 'float':
            dtype_t = i + ' DECIMAL(10,2)'
        else:  # v == 'object':
            max_len = measurer(df_merged[i].values.astype(str)).max(axis=0)
            dtype_t = i + ' VARCHAR(' + str(max_len) + ')'
        dtype_list.append(dtype_t)
    table_columns = ','.join(dtype_list)
    strSQL_CreateTable = 'CREATE MULTISET TABLE ' + strTD_Database + '.' + strTD_table_name + ', FALLBACK (' + table_columns + ') UNIQUE PRIMARY INDEX (UID);'
    cursor.execute(strSQL_CreateTable)
chunks_df = np.array_split(df_merged, 100)
cols_count = '?' * len(df_merged.columns)
strColumns = ','.join(cols_count[i:i + 1] for i in range(0, len(cols_count), 1))
for i,_ in enumerate(chunks_df):
    data = [tuple(x) for x in chunks_df[i].to_records(index=False)]
    strInsert_Query = "INSERT INTO " + strTD_Database + '.' + strTD_table_name + " values(" + strColumns + ")"
    session.executemany(strInsert_Query, data, batch=True)
session.close()
# ======================================== End Processing ========================================

end_time = time.time()
print('End time: ' + time.strftime("%H:%M:%S"))
print('Elapsed Time: ' + printRuntime(end_time - st_time))