import sys
import pyodbc
import pandas as pd
import time


# =================================================
# print(df1.merge(df2, indicator='i', how='outer').query('i == "left_only"').drop('i', 1))
# =================================================

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg
# ======================================== VARIABLES ========================================
strQuery_SQLServer = """SELECT [YEAR_ID],[DAY_ID] FROM [EntManager].[dbo].[DT_DAY] where YEAR_ID = '2018'"""
strQuery_TD = """select YEAR_KEY as YEAR_ID, DATE_KEY as DATE_ID from dmsd2v_clm_mstr.d_date where year_key = '2018'"""
strSQLServer_Server = 'HOSQL16VDPRD02\MSTRATEGYEN01'
strSQLServer_DB = 'EntManager'
strCSV_Separator = ','
# ======================================== END VARIABLES ========================================
cwd = sys.path[0]  # Get current working directory
st_time = time.time() # Start timer

# ======================================== Step 1: SQL Server Connection And Extract Data ========================================
conn_SQLServer = pyodbc.connect('Driver={SQL Server};Server=' + strSQLServer_Server + ';Database=' + strSQLServer_DB + ';Trusted_Connection=yes;')
df_SQLServer = pd.read_sql(strQuery_SQLServer, conn_SQLServer)
# ======================================== Step 2: Export Dataframe to CSV file ========================================
df_SQLServer.to_csv(cwd + '/Step2_SQL_Server_Data.csv', sep=strCSV_Separator, encoding='utf-8', index=False)
conn_SQLServer.close()

# ======================================== Step 3: Teradata Connection And Extract Data ========================================
conn_TD = pyodbc.connect('DSN=TDTest64;Trusted_Connection=yes;')
df_TD = pd.read_sql(strQuery_TD, conn_TD)
# ======================================== Step 4: Export Dataframe to CSV file ========================================
df_TD.to_csv(cwd + '/Step4_TD_Data.csv', sep=strCSV_Separator, encoding='utf-8', index=False)
conn_TD.close

# ======================================== Step 5: Left Outer Join Dataframes ========================================
df_merged = df_SQLServer.merge(df_TD, indicator='exists_in', how='outer').query('exists_in == "left_only"').drop('exists_in', 1)
# ======================================== Step 6: Export the result set to CSV file ========================================
df_merged.to_csv(cwd + '/Step6_Joined.csv', sep=strCSV_Separator, encoding='utf-8', index=False)
# ======================================== End Processing ========================================

end_time = time.time()
print('End time: ' + time.strftime("%H:%M:%S"))
print('Elapsed Time: ' + printRuntime(end_time - st_time))