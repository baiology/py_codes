# Import modules
import sys
from mstrio import microstrategy

# Parameters
username = 't033270'
password = 'test'
projectName = 'Claims Management Reporting_TD'
cubeID = '687BC447441654DB2B60A8BDBA3B7245' # as a sample test cube: 10-Day Reserve Cube
baseURL = "http://wcmsenwqa01.amica.com:8080/MicroStrategyLibrary/api" #replace with your own URL for MicroStrategy Library API

# Main program
'Create MSTR connection'
conn_TD = microstrategy.Connection(base_url=baseURL,username=username, password=password, project_name=projectName)
conn_TD.connect() # Connect() function calls login procedure where it creates X-MSTR Auth-Token automatically
cube_TD = conn_TD.get_cube(cube_id=cubeID) # get_cube function calls cube_instance procedure where X-MSTR-Auth-Token is being used.

# Save to file - in JSON format.
cwd = sys.path[0] # Get current working directory
cube_TD.to_json(cwd + '\\Cube_TD.json') # Save file to JSON
conn_TD.close() # Close connection