from urllib.parse import urlencode
from urllib.request import Request, urlopen
import requests
import io
import pandas as pd
import json
from mstrio import microstrategy

project_id = 'AF9F62054258210C513AD4A7BC50F277'
report_guid = '811720744CFD8539AD23949B798785C4' #'3E2A8D854C62231D288FB9827AE79DEF'
username = 't033270'
password = 'test'
# Connect
base_url = 'http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api'
url = base_url + '/auth/login'
response = requests.post(url, data={'username': username, 'password': password, 'loginMode': 1})
authToken = response.headers['X-MSTR-AuthToken']
cookies = dict(response.cookies)
# Create Instance
url = base_url + '/reports/' + report_guid + '/instances/?limit=1000'
instance_response = requests.post(url,
                                  headers={'X-MSTR-AuthToken': authToken,
                                           'X-MSTR-ProjectID': project_id},
                                    json={'reportId': report_guid}, cookies=cookies)
instance_json = instance_response.json()
instance_id = instance_json['instanceId']
# Get Prompt IDs
url = base_url + '/reports/' + report_guid + '/instances/' + instance_id + '/prompts'
prompt_response = requests.get(url,
                                  headers={'X-MSTR-AuthToken': authToken,
                                           'X-MSTR-ProjectID': project_id},
                                    json={'reportId': report_guid, 'instanceId': instance_id}, cookies=cookies)
prompt_json_list = prompt_response.json()
prompt_key_list = []
prompt_type_list = []
prompt_answer_list = []
for prompt in prompt_json_list:
    prompt_key_list.append(prompt['key'])
    prompt_type_list.append(prompt['type'])
    prompt_name = prompt['name']
    prompt_datatype = prompt['dataType'].upper()
    if prompt_datatype == 'DATE':
        prompt_datatype = prompt_datatype + ' (Format: YYYY-MM-DD)'
    ans = input(prompt_name + '(of type ' + prompt_datatype + '): ')
    prompt_answer_list.append(ans)
    print(ans)
# instance_id = prompt_json['instanceId']
# Create Answer Prompt
prompts = []
for index, value in enumerate(prompt_key_list):
    json_data = ''' "key":"{}","type":"{}","answers":"{}"'''.format(prompt_key_list[index], prompt_type_list[index], prompt_answer_list[index])
    prompts.append('{' + json_data + '}')
prompts_json_body = '{"prompts":[' + ','.join(prompts) + ']}'
# 1# print(','.join(prompts))
# json_body = '''{
#   "prompts":[
#     {
#       "key":"D1AB5D964F841DF4050760ACBD5FC47C@0@10",
#       "type":"VALUE",
#       "answers": "2019-10-20T00:00:00.000+0000"
#     },
#     {
#       "key":"DA91BA764D3E206244AB54BB6E90A45C@0@10",
#       "type":"VALUE",
#       "answers": "2019-10-26T00:00:00.000+0000"
#     }
#   ]
# }'''

# Execute PUT statement to generate the report   #'Content-Type': 'application/json', 'Accept': 'application/json',
x = json.dumps(prompts_json_body)
url = base_url + '/reports/' + report_guid + '/instances/' + instance_id + '/prompts/answers'
headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'X-MSTR-AuthToken': authToken, 'X-MSTR-ProjectID': project_id} #, 'X-MSTR-ProjectID': project_id}
data_payload = {'body': prompts_json_body}
json_data = {'reportId': report_guid, 'instanceId': instance_id}
req = Request(url=url, data=data_payload, headers=headers, method='PUT')
jsond= urlopen(req)
# print(urllib.request.)
# prompt_answer_response = requests.put(url, headers=headers, data=data_payload, cookies=cookies)
# prompt_answer_json = prompt_answer_response.json()
# instance_id = instance_json['instanceId']
print(instance_response.text)

