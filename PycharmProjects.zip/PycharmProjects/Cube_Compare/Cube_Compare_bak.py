from mstrio import microstrategy
import os
import sys
import time
import datetime
import pandas as pd
import numpy as np

'Functions'
def compare_two_dfs(input_df_1, input_df_2):
    df_1, df_2 = input_df_1.copy(), input_df_2.copy()
    ne_stacked = (df_1 != df_2).stack()
    changed = ne_stacked[ne_stacked]
    changed.index.names = ['Index', 'TD Column']
    difference_locations = np.where(df_1 != df_2)
    changed_from = df_1.values[difference_locations]
    changed_to = df_2.values[difference_locations]
    df = pd.DataFrame({'Base': changed_from, 'Target': changed_to}, index=changed.index)
    return df

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

def createFolder(cwd):
    now = datetime.datetime.now()
    strDate = now.strftime("%m%d%Y_%H%M%S")
    outPath = cwd + "\\" + strDate
    if not os.path.exists(outPath):
        os.makedirs(outPath)
    return outPath


def replaceChars(mainString, toReplace, newString):
    # Iterate over the strings to be replaced
    for elem in toReplace:
        # Check if string is in the main string
        if elem in mainString:
            # Replace the string
            mainString = mainString.replace(elem, newString)
    return mainString

def logWriter(str, log):
    strTowWrite = str + '\n'
    log.write(strTowWrite)
    print(str)

baseurl = "http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api"
TD_project_name = "Claims Management Reporting_TD"
SYSDM_project_name = "Claims Management Reporting_SYSDM"
username = 't033270'
password = 'test'

oall_start = time.time()
'Create directory by date if not exist'
cwd = sys.path[0]
outPath = createFolder(cwd)

'Create MSTR connection'
conn_TD = microstrategy.Connection(base_url=baseurl, username=username, password=password, project_name=TD_project_name)
conn_DB2 = microstrategy.Connection(base_url=baseurl, username=username, password=password, project_name=SYSDM_project_name)
conn_DB2.connect()
cube_list = cwd + "\\cube_list.txt"
strSummary = outPath + "\\Cube_Compare_Summary.txt"
fl_Summary = open(strSummary, "w+", encoding="utf-8")
ctr = 0
fl_OverAllLog = open(outPath + "\\Cube_Compare_Log_Summary.txt", "w+", encoding="utf-8")
logWriter('Start time: ' + time.strftime("%H:%M:%S"), fl_OverAllLog)
logWriter('API Base URL: ' + baseurl, fl_OverAllLog)
with open(cube_list, 'r') as lstCube:
    for cube in lstCube:

        'TD Connection'
        currCubeName_orig = cube.split(',')[0]
        currCubeName = replaceChars(cube.split(',')[0],' /\\<>?|*"', '_').rstrip()
        currCubeID_SYSDM = cube.split(',')[1].rstrip()
        currCubeID_TD = cube.split(',')[2].rstrip()
        strLog = outPath + "\\" + currCubeName + "_Log.txt"
        fl_Log = open(strLog, "w+", encoding="utf-8")
        logWriter('==========================================================================================', fl_Log)
        cube_TD_Error = False
        try:
            logWriter('Establishing TD connection with MSTR Project. Cube: [' + currCubeName + ']', fl_Log)
            conn_TD.connect()
            logWriter('Connection established.', fl_Log)
            start = time.time()
            logWriter('Capturing the records from MSTR Project.', fl_Log)
            cube_TD = conn_TD.get_cube(cube_id=currCubeID_TD)
            logWriter('Records successfully loaded [' + str(cube_TD.shape[0]) + '] to the data frame. ' + str(
                printRuntime(time.time() - start)), fl_Log)
        except:
            cube_TD_Error = True
        conn_TD.close()

        'DB2 Connection'
        cube_DB2_Error = False
        try:
            logWriter('Establishing DB2 connection with MSTR Project.', fl_Log)
            conn_DB2.connect()
            logWriter('Connection established.', fl_Log)
            start = time.time()
            logWriter('Capturing the records from MSTR Project.', fl_Log)
            cube_DB2 = conn_DB2.get_cube(cube_id=currCubeID_SYSDM)
            logWriter('Records successfully loaded [' + str(cube_DB2.shape[0]) + '] to the data frame. ' + str(
            printRuntime(time.time() - start)), fl_Log)
        except:
            cube_DB2_Error = True
        conn_DB2.close()

        if cube_TD_Error != True and cube_DB2_Error != True :
            start = time.time()
            strMM = outPath + "\\MM_" + currCubeName + ".txt"
            cube_TD.columns = [x for x in list(cube_DB2.columns)]
            rowCount_DB2 = cube_DB2.shape[0]
            rowCount_TD = cube_TD.shape[0]
            if not cube_DB2.equals(cube_TD) and rowCount_DB2 == rowCount_TD:
                df = compare_two_dfs(cube_DB2, cube_TD)
                df.to_csv(strMM, sep=',', encoding='utf-8', index=False)
                fl_Summary.write(currCubeName_orig + ',' + str(df.shape[0]) + '\n')
                logWriter(currCubeName_orig + ',' + str(df.shape[0]) + '\n', fl_Log)
            elif cube_DB2.equals(cube_TD):
                fl_Summary.write(currCubeName_orig + ',' + 'Matched' + '\n')
                logWriter(currCubeName_orig + ',' + 'Matched', fl_Log)
            else:
                fl_Summary.write(currCubeName_orig + ',' + 'Row count not matched' + '\n')
                logWriter(currCubeName_orig + ',' + 'Row count not matched', fl_Log)
            logWriter('Cube compare completed for cube [' + str(currCubeName_orig) + ']. Elapsed time: ' + printRuntime(time.time() - start), fl_Log)
            logWriter('==========================================================================================', fl_Log)
            ctr += 1
        else:
            fl_Summary.write(currCubeName_orig + ',' + 'Unable to get cube data.' + '\n')
        fl_Log.close()
logWriter('Cube compare completed for ' + str(ctr) + ' cube(s).', fl_OverAllLog)
logWriter('End time: ' + time.strftime("%H:%M:%S"), fl_OverAllLog)
logWriter('Elapsed time: ' + printRuntime(time.time() - oall_start), fl_OverAllLog)
fl_Summary.close()
sys.exit()