from mstrio import microstrategy
import os
import sys
import time
import datetime
import pandas as pd
import numpy as np

'Functions'
def compare_two_dfs(input_df_1, input_df_2):
    df_1, df_2 = input_df_1.copy(), input_df_2.copy()
    ne_stacked = (df_1 != df_2).stack()
    changed = ne_stacked[ne_stacked]
    changed.index.names = ['Index', 'TD Column']
    difference_locations = np.where(df_1 != df_2)
    changed_from = df_1.values[difference_locations]
    changed_to = df_2.values[difference_locations]
    df = pd.DataFrame({'Base': changed_from, 'Target': changed_to}, index=changed.index)
    return df

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

def createFolder(cwd):
    now = datetime.datetime.now()
    strDate = now.strftime("%m%d%Y_%H%M%S")
    outPath = cwd + "\\" + strDate
    if not os.path.exists(outPath):
        os.makedirs(outPath)
    return outPath


def replaceChars(mainString, toReplace, newString):
    # Iterate over the strings to be replaced
    for elem in toReplace:
        # Check if string is in the main string
        if elem in mainString:
            # Replace the string
            mainString = mainString.replace(elem, newString)
    return mainString

def logWriter(str, log):
    strTowWrite = str + '\n'
    log.write(strTowWrite)
    print(str)

baseurl = "http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api"
LEFT_project_name = "Claims Management Reporting"
RIGHT_project_name = "Claims Management Reporting_PRV"
username = 't033270'
password = 'test'

oall_start = time.time()
'Create directory by date if not exist'
cwd = sys.path[0]
outPath = createFolder(cwd)

'Create MSTR connection'
conn_LEFT = microstrategy.Connection(base_url=baseurl, username=username, password=password, project_name=LEFT_project_name)
conn_RIGHT = microstrategy.Connection(base_url=baseurl, username=username, password=password, project_name=RIGHT_project_name)
# conn_RIGHT.connect()
cube_list = cwd + "\\cube_list.txt"
strSummary = outPath + "\\Cube_Compare_Summary.txt"
fl_Summary = open(strSummary, "w+", encoding="utf-8")
ctr = 0
# fl_OverAllLog = open(outPath + "\\Cube_Compare_Log_Summary.txt", "w+", encoding="utf-8")
# logWriter('Start time: ' + time.strftime("%H:%M:%S"), fl_OverAllLog)
# logWriter('API Base URL: ' + baseurl, fl_OverAllLog)
with open(cube_list, 'r') as lstCube:
    for index, cube in enumerate(lstCube):
        currCubeName_orig = cube.split(',')[0]
        currCubeName = replaceChars(cube.split(',')[0],' /\\<>?|*"', '_').rstrip()
        currCubeID_LEFT = cube.split(',')[1].rstrip()
        currCubeID_RIGHT = cube.split(',')[2].rstrip()
        strLog = outPath + "\\" + currCubeName + "_Log.txt"
        fl_Log = open(strLog, "w+", encoding="utf-8")
        # cube_TD = pd.read_csv(cwd + '/' + currCubeName + '_TD.csv')
        # cube_DB2 = pd.read_csv(cwd + '/' + currCubeName + '_DB2.csv')
        logWriter('==========================================================================================', fl_Log)
        cube_LEFT_Error = False
        # LEFT Data
        try:
            logWriter('Establishing connection with MSTR Project [' + str(LEFT_project_name) + ']. Cube: [' + currCubeName + ']', fl_Log)
            conn_LEFT.connect()
            logWriter('Connection established.', fl_Log)
            start = time.time()
            logWriter('Capturing the records from the project.', fl_Log)
            cube_LEFT = conn_LEFT.get_cube(cube_id=currCubeID_LEFT)
            cube_LEFT.columns = cube_LEFT.columns.str.replace(' ', '_')
            cube_LEFT_column_list = cube_LEFT.columns.tolist()
            cl = cube_LEFT.columns.duplicated()
            ldup = [(i, l) for i,l in enumerate(cl) if l == True]
            ldup_final_list = [cube_LEFT_column_list[d[0]] for d in ldup]
            ColCount_LEFT = int(len(cube_LEFT.columns))
            # cube_LEFT.to_csv(outPath + '/' + currCubeName + '_LEFT.csv')
            logWriter('Records successfully loaded [' + str(cube_LEFT.shape[0]) + '] to the data frame. ' + str(printRuntime(time.time() - start)), fl_Log)
        except:
            cube_LEFT_Error = True
        conn_LEFT.close()

        # RIGHT Data
        cube_RIGHT_Error = False
        try:
            logWriter('Establishing connection with MSTR Project [' + str(RIGHT_project_name) + ']', fl_Log)
            conn_RIGHT.connect()
            logWriter('Connection established.', fl_Log)
            start = time.time()
            logWriter('Capturing the records from the project.', fl_Log)
            cube_RIGHT = conn_RIGHT.get_cube(cube_id=currCubeID_RIGHT)
            cube_RIGHT.columns = cube_RIGHT.columns.str.replace(' ', '_')
            cube_RIGHT_column_list = cube_RIGHT.columns.tolist()
            cr = cube_RIGHT.columns.duplicated()
            rdup = [(i, l) for i,l in enumerate(cr) if l == True]
            rdup_final_list = [cube_RIGHT_column_list[d[0]] for d in rdup]
            ColCount_RIGHT = int(len(cube_LEFT.columns))
            # cube_RIGHT.to_csv(outPath + '/' + currCubeName + '_RIGHT.csv')
            logWriter('Records successfully loaded [' + str(cube_RIGHT.shape[0]) + '] to the data frame. ' + str(printRuntime(time.time() - start)), fl_Log)
            # cube_DB2.to_csv(cwd + '/' + currCubeName + '_DB2.csv')
        except:
            ex_type, ex_value, ex_traceback = sys.exc_info()
            cube_RIGHT_Error = True
        conn_RIGHT.close()
        rowCount_LEFT = cube_RIGHT.shape[0]
        rowCount_RIGHT = cube_LEFT.shape[0]
        df = pd.merge(cube_LEFT, cube_RIGHT, how='outer', indicator='Exist')
        df.columns = df.columns.str.replace(' ', '_')
        total_rowcounts = rowCount_LEFT + rowCount_RIGHT
        if total_rowcounts == df.shape[0]:
            fl_Summary.write(str((index + 1)) + ',' + currCubeName_orig + ',Both table data doesn\'t matched\n')
            continue
        if cube_LEFT_Error or cube_RIGHT_Error:
            fl_Summary.write(str((index + 1)) + ',' + currCubeName_orig + ',Unable to get Cube data or Cube not yet Published\n')
            continue
        elif 'Clm' not in cube_LEFT.columns or 'Clm' not in cube_RIGHT.columns:
            fl_Summary.write(str((index + 1)) + ',' + currCubeName_orig + ',[Clm] column not found\n')
            continue
        elif 'File_Number' not in cube_LEFT.columns or 'File_Number' not in cube_RIGHT.columns:
            fl_Summary.write(str((index + 1)) + ',' + currCubeName_orig + ',[File Number] column not found\n')
            continue
        elif ColCount_LEFT != ColCount_RIGHT:
            fl_Summary.write(str((index + 1)) + ',' + currCubeName_orig + ',Column count not matched\n')
            continue
        elif len(ldup_final_list) > 0 or len(rdup_final_list) > 0:
            if len(ldup_final_list) > 0 and len(ldup_final_list) == 0:
                fl_Summary.write(str((index + 1)) + ',' + currCubeName_orig + ',Duplicate column(s) found[LEFT: ' + ','.join(ldup_final_list)  + '\n')
            elif len(ldup_final_list) == 0 and len(ldup_final_list) > 0:
                fl_Summary.write(str((index + 1)) + ',' + currCubeName_orig + ',Duplicate column(s) found[RIGHT: ' + ','.join(rdup_final_list)  + '\n')
            else:
                fl_Summary.write(str((index + 1)) + ',' + currCubeName_orig + ',Duplicate column(s) found[LEFT:' + ','.join(ldup_final_list) + ' RIGHT: ' + ','.join(rdup_final_list) + '\n')
            continue
        start = time.time()
        xlsx_Output = outPath + "\\Mismatch_" + currCubeName + '.xlsx'
        # Change the column names to make it equal to Cube RIGHT column names
        cube_LEFT.columns = [x for x in list(cube_RIGHT.columns)]
        # cube_LEFT.to_csv(outPath + '/' + currCubeName + '_LEFT.csv')
        if not cube_RIGHT.equals(cube_LEFT): # and rowCount_DB2 == rowCount_TD:
            # df = compare_two_dfs(cube_DB2, cube_TD)
            # df.drop(df.columns[0], axis=1, inplace=True)
            # df_left_right_temp = df.loc[df['Exist'] != 'both']
            # print('run filter exists not both')
            df_left_right = df.loc[df['Exist'] != 'both']
            # print(df_left_right.shape[0])
            column_list = df_left_right.columns.tolist()
            # df_left_right = df_left_right_temp.copy()
            # df_left_right_temp = None
            # df_left_right.loc[:, 'Mismatched_Column'] = 'na'
            df_left_right = df_left_right.assign(Mismatched_Column='')
            # df_left_right['Mismatched_Column'] = ""

            # Get the mismatch columns
            for row in df_left_right.itertuples(index=True, name='Pandas'):
                # print(getattr(row, "Name"), getattr(row, "Percentage"))
                print(row)
                vlist_df_left_right = list(row)[1:]
                df_left_right_exists_in = vlist_df_left_right[-2]
                clm = '"' + getattr(row, "Clm") + '"'
                file_no = '"' + getattr(row, "File_Number") + '"'
                cond = 'Clm == ' + clm + ' and ' + 'File_Number == ' + file_no
                if df_left_right_exists_in == 'left_only':
                    # print('run query right')
                    df_right_temp = cube_RIGHT.query(cond)
                    print(df_right_temp.shape[0])
                    if len(df_right_temp.index) == 0:
                        df_left_right.at[row.Index, 'Mismatched_Column'] = "File Number and Clm doesn't exist in RIGHT"
                    else:
                        vlist_df_RIGHT = df_right_temp.values.tolist()[0]
                        del vlist_df_left_right[-2:]
                        not_matched_left_list= [index for index, elem in enumerate(vlist_df_left_right) if elem != vlist_df_RIGHT[index]]
                        cols_not_matched_left = [column_list[s] for s in not_matched_left_list]
                        df_left_right.at[row.Index, 'Mismatched_Column'] = ','.join(cols_not_matched_left)
                else:
                    # print('run query left')
                    df_left_temp = cube_LEFT.query(cond)
                    # print(df_left_temp.shape[0])
                    if len(df_left_temp.index) == 0:
                        df_left_right.at[row.Index, 'Mismatched_Column'] = "File Number and Clm doesn't exist in LEFT"
                    else:
                        vlist_df_LEFT = df_left_temp.values.tolist()[0]
                        del vlist_df_left_right[-2:]
                        not_matched_right_list = [index for index, elem in enumerate(vlist_df_left_right) if elem != vlist_df_LEFT[index]]
                        cols_not_matched_right = [column_list[s] for s in not_matched_right_list]
                        df_left_right.at[row.Index, 'Mismatched_Column'] = ','.join(cols_not_matched_right)
            df_left_right = df_left_right.sort_values('File_Number', ascending=True)
            print('Processing Complete. \nWriting output to file: ' + xlsx_Output + '\n')
            xlsxFile = os.path.normpath(xlsx_Output)
            writer = pd.ExcelWriter(xlsxFile, engine='xlsxwriter')
            df_left_right.to_excel(writer, 'Mismatch', index=False)
            writer.save()

            fl_Summary.write(str((index + 1)) + ',' + currCubeName_orig + ',Not Matched\n')
            # logWriter(currCubeName_orig + ',' + str(df.shape[0]) + '\n', fl_Log)
        elif cube_RIGHT.equals(cube_LEFT):
            fl_Summary.write(str((index + 1)) + ',' + currCubeName_orig + ',' + 'Matched' + '\n')
            logWriter(currCubeName_orig + ',' + 'Matched', fl_Log)
        logWriter('Cube compare completed for cube [' + str(currCubeName_orig) + ']. Elapsed time: ' + printRuntime(time.time() - start), fl_Log)
        logWriter('==========================================================================================', fl_Log)
        ctr += 1
        fl_Log.close()
print('Cube compare completed for ' + str(ctr) + ' cube(s).')
print('End time: ' + time.strftime("%H:%M:%S"))
print('Elapsed time: ' + printRuntime(time.time() - oall_start))
fl_Summary.write('===================================================================================\n')
fl_Summary.write('Elapsed time: ' + printRuntime(time.time() - oall_start) + '\n')
fl_Summary.write('===================================================================================\n')
fl_Summary.close()
sys.exit()