import os
import time
import datetime
import sys
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait, TimeoutException
import logging


class WebsiteScreenShotGenerator:
    SHORT_TIMEOUT = 5  # give enough time for the loading element to appear
    LONG_TIMEOUT = 300  # give enough time for loading to finish

    def __init__(self, url, headless=False, timeout=300):
        self.starttime = datetime.datetime.now()
        self.timeout = timeout
        self.logger = logging.getLogger('visix')
        # instantiate a chrome options object so you can set the size and headless preference
        self.chrome_options = Options()
        if headless:
            self.chrome_options.add_argument("--headless")
        self.chrome_options.add_argument("--start-maximized")
        self.chrome_driver = sys.path[0] + "\\chromedriver.exe"
        self.driver = webdriver.Chrome(chrome_options=self.chrome_options,
                                       executable_path=self.chrome_driver)
        # Uid
        self.url = url
        self.driver.get(self.url)

    def __del__(self):
        self.driver.get(self.url)
        self.logger.info("Closing Driver")
        self.driver.close()

    def wait_for_ec(self, expected_condition, driver_wait=10):
        self.logger.info("waiting for EC")
        while True:
            try:
                WebDriverWait(self.driver, driver_wait).until(expected_condition)
                return 0
            except TimeoutException:
                self.logger.info("caught timeout - elaspsed seconds: ")
                currenttime = datetime.datetime.now()
                elapsedtime = currenttime - self.starttime
                self.logger.info(int(elapsedtime.seconds))
                if int(elapsedtime.seconds) < self.timeout:
                    self.logger.info("Elapsed Time = ", elapsedtime)
                    continue
                else:
                    self.logger.error("Error: Timeout waiting for -")
                    self.logger.error(expected_condition)
                    return -1

    def capture(self, url, output_filename, output_locations, crop=False, width=None, height=None):

        self.driver.get(url)
        # Sleep for a few seconds to allow everything to calm down.
        time.sleep(10)

        for l in output_locations:
            output_file = l + "\\" + output_filename
            self.driver.get_screenshot_as_file(output_file)


