import functools
from microstrategy_screenshot_abailon import WebsiteScreenShotGenerator
import configparser
import time
import schedule
import logging
from subprocess import check_output


class MicroStrategyReportCapture:

    def __init__(self, settings):

        self.settings = settings
        config = configparser.ConfigParser()
        config.read(self.settings)
        config.sections()

        self.job_schedule = schedule.default_scheduler
        self.user = str(config['DEFAULT']['user'])
        self.password = str(config['DEFAULT']['passwd'])
        self.image_loc = str(config['DEFAULT']['imagelocation'])

        for r in config.sections():
            report = config[r]
            url = str(report['url'])
            server = str(report['server'])
            guid = str(report['guid'])
            project = str(report['project'])
            image = str(report['imgname'])
            refresh = int(report['refresh_minutes'])

            report_url = url + '&evt=3140&src=Main.aspx.3140&' + \
                         '&documentID=' + guid + \
                         '&Server=' + server + \
                         '&Project=' + project + \
                         '&Port=0&share=1'

            self.job_schedule.every(refresh).minutes.do(self.job, server_url=url, image=image, report_url=report_url)

    def with_logging(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            print('LOG: Running job "%s"' % func.__name__)
            result = func(*args, **kwargs)
            print('LOG: Job "%s" completed' % func.__name__)
            return result
        return wrapper

    @with_logging
    def job(self, server_url, image, report_url):
        # get the Screen Shot
        screen_grabber = WebsiteScreenShotGenerator(server_url, self.user, self.password)
        output_file = self.image_loc + "\\" + image
        screen_grabber.capture(url=report_url, output_filename=output_file)

        del screen_grabber

    def run(self):
        logging.basicConfig(filename='run.log', level=logging.INFO)

        while True:
            next_run = self.job_schedule.next_run
            print(next_run)
            self.job_schedule.run_pending()
            time.sleep(10)


if __name__ == '__main__':

    reporter = MicroStrategyReportCapture("settings.ini")
    reporter.run()
