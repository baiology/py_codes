import os
import time
import datetime
import sys
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait, TimeoutException
import logging


class MSTRScreenShotGenerator:
    SHORT_TIMEOUT = 5  # give enough time for the loading element to appear
    LONG_TIMEOUT = 300  # give enough time for loading to finish
    LOADING_ELEMENT_XPATH = '//div[@class="mstrWait"]'
    WAIT_ELEMENT_XPATH = '//div[@class="mstrmojo-Box mstrIcon-wait"]'
    TOOLBAR_ELEMENT_XPATH = '//[@id="rootView"]div[@class="mstrmojo-RootView-toolbar"]'
    CLOSE_BUTTON_XPATH = '//*[@id="mstr38"]/div[1]/div[5]/div/div'

    USERNAME_TEXTBOX = '//*[@id="Uid"]'
    PASSWORD_TEXTBOX = '//*[@id="Pwd"]'
    PWD_BUTTON = '//*[@id="3054"]'
    LOGOUT = '?evt=3008&src=Main.aspx.3008'
    LOGIN = '?connmode=1'
    CLICK_HERE = '//*[@id="mstrWeb_content"]/div[1]/a'  # Added by Andrew Bailon


    def __init__(self, url, user, pw, timeout=300, headless=True):
        self.starttime = datetime.datetime.now()
        self.logger = logging.getLogger('visix')
        self.timeout = timeout
        # instantiate a chrome options object so you can set the size and headless preference
        chrome_options = Options()
        if headless:
            chrome_options.add_argument("--headless")
        chrome_options.add_argument("--start-fullscreen")
        chrome_driver = sys.path[0] + "\\chromedriver.exe"
        self.driver = webdriver.Chrome(chrome_options=chrome_options,
                                       executable_path=chrome_driver)
        self.driver.set_window_size(1920, 1080)
        # Uid
        self.url = url
        self.driver.get(self.url+self.LOGIN)

        # Handle any Click Here conditions but don't require MicroStrategy to show that notification
        time.sleep(5)  # Sleep for a few seconds to allow the page to load.
        try:
            if self.driver.find_element_by_xpath(self.CLICK_HERE):
                self.driver.find_element_by_xpath(self.CLICK_HERE).click()
        except NoSuchElementException:
            pass

        submit_button = EC.element_to_be_clickable((By.XPATH, self.PWD_BUTTON))
        self.wait_for_ec(submit_button)
        username = self.driver.find_element_by_xpath(self.USERNAME_TEXTBOX)
        password = self.driver.find_element_by_xpath(self.PASSWORD_TEXTBOX)

        username.send_keys(user)
        password.send_keys(pw)

        self.driver.find_element_by_xpath(self.PWD_BUTTON).click()

    def __del__(self):
        self.driver.get(self.url+self.LOGOUT)
        self.logger.info("Closing Driver")
        self.driver.quit()

    def wait_for_ec(self, expected_condition, driver_wait=10):
        self.logger.info("waiting for EC")
        while True:
            try:
                WebDriverWait(self.driver, driver_wait).until(expected_condition)
                return 0
            except TimeoutException:
                self.logger.info("caught timeout - elaspsed seconds: ")
                currenttime = datetime.datetime.now()
                elapsedtime = currenttime - self.starttime
                self.logger.info(int(elapsedtime.seconds))
                if int(elapsedtime.seconds) < self.timeout:
                    self.logger.info("Elapsed Time = ", elapsedtime)
                    continue
                else:
                    self.logger.error("Error: Timeout waiting for -")
                    self.logger.error(expected_condition)
                    return -1

    def capture(self, url, output_filename, output_locations, crop=False, width=None, height=None):
        self.logger.info("Capturing Screenshot for " + output_filename)
        self.driver.get(url)
        close_button = EC.element_to_be_clickable((By.XPATH, self.CLOSE_BUTTON_XPATH))
        status = self.wait_for_ec(close_button)

        if status == 0:
            wait_banner = EC.invisibility_of_element_located((By.XPATH, self.WAIT_ELEMENT_XPATH))
            status = self.wait_for_ec(wait_banner)

        # Sleep for a few seconds to allow everything to calm down.
        time.sleep(10)

        if status == 0:
            for l in output_locations:
                output_file = l + "\\" + output_filename
                self.driver.get_screenshot_as_file(output_file)
            return
        else:
            self.logger.error("Timed out waiting for website to load.")



