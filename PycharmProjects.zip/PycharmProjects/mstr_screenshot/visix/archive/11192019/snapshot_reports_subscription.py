import functools

import sys
from website_screenshot import WebsiteScreenShotGenerator
from microstrategy_screenshot import MSTRScreenShotGenerator
import configparser
import time
import schedule
import logging

class MicroStrategyReportCapture:

    def __init__(self, settings):
        logging.basicConfig(filename='visix.log', level=logging.INFO)
        self.logger = logging.getLogger('visix')
        self.logger.info("Starting Visix Screenshoter")
        self.settings = settings
        config = configparser.ConfigParser()
        config.read(self.settings)
        config.sections()

        self.job_schedule = schedule.default_scheduler
        self.user = str(config['DEFAULT']['user'])
        self.password = str(config['DEFAULT']['passwd'])

        for r in config.sections():
            report = config[r]
            url = str(report['url'])
            image = str(report['imgname'])
            refresh = int(report['refresh_minutes'])

            image_locations = [e.strip() for e in str(report['image_locations']).split(',')]
            pagetype = str(report['type'])
            if pagetype in ['webpage']:
                self.job_schedule.every(refresh).minutes.do(self.web_job, image_name=image,
                                                            image_locations=image_locations, report_url=url)
            else:
                server = str(report['server'])
                guid = str(report['guid'])
                project = str(report['project'])
                report_url = guid + '&Server=' + server + \
                                    '&Project=' + project + \
                                    '&Port=0&share=1'
                self.job_schedule.every(refresh).minutes.do(self.mstr_job, server_url=url, image_name=image, timeout=refresh,
                                                            image_locations=image_locations, report_url=report_url)

    def with_logging(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            logger = logging.getLogger('visix')
            logger.info('LOG: Running job "%s"' % func.__name__)
            result = func(*args, **kwargs)
            logger.info('LOG: Job "%s" completed' % func.__name__)
            return result

        return wrapper

    @with_logging
    def mstr_job(self, server_url, image_name, image_locations, report_url, timeout=300):
        """
        MicroStrategy job type.  This job type will use the MSTRScreenShotGenerator class to capture screenshots.
        The MicroStrategy screenshot class includes code to wait for the completion of the MicroStragey report.
        :param server_url: the base MicroStrategy url for authentication.
        :param image: name of the output_filename image.
        :param report_url: the url to the actual report.
        """
        # get the Screen Shot
        screen_grabber = MSTRScreenShotGenerator(server_url, self.user, self.password, timeout=timeout)
        screen_grabber.capture(url=report_url, output_locations=image_locations, output_filename=image_name)

        del screen_grabber

    @with_logging
    def web_job(self, image_name, image_locations, report_url, timeout=300):
        """
        Standard Web site job type.  This job type will use the WebsiteShotGenerator class to capture screenshots.
        :param image:  name of the output_filename image.
        :param report_url: url of the website.
        """
        # get the Screen Shot
        screen_grabber = WebsiteScreenShotGenerator(report_url, timeout=timeout)
        screen_grabber.capture(url=report_url, output_locations=image_locations, output_filename=image_name)

        del screen_grabber

    def run(self):


        while True:
            next_run = self.job_schedule.next_run
            self.job_schedule.run_pending()
            time.sleep(10)


if __name__ == '__main__':
    cwd = sys.path[0]  # Get current working directory
    reporter = MicroStrategyReportCapture(cwd + "/settings.ini")
    reporter.run()
