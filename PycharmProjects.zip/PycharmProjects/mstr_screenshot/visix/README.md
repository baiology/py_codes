Download and install Chrome
Download the Chrome Driver for Selenium. https://chromedriver.chromium.org/getting-started

Maybe not needed - pip install selenium

pip install requests

pip install phantomJS
pip install pillow
pip install python-interface
pip install subprocess