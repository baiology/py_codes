import os
import time

import sys
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait, TimeoutException


class WebsiteScreenShotGenerator:
    SHORT_TIMEOUT = 5  # give enough time for the loading element to appear
    LONG_TIMEOUT = 300  # give enough time for loading to finish
    LOADING_ELEMENT_XPATH = '//div[@class="mstrWait"]'
    WAIT_ELEMENT_XPATH = '//div[@class="mstrmojo-Box mstrIcon-wait"]'
    TOOLBAR_ELEMENT_XPATH = '//[@id="rootView"]div[@class="mstrmojo-RootView-toolbar"]'
    CLOSE_BUTTON_XPATH = '//*[@id="mstr38"]/div[1]/div[5]/div/div'

    USERNAME_TEXTBOX = '//*[@id="Uid"]'
    PASSWORD_TEXTBOX = '//*[@id="Pwd"]'
    PWD_BUTTON = '//*[@id="3054"]'
    LOGOUT = '?evt=3008&src=Main.aspx.3008'
    LOGIN = '?connmode=1'
    CLICK_HERE = '//*[@id="mstrWeb_content"]/div[1]/a' # Added by Andrew Bailon

    def __init__(self, url, user, pw, headless=False):

        # instantiate a chrome options object so you can set the size and headless preference
        self.chrome_options = Options()
        if headless:
            self.chrome_options.add_argument("--headless")
        self.chrome_options.add_argument("--start-maximized")
        self.chrome_driver = sys.path[0] + "\\chromedriver.exe"
        self.driver = webdriver.Chrome(chrome_options=self.chrome_options,
                                       executable_path=self.chrome_driver)
        # Uid
        self.url = url
        self.driver.get(self.url+self.LOGIN)

        click_here_link = EC.element_to_be_clickable((By.XPATH, self.CLICK_HERE))  # Added by Andrew Bailon
        self.wait_for_ec(click_here_link)  # Added by Andrew Bailon
        self.driver.find_element_by_xpath(self.CLICK_HERE).click()  # Added by Andrew Bailon
        submit_button = EC.element_to_be_clickable((By.XPATH, self.PWD_BUTTON))
        self.wait_for_ec(submit_button)
        username = self.driver.find_element_by_xpath(self.USERNAME_TEXTBOX)
        password = self.driver.find_element_by_xpath(self.PASSWORD_TEXTBOX)

        username.send_keys(user)
        password.send_keys(pw)

        self.driver.find_element_by_xpath(self.PWD_BUTTON).click()

    def __del__(self):
        self.driver.get(self.url+self.LOGOUT)
        self.driver.close()

    def wait_for_ec(self, expected_condition, time_chunks=5, max_wait=480):
        time_waited = driver_wait = time_chunks
        while True:
            try:
                WebDriverWait(self.driver, driver_wait).until(expected_condition)
                return 0
            except TimeoutException:
                time_waited += time_chunks
                if time_waited < max_wait:
                    continue
                else:
                    return None

    def capture(self, url, output, crop=False, width=None, height=None):

        self.driver.get(url)
        close_button = EC.element_to_be_clickable((By.XPATH, self.CLOSE_BUTTON_XPATH))
        self.wait_for_ec(close_button)

        wait_banner = EC.invisibility_of_element_located((By.XPATH, self.WAIT_ELEMENT_XPATH))
        self.wait_for_ec(wait_banner)

        # Sleep for a few seconds to allow everything to calm down.
        time.sleep(10)
        self.driver.get_screenshot_as_file(output)


