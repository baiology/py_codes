import datetime
import os
import pandas as pd
import xml.etree.ElementTree as ET
import sys
import datetime as dt
import pyodbc
import teradata
import numpy as np

measurer = np.vectorize(len)
udaExec = teradata.UdaExec(appName="MyApp", version="1.0", logConsole=True)
session = udaExec.connect(method="odbc", system="TDTEST", username="t033270", password="Welcome7&", authentication="LDAP")
time_format = '%m/%d/%y %H:%M:%S'
start_time = str(dt.datetime.now().strftime(time_format))
print('  Start time: ' + start_time)
print('  ==================================')
cwd = sys.path[0]  # Get current working directory
src_folder = cwd + '/src' # Get the source folder where XMLs are stored
files_list = [src_folder + '/' + x for x in os.listdir(src_folder) if x.endswith('.xml')] # Create a list of files with file path
row_data = []
header_count = 0
headers = []
print('  XML Parse in-progress...')
for file in files_list:
    tree = ET.parse(file)
    root = tree.getroot()
    project_name = os.path.splitext(os.path.basename(file))[0]
    # Get Row headers
    record_count = len(root.findall('.//Row'))
    old_header_count = 0
    for row in root.findall('.//Row'):
        row_value_list = []
        current_header_count = len(row)
        if current_header_count > old_header_count: # get the maximum header count
            headers = [x.tag for x in row]
        row_value_list = [x.text for x in row]
        old_header_count = len(row)
        row_value_list.insert(0, project_name)
        row_data.append(row_value_list)
headers.insert(0, 'Project_Name')
df = pd.DataFrame(row_data)
df.columns = headers
final_df = df[~df["FolderPath"].str.contains('Profiles', na=False)] # Removes all rows with *Profiles*
now = datetime.datetime.now()
strDate = now.strftime("%m%d%Y_%H%M%S")
# final_df.insert(loc=len(final_df.columns), column='Create_TS', value=strDate)
insert_ts = str(dt.datetime.now().strftime(time_format))
final_df.insert(loc=len(final_df.columns), column='Insert_TS', value=insert_ts)
xlsx_Output = cwd + '\\ACL_' + strDate + '.xlsx'
xlsxFile = os.path.normpath(xlsx_Output)
writer = pd.ExcelWriter(xlsxFile, engine='xlsxwriter')
final_df.to_excel(writer, 'ACL', index=False)
writer.save()
# Check if table is created, if yes get the last UID/sequence ID, if not create the table and insert data
conn = pyodbc.connect('DSN=TDTEST64;Trusted_Connection=yes', autocommit=True)
cursor = conn.cursor()
if cursor.tables(table='ACL', tableType='TABLE').fetchone(): # table exists
    cursor.execute('SELECT MAX(UID) FROM LAB_BI.ACL;')
    last_row_ID = cursor.fetchone()[0] + 1 # Start from this row UID
    final_df.insert(loc=0, column='UID', value=range(last_row_ID, last_row_ID + len(final_df)))
else: # table not exists
    final_df.insert(loc=0, column='UID', value=range(1, 1 + len(final_df)))
    col_dtypes = final_df.dtypes
    dtype_list = []
    for i, v in col_dtypes.items():
        if v == 'int64' or v == 'int32':
            dtype_t = i + ' INTEGER'
        elif v == 'float':
            dtype_t = i + ' DECIMAL(10,2)'
        else:  # v == 'object':
            max_len = measurer(final_df[i].values.astype(str)).max(axis=0)
            dtype_t = i + ' VARCHAR(' + str(max_len) + ')'
        dtype_list.append(dtype_t)
    table_columns = ','.join(dtype_list)
    strSQL_CreateTable = 'CREATE MULTISET TABLE LAB_BI.ACL, FALLBACK (' + table_columns + ') UNIQUE PRIMARY INDEX (UID);'
    cursor.execute(strSQL_CreateTable)

chunks_df = np.array_split(final_df, 100)
for i,_ in enumerate(chunks_df):
        data = [tuple(x) for x in chunks_df[i].to_records(index=False)]
        session.executemany("INSERT INTO LAB_BI.ACL values(?,?,?,?,?,?,?,?,?,?,?,?)",data,batch=True)

print('  XML Parse Complete.')
print('  ==================================')
end_time = str(dt.datetime.now().strftime(time_format))
print('    End time: ' + end_time)
st_time = dt.datetime.strptime(start_time, time_format)
en_time = dt.datetime.strptime(end_time, time_format)
diff = en_time - st_time
print('Elapsed Time: ' + str(diff))