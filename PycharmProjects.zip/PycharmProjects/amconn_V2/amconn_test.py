from mstrio import microstrategy  # <---- this imports the MSTR restapi

import amconn_V2 as amc

restapi_url = 'http://HOMSENWPRD01.amica.com:8080/MicroStrategyLibrary/api'
api_user = 't033270'
api_password = 'test'
project_id = '28B29F88423461E8F73511915E7FD9A2'
report_id = '9DADD1FC4E19A91AEC182A9FBE021DE1'  # '9DADD1FC4E19A91AEC182A9FBE021DE1' # QA - '9DADD1FC4E19A91AEC182A9FBE021DE1'
group_id = '022D56E1488CCDE025DCBDAEBDE977DC'

# amc.sendMail('abailon@amica.com', 'test subject', 'abailon@amica.com', 'test body')
# amc.sendMail_RestAPI('Claims Management Reporting', report_id, 'Test2')
# print(amc.get_usergroups
token, cookies = amc.conn_RestAPI(restapi_url, api_user, api_password)

x = amc.get_ObjectProperties(restapi_url, token, cookies, project_id, report_id)
print(x)
# this is the connection details
