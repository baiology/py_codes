# -*- coding: utf-8 -*-
"""
Created on Fri May 24 09:33:14 2019

@author: A17678
"""
import io
import json

import requests
import teradata
import getpass
import pyodbc
import pandas as pd
from mstrio import microstrategy
import smtplib as SMTP
from email.mime.text import MIMEText

conn = None
# results = None
# global PASSWORDST
# PASSWORDST = None
# username = getpass.getuser()
#
# def password():
#     '''gets password for use in all connections'''
#     password = None
#     global PASSWORDST
#
#     if (PASSWORDST == None):
#         password = getpass.getpass('Password: ')
#         PASSWORDST = password
#
#     return PASSWORDST

def MSTR_logout(url, auth_token, cookies):
    """
    Close all existing sessions for the authenticated user.
    :param connection: MicroStrategy REST API connection object
    :param verbose: Verbosity of request response; defaults to False
    :return: Complete HTTP response object
    """
    response = requests.post(url=url + '/auth/logout',
                             headers={'X-MSTR-AuthToken': auth_token},
                             cookies=cookies)
    return response

def queryTDTest(query):
    '''This module will connect, run, and return 1 query against TDTEST as a list of lists - provide username and query as string'''
    global conn
    with connectToTDTest() as session:
        # udaExec = teradata.UdaExec (appName="HelloWorld", version="1.0",
        #                           logConsole=False)

        # conn = udaExec.connect(method="odbc", dsn = "TDPROD", system="TDPROD",  port = "1025", authentication = "LDAP", username = username, password = getpass.getpass())

        # results = conn.execute(query)
        results = pd.read_sql(query, session)

        return results


def queryTDProd(query):
    '''This module will connect, run, and return 1 query against TDProd as a list of lists - provide username and query as string'''
    global conn
    with connectToTDProd() as session:
        results = pd.read_sql(query, session)

        return results


def connectToTDProd():
    '''connects to tdprod and returns connection'''

    global conn
    global username
    udaExec = teradata.UdaExec(appName="HelloWorld", version="1.0",
                               logConsole=False)

    conn = udaExec.connect(method="odbc", dsn="TDPROD", system="TDPROD", port="1025", authentication="LDAP",
                           username=username, password=password())

    return conn


def connectToTDTest():
    '''connects to tdtest and returns connection'''
    global conn
    global username

    username1 = getpass.getuser()
    udaExec = teradata.UdaExec(appName="HelloWorld", version="1.0",
                               logConsole=False)

    conn = udaExec.connect(method="odbc", dsn="TDTEST", system="TDTEST", port="1025", authentication="LDAP",
                           username=username, password=password())

    return conn


def executeTD(query, db):
    ''' executes query against td prod or test. requires string query and tdtest or tdprod as db string'''
    global conn
    global results
    db = db.lower
    if (db == 'tdtest'):
        with connectToTDTest() as session:
            results = pd.read_sql(query, session)

    elif (db == 'tdprod'):
        with connectToTDProd() as session:
            results = pd.read_sql(query, session)
    return results


def executeInd(query, values):
    global conn

    with connectToTDTest() as session:
        session.executemany(query, values, batch=False)
        # return results


def executemany(query, values):
    '''uses executemany function against teradata for inserting rows'''
    global conn

    with connectToTDTest() as session:
        session.executemany(query, values, batch=True)
        # return results


def close():
    global conn
    conn.close()


def queryPCClone(query):
    '''runs query against pc clone and returns dataframe'''
    server = 'HOSQLSNAP01\PCQUERY'
    db = 'pc_clone'

    with pyodbc.connect('DRIVER={SQL Server};SERVER=' + server + ';DATABASE=' + db + ';Trusted_Connection=yes',
                        autocommit=True) as session:
        cursor = session.cursor()
        cursor.execute(query)

        columnNames = [column[0] for column in cursor.description]
        columnTypes = [column[1] for column in cursor.description]

        results = pd.DataFrame.from_records(cursor.fetchall(), columns=columnNames)
    return results


def queryProvider(query):
    '''runs query against pc clone and returns dataframe'''
    server = 'LSCOREPRD\COREINST'
    db = 'serviceprovider'

    with pyodbc.connect('DRIVER={SQL Server};SERVER=' + server + ';DATABASE=' + db + ';Trusted_Connection=yes',
                        autocommit=True) as session:
        cursor = session.cursor()
        cursor.execute(query)

        columnNames = [column[0] for column in cursor.description]
        columnTypes = [column[1] for column in cursor.description]

        results = pd.DataFrame.from_records(cursor.fetchall(), columns=columnNames)
    return results


def queryVoice(query):
    '''runs query against pc clone and returns dataframe'''
    server = 'HOSQLININPRD01\GENESYS'
    db = 'IND_Amica_158GIC091'

    with pyodbc.connect('DRIVER={SQL Server};SERVER=' + server + ';DATABASE=' + db + ';Trusted_Connection=yes',
                        autocommit=True) as session:
        cursor = session.cursor()
        cursor.execute(query)

        columnNames = [column[0] for column in cursor.description]
        columnTypes = [column[1] for column in cursor.description]

        results = pd.DataFrame.from_records(cursor.fetchall(), columns=columnNames)
    return results


def queryBC(query):
    '''runs query against pc clone and returns dataframe'''
    server = 'HOSQLSNAP01\BCQUERY'
    db = 'BC_Clone'

    with pyodbc.connect('DRIVER={SQL Server};SERVER=' + server + ';DATABASE=' + db + ';Trusted_Connection=yes',
                        autocommit=True) as session:
        cursor = session.cursor()
        cursor.execute(query)

        columnNames = [column[0] for column in cursor.description]
        columnTypes = [column[1] for column in cursor.description]

        results = pd.DataFrame.from_records(cursor.fetchall(), columns=columnNames)
    return results


def queryMSTRAPPS(query):
    '''runs query against MSTRAPPS Prod and returns dataframe'''
    server = 'HOSQL14PRD01\MSTRAPPS'
    db = 'SCSDB'

    with pyodbc.connect('DRIVER={SQL Server};SERVER=' + server + ';DATABASE=' + db + ';Trusted_Connection=yes',
                        autocommit=True) as session:
        cursor = session.cursor()
        cursor.execute(query)

        columnNames = [column[0] for column in cursor.description]
        columnTypes = [column[1] for column in cursor.description]

        results = pd.DataFrame.from_records(cursor.fetchall(), columns=columnNames)
    return results


def mstrPUSH(dataset, name):
    '''creates connection to mstr dev api server, requires dataframe and dataset name (string)'''

    USERNAME = getpass.getuser()
    PASSWORD = password()

    conn = microstrategy.Connection(base_url="http://HOMSENWPRD01.amica.com:8080/MicroStrategyLibrary/api",
                                    username=USERNAME,
                                    password=PASSWORD,
                                    project_name="Policy Management Reporting")

    conn.connect()

    pushToMSTR = conn.create_dataset(dataset, dataset_name=name, table_name=name)
    conn.close()
    return pushToMSTR


def mstrUpdate(dataset, guid, name, update_type):
    '''creates connection to mstr dev api server, requires dataframe and dataset name (string)'''
    '''Update Policy - string object with the update operation to perform. One of 'add' (inserts new, unique rows), 'update'
(updates data in existing rows and columns), 'upsert' (updates existing
data and inserts new rows), 'replace' (similar to truncate and load, replaces the existing data with new data)'''

    # USERNAME = getpass.getuser()
    # PASSWORD = password()



    conn = microstrategy.Connection(base_url="http://HOMSENWPRD01.amica.com:8080/MicroStrategyLibrary/api",
                                    username="t17655",
                                    password="t17655",
                                    project_name="Policy Management Reporting")

    conn.connect()

    pushToMSTR = conn.update_dataset(dataset, guid, name, update_type)
    conn.close()
    return pushToMSTR


def mstrPULL(reportid):
    '''creates connection to mstr dev api server, requires dataframe and dataset name (string)'''
    # USERNAME = input("Enter username: ")
    # PASSWORD = password()
    # ID for MSTR report to pull





    conn = microstrategy.Connection(base_url="http://HOMSENWPRD01.amica.com:8080/MicroStrategyLibrary/api",
                                    username="t17655",
                                    password="t17655",
                                    project_name="Policy Management Reporting")
    # conn.login_mode = 16
    conn.connect()

    report = conn.get_report(report_id=reportid)
    conn.close()
    return report


def mstrPULLClaims(reportid):
    '''creates connection to mstr dev api server, requires dataframe and dataset name (string)'''
    USERNAME = input("Enter username: ")
    PASSWORD = password()
    # ID for MSTR report to pull





    conn = microstrategy.Connection(base_url="http://HOMSENWPRD01.amica.com:8080/MicroStrategyLibrary/api",
                                    username=USERNAME,
                                    password=PASSWORD,
                                    project_name="Claims Management Reporting")

    conn.connect()

    report = conn.get_report(report_id=reportid)
    conn.close()
    return report

def conn_RestAPI(url, username, password):
    response = requests.post(url + '/auth/login', data={'username': username, 'password': password, 'loginMode': 1})
    authToken = response.headers['X-MSTR-AuthToken']
    cookies = dict(response.cookies)
    return authToken, cookies

def get_ObjectProperties(url, authToken, cookies, project_id, guid):
    report_obj = requests.get(url + '/objects/' + guid + '?type=3',
                              headers={'X-MSTR-AuthToken': authToken, 'X-MSTR-ProjectID': project_id, 'id': guid},
                              cookies=cookies)
    return json.loads(report_obj.text)
    # report_name = report_json['name']


def sendMail(SENDER, SUBJECT, DESTINATION, body):
    SMTPserver = 'GW-SMTP.amica.com'
    sender = SENDER
    subject = SUBJECT
    destination = DESTINATION
    # password = gp.getpass('password: ')
    text_sub = 'plain'
    content = body

    msg = MIMEText(content, text_sub)
    msg['Subject'] = subject
    msg['From'] = sender  # some SMTP servers will do this automatically, not all

    with SMTP.SMTP(SMTPserver, 25) as conn:
        conn.set_debuglevel(False)

        conn.ehlo()
        conn.starttls()
        conn.helo()
        # conn.login(username, password)

        conn.sendmail(sender, destination, msg.as_string())

def get_ProjectID(project_name):
    '''get project ID based  on project name'''
    # USERNAME = input("Enter username: ")
    # PASSWORD = password()
    username = 't033270'
    password = 'test'

    conn = microstrategy.Connection(base_url="http://HOMSENWPRD01.amica.com:8080/MicroStrategyLibrary/api",
                                    username=username,
                                    password=password,
                                    project_name=project_name)
    conn.connect()
    project_id = conn.project_id
    conn.close()
    return project_id

def get_usergroups(url, authToken, cookies, usergroup_list):
    for usergroup in usergroup_list:
        usergroup_response = requests.get(url + '/usergroups', headers={'X-MSTR-AuthToken': authToken}, params={'nameBegins': usergroup_name, 'limit': -1},
                                      cookies=cookies)
    return json.loads(usergroup_response.text)

def sendMail_RestAPI(project_name, report_id, group_name):
    '''send report to user group'''
    # Variable
    str_io = io.StringIO()
    # project_name = "Claims Management Reporting"
    # report_id = '9DADD1FC4E19A91AEC182A9FBE021DE1'  # '9DADD1FC4E19A91AEC182A9FBE021DE1' # QA - '9DADD1FC4E19A91AEC182A9FBE021DE1'
    # group_id = '9C85683043584D67ABE75CA56A7C195B'
    project_id = get_ProjectID(project_name) # 'E37C06B844EC13D226F6428AF6133DEA'  # 'EE20C1884DA2A79F1366FD964FC668B6'
    username = 't033270'
    password = 'test'
    # subject = 'Email: '
    # Connect
    url = 'http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api'  # wcmsenwqa01, homsenwprd01

    response = requests.post(url + '/auth/login', data={'username': username, 'password': password, 'loginMode': 1})

    authToken = response.headers['X-MSTR-AuthToken']
    cookies = dict(response.cookies)
    # print("Token: " + authToken)

    # Get project
    proj_response = requests.get(url + '/projects',
                                 headers={'X-MSTR-AuthToken': authToken},
                                 cookies=cookies)
    # Content type
    content_type = proj_response.headers['content-type']

    # Report details
    report = requests.get(url + '/reports/' + report_id,
                          headers={'X-MSTR-AuthToken': authToken,
                                   'X-MSTR-ProjectID': project_id},
                          json={'reportId': report_id}, cookies=cookies)

    if report.ok == False:  # Error: (Unsupported template structure. Please check your design (only template metrics are allowed on column axis, for example).)
        err_msg_json = json.loads(report.text)
        err_msg = err_msg_json['message']
        print('Unable to extract data. \n' + err_msg)
    else:
        # Get Report Name
        r = report.json()
        report_name = r.get('name')

        # Get Report snd export to HTML
        # pd.options.display.float_format = '{:.0f}'.format
        # pd.options.display.float_format = '${:,.0f}'.format # dollar sign
        pd.options.display.float_format = '{:,.0f}'.format  # without dollar sign
        conn_TD = microstrategy.Connection(base_url=url, username=username, password=password,
                                           project_name=project_name)
        conn_TD.connect()
        # print('Connection established.')
        # print('Capturing the records from MSTR Project.')
        report_TD = conn_TD.get_report(report_id=report_id)
        report_str = report_TD.to_html(buf=str_io, classes='table table-striped', index=False)
        html_str = str_io.getvalue()
        # cwd = sys.path[0]  # Get current working directory
        # report_TD.to_csv(cwd + '/report.csv', index=False) # save to CSV

    # User Group Info details
    group_id_response = requests.get(url + '/usergroups',
                                headers={'X-MSTR-AuthToken': authToken},
                                     params={ 'nameBegins': "Test2",
                                         'limit': '-1'},
                                cookies=cookies)
    group_id_json = json.loads(group_id_response.text)
    group_id = group_id_json[0]['id']
    # group_info = requests.get(url + '/usergroups/' + group_id,
    #                           headers={'X-MSTR-AuthToken': authToken,
    #                                    'id': group_id}, cookies=cookies)
    #
    # group_info_json = json.loads(group_info.text)
    # group_name = group_info_json['name']

    # User Group Member details
    group_member = requests.get(url + '/usergroups/' + group_id + '/members',
                                headers={'X-MSTR-AuthToken': authToken,
                                         'id': group_id}, cookies=cookies)

    group_json = json.loads(group_member.text)
    group_members_list = []
    if type(group_json) is list:
        for j in group_json:
            group_members_list.append(j['id'])
    else:
        group_members_list.append(group_json['id'])

    user_guids = ','.join(group_members_list)
    # Email
    html = """
    <html>
    <head>
    <style>
      body {{font-family: Arial; font-size: 15px; }}
      table, th, td {{border: 1px solid black; border-collapse: collapse; }}
      th, td {{font-family: Arial; font-size: 15px; padding: 5px; }}
    </style>
    </head>
    <body><p>Hi {}, </p>
    <p>Report Name: {}</p>
    {}
    <p>Regards,</p>
    <p>MSTR Admin</p>
    </body></html>
    """

    html = html.format(group_name, report_name, html_str)  # recipient_name.split(',')[1]
    subject = 'Email: '+ str(report_name)
    head = {"X-MSTR-AuthToken": authToken}
    data = {"notificationType": "1", "userIds": group_members_list, "subject": subject, "content": html, "isHTML": True,
            "extraProperties": {}}
    send_email = requests.post(url + '/emails', json=data, headers=head, cookies=cookies)

    # print(send_email)

    MSTR_logout(url, authToken, cookies)
