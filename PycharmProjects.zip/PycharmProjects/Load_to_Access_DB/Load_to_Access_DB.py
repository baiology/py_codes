import pyodbc
import requests
import io
import pandas as pd
import json

import sys
from mstrio import microstrategy
# from mstrio.api import

def logout(url, auth_token, cookies):
    """
    Close all existing sessions for the authenticated user.
    :param connection: MicroStrategy REST API connection object
    :param verbose: Verbosity of request response; defaults to False
    :return: Complete HTTP response object
    """
    response = requests.post(url=url + '/auth/logout',
                             headers={'X-MSTR-AuthToken': auth_token},
                             cookies=cookies)
    return response

# Variable
str_io = io.StringIO()
report_id = '9DADD1FC4E19A91AEC182A9FBE021DE1' #'9DADD1FC4E19A91AEC182A9FBE021DE1' # QA - '9DADD1FC4E19A91AEC182A9FBE021DE1'
project_id = 'EE20C1884DA2A79F1366FD964FC668B6' #'EE20C1884DA2A79F1366FD964FC668B6'
project_name = "Claims Management Reporting_TD"
username = 't033270'
password = 'test'
subject = 'Email: '
# Connect
url = 'http://wcmsenwqa01.amica.com:8080/MicroStrategyLibrary/api' # wcmsenwqa01, homsenwprd01

# response = requests.post(url + '/auth/login', data={'username': 't033270', 'password': 'test', 'loginMode': 1})
#
# authToken = response.headers['X-MSTR-AuthToken']
# cookies = dict(response.cookies)
# print("Token: " + authToken)

# Get Report snd export to HTML
# pd.options.display.float_format = '{:.0f}'.format
# pd.options.display.float_format = '${:,.0f}'.format # dollar sign
conn_TD = microstrategy.Connection(base_url=url, username=username, password=password, project_name=project_name)
conn_TD.connect()
print('Connection established.')
print('Capturing the records from MSTR Project.')
report_TD = conn_TD.get_report(report_id=report_id)
# report_str = report_TD.to_html(buf=str_io, classes='table table-striped', index=False)
# html_str = str_io.getvalue()
cwd = sys.path[0]  # Get current working directory
report_TD.to_csv(cwd + '/report.txt', index=False, sep='|') # save to CSV

df = pd.read_csv(cwd + '/report.txt', sep='|', header=0)
df.columns = df.columns.str.lower()
df.columns = df.columns.str.strip()
df.columns = df.columns.str.replace(' ', '_')
df = df.add_prefix('d_')
header_list = df.columns.tolist()
column_defs_list_dtype = []
column_defs_list_nodtype = []
ctr = 0
for col in df.columns:
    isnan = df[col].isnull().all()
    strdType = df[col].dtype
    if strdType == 'O':
        max_len = df[col].map(lambda x: len(x)).max()
    if isnan:
        column_defs_list_dtype.append(header_list[ctr] + ' TEXT(1000)')
        column_defs_list_nodtype.append(header_list[ctr])
    else:
        if df[col].dtype == 'int64':
            column_defs_list_dtype.append(header_list[ctr] + ' INTEGER')
            column_defs_list_nodtype.append(header_list[ctr])
        elif df[col].dtype == 'float64':
            column_defs_list_dtype.append(header_list[ctr] + ' DOUBLE')
            column_defs_list_nodtype.append(header_list[ctr])
        else: # Text data type
            column_defs_list_dtype.append(header_list[ctr] + ' TEXT(' + str(max_len) + ')')
            column_defs_list_nodtype.append(header_list[ctr])
    ctr += 1

tbl_nm = 'test_tbl'
strFieldDefs = ','.join(column_defs_list_dtype)
strFieldDefs_NoDtype = ','.join(column_defs_list_nodtype)
connection_string = (
    'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};'
    'DBQ=' + cwd + '/test_db.accdb'
)
conn = pyodbc.connect(connection_string, autocommit=True)
cursor = conn.cursor()
if list(cursor.tables(tbl_nm)):
    cursor.execute("DROP TABLE " + tbl_nm)

strCreateDDL = 'CREATE TABLE ' + tbl_nm + ' (' + strFieldDefs + ')'
cursor.execute(strCreateDDL)
strQuestionMarkCount = ','.join(['?' for x in range(len(df.columns))])
strInsertDDL = 'INSERT INTO ' + tbl_nm + '(' + strFieldDefs_NoDtype + ') VALUES( ' + strQuestionMarkCount + ')'
cursor.executemany(strInsertDDL, df.itertuples(index=False))
conn.commit()
conn.close()
