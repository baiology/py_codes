import os

path = '\\\\HOFILE04\\USERS_M\T033270\Amica\\tasks\\04022019\\'
filelist = os.listdir(path)
for file in filelist:
    if file.endswith('sql'):
        cfile = path + file
        nfile = open(path + file.split('.')[0] + '.txt', 'w+', encoding="utf-8")
        ctr = 0
        with open(cfile) as fl:
            lines  = fl.readlines()
            for i in range(0, len(lines)):
                # if i != len(lines) -1:
                #     nxtline = lines[i + 1]
                # if nxtline != '\n':
                if (';insert' not in lines[i]) or ('[Analytical' not in lines[i]):
                    if lines[i] == '\n':
                        nfile.write(';\n')
                    else:
                        nfile.write(lines[i])
            fl.close()
        nfile.close()