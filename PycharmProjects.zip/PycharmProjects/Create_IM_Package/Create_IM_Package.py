import xml.dom.minidom as xml
import configparser
import datetime
import json
import os
import sys
import time
from tkinter import filedialog, messagebox
from tkinter.filedialog import askopenfilename
from tkinter.ttk import Notebook

import pandas as pd
from lxml import  etree
from xml.etree.ElementTree import Element, SubElement, tostring
from tkinter import *
# from tkinter.filedialog import askdirectory
# from tkinter import ttk
# import tkinter as tk
# from tkinter import messagebox

import requests


def checkFileAndDelete(fn):
    time_to_wait = 10
    time_counter = 0
    reachedLimit = False
    while not os.path.exists(fn):
        time.sleep(1)
        time_counter += 1
        if time_counter > time_to_wait:
            reachedLimit = True
            break
    if not reachedLimit:
        os.remove(fn)
    else:
        print('File not found.')

def createFile(PathFilename):
    crFile = open(PathFilename, "w+", encoding="ascii")
    return crFile

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

def find(name, path):
    result = []
    for root, dirs, files in os.walk(path):
        if name in files:
            result.append(os.path.join(root, name))
    return result

def openFile(btn):
    global fn
    # ftypes = [('All files', '*')]
    fn = askopenfilename(initialdir=cwd, title="Select file", filetypes=[("Excel files","*.xlsx")])
    print(fn)
    if btn == 1:
        EntReportListVar.set(fn)

def closeWindow():
    root.destroy()


# Main Program
def main_prog():
    # cwd = sys.path[0]  # Get current working directory
    st_time = time.time()
    curr_tab = tab_parent.index("current")
    if curr_tab == 0:
        strBaseServer = bEntServerVar.get()
        strBasePort = bEntPortVar.get()
        strBaseProject = bEntProjectVar.get()
        strBaseProjectGUID = bEntProjectGUIDVar.get()
        strTargetServer = tEntServerVar.get()
        strTargetPort = tEntPortVar.get()
        strTargetProject = tEntProjectVar.get()
        strTargetProjectGUID = tEntProjectGUIDVar.get()
    else:
        strBaseServer = bEntServerVar_SP.get()
        strBasePort = bEntPortVar_SP.get()
        strBaseProject = bEntProjectVar_SP.get()
        strBaseProjectGUID = bEntProjectGUIDVar_SP.get()
    # Common variables
    strOutputDir = EntOutputDirVar.get()
    strReportList = EntReportListVar.get()
    strMSTRURL = EntMSTRURLVar.get()
    strUsername = EntUsernameVar.get()
    strPassword = EntPasswordVar.get()

    print('Start time: ' + time.strftime("%H:%M:%S"))
    if curr_tab == 0:
        with open(cwd + '/template_proj_vs_proj.mtc') as pkg_temp:
            pkg_str = pkg_temp.read()
            pkg_str = pkg_str.replace('$$base_server$$', strBaseServer)
            pkg_str = pkg_str.replace('$$base_port$$', strBasePort)
            pkg_str = pkg_str.replace('$$base_project$$', strBaseProject)
            pkg_str = pkg_str.replace('$$base_project_guid$$', strBaseProjectGUID)
            pkg_str = pkg_str.replace('$$target_server$$', strTargetServer)
            pkg_str = pkg_str.replace('$$target_port$$', strTargetPort)
            pkg_str = pkg_str.replace('$$target_project$$', strTargetProject)
            pkg_str = pkg_str.replace('$$target_project_guid$$', strTargetProjectGUID)
            pkg_str = pkg_str.replace('$$outdir$$', strOutputDir)
    else:
        with open(cwd + '/template_single_project.mtc') as pkg_temp:
            pkg_str = pkg_temp.read()
            pkg_str = pkg_str.replace('$$base_server$$', strBaseServer)
            pkg_str = pkg_str.replace('$$base_port$$', strBasePort)
            pkg_str = pkg_str.replace('$$base_project$$', strBaseProject)
            pkg_str = pkg_str.replace('$$base_project_guid$$', strBaseProjectGUID)
            pkg_str = pkg_str.replace('$$outdir$$', strOutputDir)

    # create RestAPI token
    project_id = strBaseProjectGUID #Base Project GUID
    url = strMSTRURL  # wcmsenwqa01, homsenwprd01
    response = requests.post(url + '/auth/login', data={'username': strUsername, 'password': strPassword, 'loginMode': 1})
    authToken = response.headers['X-MSTR-AuthToken']
    cookies = dict(response.cookies)
    head = {"X-MSTR-AuthToken": authToken}


    # print(tostring(eTestable))
    # read report list
    df_report_list = pd.read_excel(strReportList)
    lst_Testables = []
    for index, row in df_report_list.iterrows():
        strGUID = row[1]
        report_obj = requests.get(url + '/objects/' + strGUID + '?type=3', headers={'X-MSTR-AuthToken': authToken, 'X-MSTR-ProjectID': project_id, 'id': strGUID}, cookies=cookies)
        if report_obj.ok:
            report_json = json.loads(report_obj.text)
        else:
            report_obj = requests.get(url + '/objects/' + strGUID + '?type=55', headers={'X-MSTR-AuthToken': authToken, 'X-MSTR-ProjectID': project_id, 'id': strGUID}, cookies=cookies)
            report_json = json.loads(report_obj.text)
        report_name = report_json['name']
        print(str(index + 1) + '. ' + report_name)
        type = report_json['type']
        report_type = report_json['subtype']
        path_json = report_json['ancestors']
        path = '\\'.join([x['name'] for x in path_json])

        # create the XML tag for the Testables
        eTestable = Element('Testable')
        eType = SubElement(eTestable, 'Type')
        eType.text = str(type)
        eType = SubElement(eTestable, 'GUID')
        eType.text = str(strGUID)
        eType = SubElement(eTestable, 'Name')
        eType.text = str(report_name)
        eType = SubElement(eTestable, 'Path')
        eType.text = str(path)
        eType = SubElement(eTestable, 'Rounds')
        eType.text = str(1)
        eType = SubElement(eTestable, 'Reporttype')
        eType.text = str(report_type)
        xml_str_tmp = etree.fromstring(tostring(eTestable, encoding='utf-8'))
        xml_str = etree.tostring(xml_str_tmp, pretty_print=True).decode()
        lst_Testables.append(xml_str)

    testables = '\n'.join(lst_Testables)
    pkg_str = pkg_str.replace('$$testables$$', testables)
    now = datetime.datetime.now()
    strDate = now.strftime("%m%d%Y_%H%M%S")
    if curr_tab == 0:
        pkg_file = createFile(cwd + '\\IM_Package_PVP_' + strDate + '.mtc')
    else:
        pkg_file = createFile(cwd + '\\IM_Package_SP_' + strDate + '.mtc')
    pkg_file.write(pkg_str)
    pkg_file.close()
    end_time = time.time()
    print('End time: ' + time.strftime("%H:%M:%S"))
    print('Elapsed Time: ' + printRuntime(end_time - st_time))
    messagebox.showinfo('IM Package Generation Complete', 'Successfully generated IM Package file. \nElapsed Time: ' + printRuntime(end_time - st_time))
    closeWindow()

# main_prog()

# --------------------------------------
# Windows GUI Creation
# --------------------------------------
cwd = sys.path[0]  # Get current working directory
root = Tk() # create the root window instance
root.title('Create IM Package') # add title to the window
root.resizable(0,0) # will disable the maximize button in the upper right window
canvas = Canvas(root, height=400, width=750) # create the window canvas/form
canvas.pack(side='top') # pack the form so that it will be visible

tab_parent = Notebook(root)
# Tabs
tab1 = Frame(tab_parent)
tab2 = Frame(tab_parent)
tab_parent.add(tab1, text='Project vs Project')
tab_parent.add(tab2, text='Single Project')
tab_parent.place(height=160, width=800, relx=0.02, rely=0.02)

# Frames
tab1_frame1 = Frame(tab1, relief=GROOVE, borderwidth=2)
tab1_frame1.place(height=120, width=350, relx=0.02, rely=0.10)
tab1_frame2 = Frame(tab1,  relief=GROOVE, borderwidth=2)
tab1_frame2.place(height=120, width=350, relx=0.47, rely=0.10)
tab2_frame1 = Frame(tab2, relief=GROOVE, borderwidth=2)
tab2_frame1.place(height=120, width=350, relx=0.02, rely=0.10)

#---------------------------------------------------- Base Frame PVP ----------------------------------------------------
# Base Title Group
bLblTitleVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
bLblTitle = Label(tab1, textvariable = bLblTitleVar)
bLblTitleVar.set('BASE')
bLblTitle.place(height=15, width=35, relx=0.20, rely=0.03)

# Server
bLblServerVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
bLblServer = Label(tab1_frame1, textvariable = bLblServerVar)
bLblServerVar.set('Server:')
bLblServer.place(height=20, width=35, relx=0.02, rely=0.06)
bEntServerVar = StringVar()
bEntServer = Entry(tab1_frame1, textvariable=bEntServerVar, bg='white')
bEntServer.place(height=20, width=250, relx=0.25, rely=0.06)
bEntServerVar.set('WCMSENIQA01')

# Port
bLblPortVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
bLblPort = Label(tab1_frame1, textvariable = bLblPortVar)
bLblPortVar.set('Port:')
bLblPort.place(height=20, width=25, relx=0.02, rely=0.29)
bEntPortVar = StringVar()
bEntPort = Entry(tab1_frame1, textvariable=bEntPortVar, bg='white')
bEntPort.place(height=20, width=250, relx=0.25, rely=0.29)
bEntPortVar.set('34952')

# Project
bLblProjectVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
bLblProject = Label(tab1_frame1, textvariable = bLblProjectVar)
bLblProjectVar.set('Project:')
bLblProject.place(height=20, width=40, relx=0.02, rely=0.52)
bEntProjectVar = StringVar()
bEntProject = Entry(tab1_frame1, textvariable=bEntProjectVar, bg='white')
bEntProject.place(height=20, width=250, relx=0.25, rely=0.52)
bEntProjectVar.set('Conversion / Policy Information Project_QA')

# Project GUID
bLblProjectGUIDVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
bLblProjectGUID = Label(tab1_frame1, textvariable = bLblProjectGUIDVar)
bLblProjectGUIDVar.set('Project GUID:')
bLblProjectGUID.place(height=20, width=70, relx=0.02, rely=0.75)
bEntProjectGUIDVar = StringVar()
bEntProjectGUID = Entry(tab1_frame1, textvariable=bEntProjectGUIDVar, bg='white')
bEntProjectGUID.place(height=20, width=250, relx=0.25, rely=0.75)
bEntProjectGUIDVar.set('854FCBF242D15F563315F1930C4B81B5')

#---------------------------------------------------- Target Frame ----------------------------------------------------
# Base Title Group
tLblTitleVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
tLblTitle = Label(tab1, textvariable = tLblTitleVar)
tLblTitleVar.set('TARGET')
tLblTitle.place(height=15, width=45, relx=0.65, rely=0.03)

# Server
tLblServerVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
tLblServer = Label(tab1_frame2, textvariable = tLblServerVar)
tLblServerVar.set('Server:')
tLblServer.place(height=20, width=35, relx=0.02, rely=0.06)
tEntServerVar = StringVar()
vEntServer = Entry(tab1_frame2, textvariable=tEntServerVar, bg='white')
vEntServer.place(height=20, width=250, relx=0.25, rely=0.06)
tEntServerVar.set('WCMSENIQA01')

# Port
tLblPortVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
tLblPort = Label(tab1_frame2, textvariable = tLblPortVar)
tLblPortVar.set('Port:')
tLblPort.place(height=20, width=25, relx=0.02, rely=0.29)
tEntPortVar = StringVar()
tEntPort = Entry(tab1_frame2, textvariable=tEntPortVar, bg='white')
tEntPort.place(height=20, width=250, relx=0.25, rely=0.29)
tEntPortVar.set('34952')

# Project
tLblProjectVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
tLblProject = Label(tab1_frame2, textvariable = tLblProjectVar)
tLblProjectVar.set('Project:')
tLblProject.place(height=20, width=40, relx=0.02, rely=0.52)
tEntProjectVar = StringVar()
tEntProject = Entry(tab1_frame2, textvariable=tEntProjectVar, bg='white')
tEntProject.place(height=20, width=250, relx=0.25, rely=0.52)
tEntProjectVar.set('Policy Management Reporting')

# Project GUID
tLblProjectGUIDVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
tLblProjectGUID = Label(tab1_frame2, textvariable = tLblProjectGUIDVar)
tLblProjectGUIDVar.set('Project GUID:')
tLblProjectGUID.place(height=20, width=70, relx=0.02, rely=0.75)
tEntProjectGUIDVar = StringVar()
tEntProjectGUID = Entry(tab1_frame2, textvariable=tEntProjectGUIDVar, bg='white')
tEntProjectGUID.place(height=20, width=250, relx=0.25, rely=0.75)
tEntProjectGUIDVar.set('0E7482C240C537EF56490082071477D0')

#---------------------------------------------------- Base Frame Single  Project ----------------------------------------------------
# Base Title Group
bLblTitleVar_SP = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
bLblTitle_SP = Label(tab2, textvariable = bLblTitleVar_SP)
bLblTitleVar_SP.set('BASE')
bLblTitle_SP.place(height=15, width=35, relx=0.20, rely=0.03)

# Server
bLblServerVar_SP = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
bLblServer_SP = Label(tab2_frame1, textvariable = bLblServerVar_SP)
bLblServerVar_SP.set('Server:')
bLblServer_SP.place(height=20, width=35, relx=0.02, rely=0.06)
bEntServerVar_SP = StringVar()
bEntServer_SP = Entry(tab2_frame1, textvariable=bEntServerVar_SP, bg='white')
bEntServer_SP.place(height=20, width=250, relx=0.25, rely=0.06)
bEntServerVar_SP.set('WCMSENIQA01')

# Port
bLblPortVar_SP = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
bLblPort_SP = Label(tab2_frame1, textvariable = bLblPortVar_SP)
bLblPortVar_SP.set('Port:')
bLblPort_SP.place(height=20, width=25, relx=0.02, rely=0.29)
bEntPortVar_SP = StringVar()
bEntPort_SP = Entry(tab2_frame1, textvariable=bEntPortVar_SP, bg='white')
bEntPort_SP.place(height=20, width=250, relx=0.25, rely=0.29)
bEntPortVar_SP.set('34952')

# Project
bLblProjectVar_SP = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
bLblProject_SP = Label(tab2_frame1, textvariable = bLblProjectVar_SP)
bLblProjectVar_SP.set('Project:')
bLblProject_SP.place(height=20, width=40, relx=0.02, rely=0.52)
bEntProjectVar_SP = StringVar()
bEntProject_SP = Entry(tab2_frame1, textvariable=bEntProjectVar_SP, bg='white')
bEntProject_SP.place(height=20, width=250, relx=0.25, rely=0.52)
bEntProjectVar_SP.set('Conversion / Policy Information Project_QA')

# Project GUID
bLblProjectGUIDVar_SP = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
bLblProjectGUID_SP = Label(tab2_frame1, textvariable = bLblProjectGUIDVar_SP)
bLblProjectGUIDVar_SP.set('Project GUID:')
bLblProjectGUID_SP.place(height=20, width=70, relx=0.02, rely=0.75)
bEntProjectGUIDVar_SP = StringVar()
bEntProjectGUID_SP = Entry(tab2_frame1, textvariable=bEntProjectGUIDVar_SP, bg='white')
bEntProjectGUID_SP.place(height=20, width=250, relx=0.25, rely=0.75)
bEntProjectGUIDVar_SP.set('854FCBF242D15F563315F1930C4B81B5')

#---------------------------- Common Objects ----------------------------

# Microstrategy RestAPI URL
lblMSTRURLVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
lblMSTRURL = Label(root, textvariable = lblMSTRURLVar)
lblMSTRURLVar.set('Microstrategy RestAPI URL:')
lblMSTRURL.place(height=20, width=150, relx=0.02, rely=0.41)
EntMSTRURLVar = StringVar()
EntMSTRURL= Entry(root, textvariable=EntMSTRURLVar, bg='white')
EntMSTRURL.place(height=20, width=550, relx=0.02, rely=0.48)
EntMSTRURLVar.set('http://wcmsenwqa01.amica.com:8080/MicroStrategyLibrary/api')

# Username and password
lblUsernameVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
lblUsename = Label(root, textvariable = lblUsernameVar)
lblUsernameVar.set('Username:')
lblUsename.place(height=20, width=60, relx=0.02, rely=0.55)
EntUsernameVar = StringVar()
EntUsername = Entry(root, textvariable=EntUsernameVar, bg='white')
EntUsername.place(height=20, width=100, relx=0.11, rely=0.55)
EntUsernameVar.set(os.environ.get('USERNAME'))

lblPasswordVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
lblPassword = Label(root, textvariable = lblPasswordVar)
lblPasswordVar.set('Password:')
lblPassword.place(height=20, width=60, relx=0.25, rely=0.55)
EntPasswordVar = StringVar()
EntPassword = Entry(root, show='*', textvariable=EntPasswordVar, bg='white')
EntPassword.place(height=20, width=200, relx=0.35, rely=0.55)
EntPasswordVar.set('')

# Output Directory
lblOutputDirVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
lblOutputDir = Label(root, textvariable = lblOutputDirVar)
lblOutputDirVar.set('IM Output Directory:')
lblOutputDir.place(height=20, width=120, relx=0.02, rely=0.62)
EntOutputDirVar = StringVar()
EntOutputDir = Entry(root, textvariable=EntOutputDirVar, bg='white')
EntOutputDir.place(height=20, width=550, relx=0.02, rely=0.68)
EntOutputDirVar.set(cwd)

# Report List
strReportListVar = StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
lblReportList = Label(root, textvariable = strReportListVar)
strReportListVar.set('Report List:')
lblReportList.place(height=20, width=60, relx=0.02, rely=0.74)
EntReportListVar = StringVar()
EntReportList = Entry(root, textvariable=EntReportListVar, bg='white')
EntReportList.place(height=20, width=550, relx=0.02, rely=0.80)
EntReportListVar.set('')

btnReportList = Button(root, text = "...", command=lambda: openFile(1))
btnReportList.place(height=21, width=50, relx=0.76, rely=0.80)

# Button Generate and Close
btnGenerate = Button(root, text = "Generate", command=main_prog)
btnGenerate.place(height=30, width=70, relx=0.30, rely=0.86)

btnClose = Button(root, text = "Close", command=closeWindow)
btnClose.place(height=30, width=70, relx=0.50, rely=0.86)

root.mainloop()