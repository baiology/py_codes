import datetime
import csv
import json
import subprocess
import os
import sys
import time
import pandas as pd
import lxml.etree
from tkinter.filedialog import askdirectory
import tkinter as tk
from tkinter import messagebox

def checkFileAndDelete(fn):
    time_to_wait = 10
    time_counter = 0
    reachedLimit = False
    while not os.path.exists(fn):
        time.sleep(1)
        time_counter += 1
        if time_counter > time_to_wait:
            reachedLimit = True
            break
    if not reachedLimit:
        os.remove(fn)
    else:
        print('File not found.')

def createFile(PathFilename):
    crFile = open(PathFilename, "w+", encoding="utf-8")
    return crFile

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

def find(name, path):
    result = []
    for root, dirs, files in os.walk(path):
        if name in files:
            result.append(os.path.join(root, name))
    return result

def openFile(btn):
    global fn
    # ftypes = [('All files', '*')]
    fn = askdirectory()
    print(fn)
    if btn == 1:
        vEntFile1.set(fn)
    else:
        vEntFile2.set(fn)

def closeWindow():
    root.destroy()

def recursive_iter(obj):
    if isinstance(obj, dict):
        for item in obj.values():
            yield from recursive_iter(item)
    elif any(isinstance(obj, t) for t in (list, tuple)):
        for item in obj:
            yield from recursive_iter(item)
    else:
        yield obj

def recursive_iter_keys(obj, keys=()):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from recursive_iter(v, keys + (k,))
    elif any(isinstance(obj, t) for t in (list, tuple)):
        for idx, item in enumerate(obj):
            yield from recursive_iter(item, keys + (idx,))
    else:
        yield keys, obj

# data = json.loads(my_json_data)
# Main Program
def main_prog():
    cwd = sys.path[0]  # Get current working directory
    st_time = time.time()
    # strSourceDir = vEntFile1.get()
    # strOutDir = vEntFile2.get()
    print('Start time: ' + time.strftime("%H:%M:%S"))
    with open(cwd + '/test.json', 'r') as json_file:
        json_load = json.load(json_file)

    for record in json_load['records']:
        for keys, item in recursive_iter_keys(record):
            print(keys, item)
    for item in recursive_iter(json_load['records'][0]):
        print(item)

    lst_Data = []
    for record in json_load:
        obj = json_load[record]
        # if type(obj).__name__ == 'list':
            # for x in obj:
                # do until type(obj).__name__ == 'list':
        print(obj)
        # lst_row = []
        # lst_row.append(record['Id'])
        # lst_row.append(record['Subject'])
        # lst_row.append(record['ActivityDate'])
        # lst_row.append(record['CreatedDate'])
        # lst_row.append(record['Status'])
        # lst_Data.append(lst_row)
        # for next_layer in record['attributes']:
        #     print(next_layer['type'])

    df = pd.DataFrame(lst_Data, columns=['RecID', 'Subject', 'Activity Date', 'Created Date', 'Status'])
    df.to_csv(cwd + '/output.csv', sep=',', encoding='utf-8', index=False)
    end_time = time.time()
    print('End time: ' + time.strftime("%H:%M:%S"))
    print('Elapsed Time: ' + printRuntime(end_time - st_time))
    # if len(lstParseError) == 0:
    #     messagebox.showinfo('IM Summary Generation Complete', 'Successfully generated IM Result Summary report. \nElapsed Time: ' + printRuntime(end_time - st_time))
    # else:
    #     messagebox.showinfo('IM Summary Generation Complete', 'Successfully generated IM Result Summary report. \nElapsed Time: ' + printRuntime(end_time - st_time) + '\n\n The following folder(s) were not parsed due to invalid XML or missing tag: \n' + '\n'.join(lstParseError))
    # closeWindow()

# --------------------------------------
# Windows GUI Creation
# --------------------------------------
main_prog()
# cwd = sys.path[0]  # Get current working directory
# root = tk.Tk() # create the root window instance
# root.title('IM Summary Report') # add title to the window
# root.resizable(0,0) # will disable the maximize button in the upper right window
# canvas = tk.Canvas(root, height=100, width=500) # create the window canvas/form
# canvas.pack(side='top') # pack the form so that it will be visible
#
# # File 1
# btnFile1 = tk.Button(root, text = "...", command=lambda: openFile(1)) # create the button for browsing folder
# btnFile1.place(height=20, width=50, relx=0.85, rely=0.10) # place the button to the window using the relx and rely positioning
#
# var = tk.StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
# lblFile1 = tk.Label(root, textvariable = var)
# var.set('Source Folder: ')
# lblFile1.place(height=20, width=100, relx=0.02, rely=0.10)
#
# vEntFile1 = tk.StringVar()
# entFile1 = tk.Entry(root, textvariable=vEntFile1, bg='white')
# entFile1.place(height=20, width=320, relx=0.20, rely=0.10)
# vEntFile1.set(cwd)
#
# # File 2
# btnFile2 = tk.Button(root, text = "...", command=lambda: openFile(2))
# btnFile2.place(height=20, width=50, relx=0.85, rely=0.35)
#
# var = tk.StringVar()
# lblFile2 = tk.Label(root, textvariable = var)
# var.set('Output Folder: ')
# lblFile2.place(height=20, width=100, relx=0.02, rely=0.35)
#
# vEntFile2 = tk.StringVar()
# entFile2 = tk.Entry(root, textvariable=vEntFile2, bg='white')
# entFile2.place(height=20, width=320, relx=0.20, rely=0.35)
# vEntFile2.set(cwd)
#
# # Button Generate and Close
# btnCompare = tk.Button(root, text = "Generate", command=main_prog)
# btnCompare.place(height=30, width=70, relx=0.30, rely=0.60)
#
# btnClose = tk.Button(root, text = "Close", command=closeWindow)
# btnClose.place(height=30, width=70, relx=0.50, rely=0.60)
#
# root.mainloop()