import datetime
import csv
import os
import sys
import time
import pandas as pd
import tkinter as tk
from subprocess import Popen, PIPE
from subprocess import check_output as qx
from tkinter.filedialog import askdirectory
from tkinter import filedialog
from tkinter import messagebox

def createFile(PathFilename):
    crFile = open(PathFilename, "w+", encoding="utf-8")
    return crFile

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

def find(name, path):
    result = []
    for root, dirs, files in os.walk(path):
        if name in files:
            result.append(os.path.join(root, name))
    return result

def openFile(btn):
    global fn
    # ftypes = [('All files', '*')]
    # fn = filedialog.askopenfilename(initialdir='/', title='Select file', filetypes=(('Text', '*.txt'), ('CSV', '*.csv')))
    fn = askdirectory()
    print(fn)
    if btn == 1:
        vEntFile1.set(fn)
    else:
        vEntFile2.set(fn)

def closeWindow():
    root.destroy()

def create_TPT_File_And_Load(inputfolder, db, tptfilepath):
    with open(cwd + '/tpt_template.txt') as tpt_temp:
        tpt_str = tpt_temp.read()
        # Read each file in a folder
        for file in os.listdir(inputfolder):
            file_path = os.path.normpath(os.path.join(inputfolder, file))
            print('--------------------------------------------------------------------------------------')
            print('Processing Input File: ' + file_path)
            print('--------------------------------------------------------------------------------------')
            table_name = os.path.splitext(file)[0].upper()
            tpt_file = createFile(cwd + '\\' + table_name + '.tpt')
            tpt_file_path = os.path.normpath(cwd + '\\' + table_name + '.tpt')
            if file.endswith('.txt') or file.endswith('.csv'):
                with open(file_path) as in_file:
                    headers = in_file.readlines()[0].strip()
                    header_list = headers.split(',')

                    # create the item schema
                    item_schema= ', \n'.join([x + ' VARCHAR(3000)' for x in header_list]) # item schema

                    # create the create table SQL statement
                    df_csv = pd.read_csv(file_path)
                    # null_cols = df_csv.columns[df_csv.isnull().all()]
                    # print(''.join(null_cols))
                    ctr = 0
                    column_defs_list_dtype = []
                    column_defs_list_nodtype = []
                    column_defs_list_nodtype_colon = []
                    for col in df_csv.columns:
                        isnan = df_csv[col].isnull().all()
                        if df_csv[col].dtype == 'O':
                            max_len = df_csv[col].map(lambda x: len(x)).max()
                        if isnan:
                            column_defs_list_dtype.append(header_list[ctr] + ' VARCHAR(1000)')
                        else:
                            if df_csv[col].dtype == 'int64':
                                column_defs_list_dtype.append(header_list[ctr] + ' INTEGER')
                            else:
                                column_defs_list_dtype.append(header_list[ctr] + ' VARCHAR(' + str(max_len) + ')')
                        column_defs_list_nodtype.append(header_list[ctr])
                        column_defs_list_nodtype_colon.append(':' + header_list[ctr])
                        ctr += 1
                    table_def_dtype = ', \n'.join(column_defs_list_dtype)
                    table_def_nodtype = ', \n'.join(column_defs_list_nodtype)
                    table_def_nodtype_colon = ', \n'.join(column_defs_list_nodtype_colon)
                    db_and_table = db.upper() + '.' + table_name
                    create_table_sql = '(\'CREATE MULTISET TABLE ' + db_and_table + '\n(\n' + table_def_dtype.upper() + '\n);\')'
                    insert_sql = '\'INSERT INTO ' + db_and_table + '\n(\n' + table_def_nodtype.upper() + '\n)\nVALUES\n(\n' + table_def_nodtype_colon.upper() + '\n);\''

            # replace text in TPT template
            drop_table_sql = '(\'DROP TABLE ' + db_and_table + '\'),\n' \
                            '(\'DROP TABLE ' + db_and_table + '_UV\'),\n' \
                            '(\'DROP TABLE ' + db_and_table + '_ET1\'),\n' \
                            '(\'DROP TABLE ' + db_and_table + '_ET2\'),\n' \
                            '(\'DROP TABLE ' + db_and_table + '_WT\'),\n'
            tpt_str = tpt_str.replace('<item_schema>', item_schema)
            tpt_str = tpt_str.replace('<privatelogname>', db_and_table + '.log')
            tpt_str = tpt_str.replace('<filename>', file_path)
            tpt_str = tpt_str.replace('<delimiter>', ',')
            tpt_str = tpt_str.replace('<skiprows>', '1')
            tpt_str = tpt_str.replace('<logmech>', 'ldap')
            tpt_str = tpt_str.replace('<target_table>', db_and_table)
            tpt_str = tpt_str.replace('<log_table>', db_and_table + '_UV')
            tpt_str = tpt_str.replace('<target_table>', db_and_table)
            tpt_str = tpt_str.replace('<target_db>', db)
            tpt_str = tpt_str.replace('<err_table1>', db_and_table + '_ET1')
            tpt_str = tpt_str.replace('<err_table2>', db_and_table + '_ET2')
            tpt_str = tpt_str.replace('<drop_table>', drop_table_sql)
            tpt_str = tpt_str.replace('<create_table>', create_table_sql)
            tpt_str = tpt_str.replace('<insert_table>', insert_sql)
            tpt_file.write(tpt_str)
            tpt_file.close()

            # Run the TPT file using TBUILD utility command
            # tptfilepath = "'" + tptfilepath + '\\tbuild.exe' + "'"
            tpt_file_path = '"' + tpt_file_path + '"'
            # p = Popen(["ping","-W","2","-c", "1", "192.168.0.1"], stdout=PIPE)
            # p = Popen([tptfilepath], stdin=PIPE, stdout=PIPE, stderr=PIPE, shell=True)
            # p = Popen(tptfilepath)
            spath = tptfilepath + '\\tbuild.exe -f ' + tpt_file_path
            output = qx(spath)
            lines = output.splitlines()
            # output = p.communicate()[0].decode('utf8').strip()
            # err = p.communicate()[1].decode('utf8').strip()
            # rc = p.returncode
            print(lines)

def Load_To_SQL_Server(inputfolder, db):
    # Read each file in a folder
    for file in os.listdir(inputfolder):
        file_path = os.path.normpath(os.path.join(inputfolder, file))
        print('--------------------------------------------------------------------------------------')
        print('Processing Input File: ' + file_path)
        print('--------------------------------------------------------------------------------------')
        table_name = os.path.splitext(file)[0].upper()
        if file.endswith('.txt') or file.endswith('.csv'):
            with open(file_path) as in_file:
                headers = in_file.readlines()[0].strip()
                header_list = headers.split(',')
                # create the create table SQL statement
                df_csv = pd.read_csv(file_path)
                ctr = 0
                column_defs_list_dtype = []
                column_defs_list_nodtype = []
                column_defs_list_nodtype_colon = []
                for col in df_csv.columns:
                    isnan = df_csv[col].isnull().all()
                    if df_csv[col].dtype == 'O':
                        max_len = df_csv[col].map(lambda x: len(x)).max()
                    if isnan:
                        column_defs_list_dtype.append(header_list[ctr] + ' VARCHAR(1000)')
                    else:
                        if df_csv[col].dtype == 'int64':
                            column_defs_list_dtype.append(header_list[ctr] + ' INTEGER')
                        else:
                            column_defs_list_dtype.append(
                                header_list[ctr] + ' VARCHAR(' + str(max_len) + ')')
                    column_defs_list_nodtype.append(header_list[ctr])
                    column_defs_list_nodtype_colon.append(':' + header_list[ctr])
                    ctr += 1
                table_def_dtype = ', \n'.join(column_defs_list_dtype)
                table_def_nodtype = ', \n'.join(column_defs_list_nodtype)
                table_def_nodtype_colon = ', \n'.join(column_defs_list_nodtype_colon)
                db_and_table = db.upper() + '.' + table_name
                create_table_sql = '(\'CREATE MULTISET TABLE ' + db_and_table + '\n(\n' + table_def_dtype.upper() + '\n);\')'
                insert_sql = '\'INSERT INTO ' + db_and_table + '\n(\n' + table_def_nodtype.upper() + '\n)\nVALUES\n(\n' + table_def_nodtype_colon.upper() + '\n);\''

        # replace text in TPT template
        drop_table_sql = '(\'DROP TABLE ' + db_and_table + '\'),\n' \
                                                           '(\'DROP TABLE ' + db_and_table + '_UV\'),\n' \
                                                                                             '(\'DROP TABLE ' + db_and_table + '_ET1\'),\n' \
                                                                                                                               '(\'DROP TABLE ' + db_and_table + '_ET2\'),\n' \
                                                                                                                                                                 '(\'DROP TABLE ' + db_and_table + '_WT\'),\n'


# Main Program
def main_prog():
    st_time = time.time()
    strInputFilePath = vEntFile1.get()
    strTPTFilePath = vEntFile2.get()
    strDB = vEntDB.get()
    create_TPT_File_And_Load(strInputFilePath, strDB, strTPTFilePath)
    if os.path.isdir(strInputFilePath): # if Directory
        # do this
        print(strInputFilePath)
    else:
        # do this
        print(strInputFilePath)

    strDatabase = listVar.get()
    print('Start time: ' + time.strftime("%H:%M:%S"))

    end_time = time.time()
    print('End time: ' + time.strftime("%H:%M:%S"))
    print('Elapsed Time: ' + printRuntime(end_time - st_time))
    messagebox.showinfo('Data Load Complete', 'Successfully loaded data to ' + strDatabase + ' database.\nElapsed Time: ' + printRuntime(end_time - st_time))
    closeWindow()

# -------------------------------------------------------------------------------------------------- #
# -------------------------------------- Windows GUI Creation -------------------------------------- #
# -------------------------------------------------------------------------------------------------- #
cwd = sys.path[0]  # Get current working directory
root = tk.Tk() # create the root window instance
root.title('Data Load:') # add title to the window
root.resizable(0,0) # will disable the maximize button in the upper right window
canvas = tk.Canvas(root, height=150, width=500) # create the window canvas/form
canvas.pack(side='top') # pack the form so that it will be visible

#====================== Input File ======================#
var = tk.StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
lblFile1 = tk.Label(root, textvariable = var)
var.set('Input Folder: ')
lblFile1.place(height=20, width=100, relx=0.02, rely=0.10)

vEntFile1 = tk.StringVar()
entFile1 = tk.Entry(root, textvariable=vEntFile1, bg='white')
entFile1.place(height=20, width=320, relx=0.20, rely=0.10)

btnFile1 = tk.Button(root, text = "...", command=lambda: openFile(1)) # create the button for browsing folder
btnFile1.place(height=20, width=50, relx=0.85, rely=0.10) # place the button to the window using the relx and rely positioning

#====================== TPT Path ======================#
varTPT = tk.StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
lblFileTPT = tk.Label(root, textvariable = varTPT)
varTPT.set('TPT File Path: ')
lblFileTPT.place(height=20, width=100, relx=0.02, rely=0.27)

vEntFile2 = tk.StringVar()
entFile2 = tk.Entry(root, textvariable=vEntFile2, bg='white')
entFile2.place(height=20, width=320, relx=0.20, rely=0.27)

btnFile2 = tk.Button(root, text = "...", command=lambda: openFile(2)) # create the button for browsing folder
btnFile2.place(height=20, width=50, relx=0.85, rely=0.27) # place the button to the window using the relx and rely positioning

#====================== Dropdown list box ======================#
varDD = tk.StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
lblFileDD = tk.Label(root, textvariable = varDD)
varDD.set('Target Database: ')
lblFileDD.place(height=30, width=100, relx=0.01, rely=0.44)

list = ['Teradata', 'SQL Server']
listVar = tk.StringVar()
listVar.set(list[0])
dropdown = tk.OptionMenu(root, listVar, *list)
dropdown.place(height=30, width=100, relx=0.20, rely=0.44)

varDB = tk.StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
lblFileDB = tk.Label(root, textvariable = varDB)
varDB.set('Database Name: ')
lblFileDB.place(height=20, width=100, relx=0.40, rely=0.44)

vEntDB = tk.StringVar()
entDB = tk.Entry(root, textvariable=vEntDB, bg='white')
entDB.place(height=20, width=120, relx=0.60, rely=0.44)


# Button Generate and Close
btnCompare = tk.Button(root, text = "Load Data", command=main_prog)
btnCompare.place(height=30, width=70, relx=0.30, rely=0.70)

btnClose = tk.Button(root, text = "Close", command=closeWindow)
btnClose.place(height=30, width=70, relx=0.50, rely=0.70)

root.mainloop()