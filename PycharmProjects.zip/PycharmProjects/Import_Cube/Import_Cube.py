import base64
import json

import requests
from mstrio import microstrategy
import os
import sys
import time
import datetime
import pandas as pd
import numpy as np
global datasetId
table_name = 'Speed_Car_Table'
'Functions'
#### Get token ###
def login(base_url, api_login, api_password):
    print("Getting token...")
    data_get = {'username': api_login,
                'password': api_password,
                'loginMode': 1}
    r = requests.post(base_url + 'auth/login', data=data_get)
    if r.ok:
        authToken = r.headers['X-MSTR-AuthToken']
        cookies = dict(r.cookies)
        print("Token: " + authToken)
        return authToken, cookies
    else:
        print("HTTP %i - %s, Message %s" % (r.status_code, r.reason, r.text))


def get_sessions(base_url, auth_token, cookies):
    print("Checking session...")
    header_gs = {'X-MSTR-AuthToken': auth_token,
                 'Accept': 'application/json'}
    r = requests.get(base_url + "sessions", headers=header_gs, cookies=cookies)
    if r.ok:
        print("Authenticated...")
        print(r)
        print("HTTP %i - %s, Message %s" % (r.status_code, r.reason, r.text))
    else:
        print("HTTP %i - %s, Message %s" % (r.status_code, r.reason, r.text))


def create_cube(base_url, auth_token, cookies, project_id, cube_structure_json):
    global datasetId
    headers_cc = {'X-MSTR-AuthToken': auth_token,
                  'Content-Type': 'application/json',  # IMPORTANT!
                  'Accept': 'application/json',
                  'X-MSTR-ProjectID': project_id}
    print("\nCreating new cube...")
    r = requests.post(base_url + "/datasets", headers=headers_cc, data=cube_structure_json, cookies=cookies)
    if r.ok:
        datasetId = r.json()['datasetId']
        print("Error: " + str(r.raise_for_status()) + "   ||   HTTP Status Code: " + str(r.status_code))
        print("\nCube CREATED successfully")
        print("\nCube ID:     " + r.json()['datasetId'])
        print("Cube Name:   " + r.json()['name'])
        print("Table ID:    " + r.json()['tables'][0]['id'])
        print("Table Name:  " + r.json()['tables'][0]['name'])
        # print(
        #     "\nRemember to copy and note down Cube ID (dataset ID) and Table ID. Enter those values in the Python script 'Parameters' section")
    else:
        print("HTTP %i - %s, Message %s" % (r.status_code, r.reason, r.text))

def push_data(updatePolicy, pushed_data_json, auth_token, cookies, project_id, datasetId, tableId):
    pushed_data = base64.b64encode(bytes(pushed_data_json, 'utf-8')).decode('ascii')
    push_url = base_url + "/datasets/" + datasetId + "/tables/" + tableId
    headers_push = {'X-MSTR-AuthToken': auth_token,
                    'Content-Type': 'application/json',#IMPORTANT!
                    'X-MSTR-ProjectID': project_id,
                    'updatePolicy': updatePolicy
                    }
    insert_data = ('{"name":"Speed_Car_Table",'
                   '"columnHeaders":['
                   '{"name": "Timestamp","dataType": "DATETIME"},'
                   '{"name": "Id_Run","dataType": "STRING"},'
                   '{"name": "Id_Measure_W","dataType": "DOUBLE"},'
                   '{"name": "Id_Measure","dataType": "DOUBLE"},'
                   '{"name": "Driver_Id","dataType": "DOUBLE"},'
                   '{"name": "Accel_X","dataType": "DOUBLE"},'
                   '{"name": "Accel_Y","dataType": "DOUBLE"},'
                   '{"name": "Accel_Z","dataType": "DOUBLE"},'
                   '{"name": "Gyro_X","dataType": "DOUBLE"},'
                   '{"name": "Gyro_Y","dataType": "DOUBLE"},'
                   '{"name": "Gyro_Z","dataType": "DOUBLE"},'
                   '{"name": "Humidity","dataType": "DOUBLE"},'
                   '{"name": "Pitch","dataType": "DOUBLE"},'
                   '{"name": "Pressure","dataType": "DOUBLE"},'
                   '{"name": "Roll","dataType": "DOUBLE"},'
                   '{"name": "Temp_H","dataType": "DOUBLE"},'
                   '{"name": "Yaw","dataType": "DOUBLE"}'
                   '],"data":"' + pushed_data + '"}'
                   )
    print("\nPushing data...")
    r = requests.patch(push_url, headers=headers_push, data=insert_data, cookies=cookies)
    if r.ok:
        print("Pushed successfully...")
        print("HTTP %i - %s, Message %s" % (r.status_code, r.reason, r.text))
    else:
        print("HTTP %i - %s, Message %s" % (r.status_code, r.reason, r.text))


base_url = "http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api"
src_project_name = "Conversion / Policy Information Project"
src_project_ID = '2A60D5374240B5AE416F36A5B6E6A252'
src_cube_ID = 'C071077E4B82BAB1DCE2C59EC68A6EF6'
target_project_name = "Policy Management Reporting"
target_project_ID = 'AF9F62054258210C513AD4A7BC50F277'
import_to_folder = '0B0246E3452B88BCA27698B93E33DB72'
api_login = 't033270'
api_password = 'test'
table_name = 'Speed_Car_Table'

oall_start = time.time()
'Create directory by date if not exist'
cwd = sys.path[0]
# Get authorization details
response = requests.post(base_url + '/auth/login', data={'username': api_login, 'password': api_password, 'loginMode': 1})
authToken = response.headers['X-MSTR-AuthToken']
cookies = dict(response.cookies)

conn_source = microstrategy.Connection(base_url=base_url, username=api_login, password=api_password, project_name=src_project_name)
conn_source.connect()
# df_space = conn_source.get_cube('B5707882427E6045E87FA4AC526F5DFE')
# print(df_space)
start = time.time()
# cube_source = conn_source.create_dataset()
# cube_structure_json = cube_source.to_json()
conn_source.close()
# Get the source cube details
cube_details_resp = requests.get(base_url + '/cubes/' + src_cube_ID,
                                headers={'X-MSTR-AuthToken': authToken,
                                        'X-MSTR-ProjectID': src_project_ID,
                                        'cubeId': src_cube_ID},
                                 cookies=cookies)
cube_details_json = json.loads(cube_details_resp.text)
cube_name = cube_details_json['name']
# Attributes
cube_attribs_list = cube_details_json['result']['definition']['availableObjects']['attributes']
attribute_names_dtypes_list = []
for attribs in cube_attribs_list:
    attrib_name = attribs['name']
    attrib_datatype = attribs['forms'][0]['dataType']
    attribute_names_dtypes_list.append(attrib_name + ',' + attrib_datatype)
# Metrics
cube_metrics_list = cube_details_json['result']['definition']['availableObjects']['metrics']
metric_names_dtypes_list = []
for metrics in cube_metrics_list:
    metric_name = metrics['name']
    metric_datatype = 'Double'
    metric_names_dtypes_list.append(metric_name + ',' + metric_datatype)
columnheaders_list = attribute_names_dtypes_list + metric_names_dtypes_list
columnheaders_list = list(dict.fromkeys(columnheaders_list))

# cube_struct_json = '{"name":"' + cube_name + '",' + '"tables":[{"data":"' + cube_name + '",' + '"name":"' + cube_name + '",' + '"columnHeaders": ['
cube_structure_json = '{"name":"SpeedCarCube1","tables":[{"data":"e30=","name":"Speed_Car_Table","columnHeaders":[{"name":"Timestamp","dataType":"DATETIME"},{"name":"Id_Run","dataType":"STRING"},{"name":"Id_Measure_W","dataType":"DOUBLE"},{"name":"Id_Measure","dataType":"DOUBLE"},{"name":"Driver_Id","dataType":"DOUBLE"},{"name":"Accel_X","dataType":"DOUBLE"},{"name":"Accel_Y","dataType":"DOUBLE"},{"name":"Accel_Z","dataType":"DOUBLE"},{"name":"Gyro_X","dataType":"DOUBLE"},{"name":"Gyro_Y","dataType":"DOUBLE"},{"name":"Gyro_Z","dataType":"DOUBLE"},{"name":"Humidity","dataType":"DOUBLE"},{"name":"Pitch","dataType":"DOUBLE"},{"name":"Pressure","dataType":"DOUBLE"},{"name":"Roll","dataType":"DOUBLE"},{"name":"Temp_H","dataType":"DOUBLE"},{"name":"Yaw","dataType":"DOUBLE"}]}],"metrics":[{"name":"Accel_X","dataType":"DOUBLE","expressions":[{"formula":"Speed_Car_Table.Accel_X"}]},{"name":"Accel_Y","dataType":"DOUBLE","expressions":[{"formula":"Speed_Car_Table.Accel_Y"}]},{"name":"Accel_Z","dataType":"DOUBLE","expressions":[{"formula":"Speed_Car_Table.Accel_Z"}]},{"name":"Gyro_X","dataType":"DOUBLE","expressions":[{"formula":"Speed_Car_Table.Gyro_X"}]},{"name":"Gyro_Y","dataType":"DOUBLE","expressions":[{"formula":"Speed_Car_Table.Gyro_Y"}]},{"name":"Gyro_Z","dataType":"DOUBLE","expressions":[{"formula":"Speed_Car_Table.Gyro_Z"}]},{"name":"Humidity","dataType":"DOUBLE","expressions":[{"formula":"Speed_Car_Table.Humidity"}]},{"name":"Pitch","dataType":"DOUBLE","expressions":[{"formula":"Speed_Car_Table.Pitch"}]},{"name":"Pressure","dataType":"DOUBLE","expressions":[{"formula":"Speed_Car_Table.Pressure"}]},{"name":"Roll","dataType":"DOUBLE","expressions":[{"formula":"Speed_Car_Table.Roll"}]},{"name":"Temp_H","dataType":"DOUBLE","expressions":[{"formula":"Speed_Car_Table.Temp_H"}]},{"name":"Yaw","dataType":"DOUBLE","expressions":[{"formula":"Speed_Car_Table.Yaw"}]}],"attributes":[{"name":"Timestamp","attributeForms":[{"category":"ID","expressions":[{"formula":"Speed_Car_Table.Timestamp"}],"dataType":"STRING"}]},{"name":"Id_Run","attributeForms":[{"category":"ID","expressions":[{"formula":"Speed_Car_Table.Id_Run"}],"dataType":"STRING"}]},{"name":"Id_Measure_W","attributeForms":[{"category":"ID","expressions":[{"formula":"Speed_Car_Table.Id_Measure_W"}],"dataType":"DOUBLE"}]},{"name":"Id_Measure","attributeForms":[{"category":"ID","expressions":[{"formula":"Speed_Car_Table.Id_Measure"}],"dataType":"DOUBLE"}]},{"name":"Driver_Id","attributeForms":[{"category":"ID","expressions":[{"formula":"Speed_Car_Table.Driver_Id"}],"dataType":"DATETIME"}]}],"folderId": "' + import_to_folder + '"}'
# Create cube
conn_target = microstrategy.Connection(base_url=base_url, username=api_login, password=api_password, project_name=target_project_name)
conn_target.connect()
create_cube(base_url, conn_target.auth_token, conn_target.cookies, target_project_ID, cube_structure_json)
# Push data to cube
sample_data = '[{"Timestamp": "10/5/2017 7:28:10 PM","Id_Run": "RESET","Id_Measure_W": 1,"Id_Measure": 1,"Driver_Id": 1234,"Accel_X": 0.02546,"Accel_Y": 0.09226,"Accel_Z": 0.97747,"Gyro_X": -0.0123,"Gyro_Y": 0.01709,"Gyro_Z": 0.00736,"Humidity": 38.81998,"Pitch": 358.58579,"Pressure": 980.43262,"Roll": 5.39072,"Temp_H": 34.27213,"Yaw": 67.82173},{"Timestamp": "10/5/2017 7:28:20 PM","Id_Run": "RESET","Id_Measure_W": 2,"Id_Measure": 2,"Driver_Id": 1234,"Accel_X": 0.09999,"Accel_Y": 0.09226,"Accel_Z": 0.97747,"Gyro_X": -0.0123,"Gyro_Y": 0.01709,"Gyro_Z": 0.00736,"Humidity": 38.81998,"Pitch": 358.58579,"Pressure": 980.43262,"Roll": 5.39072,"Temp_H": 34.27213,"Yaw": 67.82173}])'
sample_data_l = [{"Timestamp": "10/5/2017 7:28:10 PM","Id_Run": "RESET","Id_Measure_W": 1,"Id_Measure": 1,"Driver_Id": 1234,"Accel_X": 0.02546,"Accel_Y": 0.09226,"Accel_Z": 0.97747,"Gyro_X": -0.0123,"Gyro_Y": 0.01709,"Gyro_Z": 0.00736,"Humidity": 38.81998,"Pitch": 358.58579,"Pressure": 980.43262,"Roll": 5.39072,"Temp_H": 34.27213,"Yaw": 67.82173},{"Timestamp": "10/5/2017 7:28:20 PM","Id_Run": "RESET","Id_Measure_W": 2,"Id_Measure": 2,"Driver_Id": 1234,"Accel_X": 0.09999,"Accel_Y": 0.09226,"Accel_Z": 0.97747,"Gyro_X": -0.0123,"Gyro_Y": 0.01709,"Gyro_Z": 0.00736,"Humidity": 38.81998,"Pitch": 358.58579,"Pressure": 980.43262,"Roll": 5.39072,"Temp_H": 34.27213,"Yaw": 67.82173}]
sample_datb = json.dumps(sample_data_l)


# sample_data = "'" + str(sample_data_t) + "'"
# df_test = pd.DataFrame(sample_data)
print(datasetId)
push_data('Replace', sample_data, conn_target.auth_token, conn_target.cookies, target_project_ID, datasetId, table_name)