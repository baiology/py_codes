import pyodbc
import pandas as pd
from mstrio import microstrategy

# Variables - TO CHANGE
# ==================================================================================
sql_statement = "select line_of_business from DMSD2V_CLM_MSTR.d_line_of_business where line_of_business not in ('HOMEOWNERS','AUTOMOBILE')"
odbc_dsn64bit = 'TDTest64'
# ==================================================================================
def mstrPUSH(dataset, name):
    '''creates connection to mstr dev api server, requires dataframe and dataset name (string)'''


    USERNAME = 't033270'
    PASSWORD = 'test'



    conn = microstrategy.Connection(base_url = "http://HOMSENWPRD01.amica.com:8080/MicroStrategyLibrary/api",
                                    username = USERNAME,
                                    password = PASSWORD,
                                    project_name = "Policy Management Reporting")

    conn.connect()




    pushToMSTR = conn.create_dataset( dataset, dataset_name = name, table_name = name )
    conn.close()
    return pushToMSTR

def mstrUpdate(dataset, guid, name, update_type):
    '''creates connection to mstr dev api server, requires dataframe and dataset name (string)'''
    '''Update Policy - string object with the update operation to perform. One of 'add' (inserts new, unique rows), 'update'
(updates data in existing rows and columns), 'upsert' (updates existing
data and inserts new rows), 'replace' (similar to truncate and load, replaces the existing data with new data)'''

    USERNAME = 't033270'
    PASSWORD = 'test'
    conn = microstrategy.Connection(base_url = "http://HOMSENWPRD01.amica.com:8080/MicroStrategyLibrary/api",
                                    username = USERNAME,
                                    password = PASSWORD,
                                    project_name = "Policy Management Reporting")
    conn.connect()
    pushToMSTR = conn.update_dataset( dataset,  guid,   name ,update_type )
    conn.close()
    return pushToMSTR

# conn = pyodbc.connect('DSN=' + odbc_dsn64bit + ';Trusted_Connection=yes')
# df_data = pd.read_sql(sql_statement, conn)
# sample_data = [{"Timestamp": "10/5/2017 7:28:10 PM","Id_Run": "RESET","Id_Measure_W": 1,"Id_Measure": 1,"Driver_Id": 1234,"Accel_X": 0.02546,"Accel_Y": 0.09226,"Accel_Z": 0.97747,"Gyro_X": -0.0123,"Gyro_Y": 0.01709,"Gyro_Z": 0.00736,"Humidity": 38.81998,"Pitch": 358.58579,"Pressure": 980.43262,"Roll": 5.39072,"Temp_H": 34.27213,"Yaw": 67.82173}]
sample_data = [{"Timestamp": "12/6/2019 7:28:10 PM","Id_Run": "RESET","Id_Measure_W": 1,"Id_Measure": 1,"Driver_Id": 1234,"Accel_X": 0.02546,"Accel_Y": 0.09226,"Accel_Z": 0.97747,"Gyro_X": -0.0123,"Gyro_Y": 0.01709,"Gyro_Z": 0.00736,"Humidity": 38.81998,"Pitch": 358.58579,"Pressure": 980.43262,"Roll": 5.39072,"Temp_H": 34.27213,"Yaw": 67.82173},{"Timestamp": "10/5/2017 7:28:20 PM","Id_Run": "RESET","Id_Measure_W": 2,"Id_Measure": 2,"Driver_Id": 1234,"Accel_X": 0.09999,"Accel_Y": 0.09226,"Accel_Z": 0.97747,"Gyro_X": -0.0123,"Gyro_Y": 0.01709,"Gyro_Z": 0.00736,"Humidity": 38.81998,"Pitch": 358.58579,"Pressure": 980.43262,"Roll": 5.39072,"Temp_H": 34.27213,"Yaw": 67.82173}]
df_test = pd.DataFrame(sample_data)
# df_test = df_test[['Driver_Id','Id_Measure','Id_Measure_W','Id_Run','Timestamp']]
# df_test = df_test[['Driver_Id','Id_Measure','Id_Measure_W','Id_Run','Timestamp','Accel_X','Accel_Y','Accel_Z','Gyro_X','Gyro_Y','Gyro_Z','Humidity','Pitch','Pressure','Roll','Temp_H','Yaw']]
# mstrPUSH(df_test, 'SpeedCarCube1')
mstrUpdate(df_test, 'B5707882427E6045E87FA4AC526F5DFE', 'SpeedCarCube1', 'upsert')
# print(df_test)

