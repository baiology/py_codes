# Import modules
import datetime
import time
import os
import sys
from tkinter.filedialog import askopenfilename

import pandas as pd
import configparser
import math
import tkinter as tk

fn = ''
# --------------------------------------
# Function Definitions
# --------------------------------------
def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

def createFolder(cwd):
    now = datetime.datetime.now()
    strDate = now.strftime("%m%d%Y_%H%M%S")
    outPath = cwd + "\\" + strDate
    if not os.path.exists(outPath):
        os.makedirs(outPath)
    return outPath

def createFile(PathFilename):
    crFile = open(PathFilename, "w+", encoding="utf-8")
    return crFile

def openFile(btn):
    global fn
    ftypes = [('All files', '*')]
    fn = askopenfilename(initialdir="/", filetypes =ftypes, title = "Choose a file.")
    print(fn)
    if btn == 1:
        vEntFile1.set(fn)
    else:
        vEntFile2.set(fn)

def fileCompare():
    # --------------------------------------
    # File Compare
    # --------------------------------------
    tr_start = time.time()
    print('Start time: ' + time.strftime("%H:%M:%S"))
    # Get current working directory
    cwd = sys.path[0]  # Get current working directory
    outPath = createFolder(cwd)
    # Main program
    config = configparser.ConfigParser()
    config.sections()
    config.read(cwd + "/file_list.txt")
    # file1 = config['DEFAULT']['file1']
    file1 = vEntFile1.get()
    # file2 = config['DEFAULT']['file2']
    file2 = vEntFile2.get()
    # delim = config['DEFAULT']['delim']
    delim = varEntDelim.get()
    # pkey = config['DEFAULT']['key']
    pkey = varEntPK.get()

    # Create mismatch file
    str_MM_FileName = outPath + '\\MM_' + ''.join(os.path.splitext(os.path.basename(file1))[0]) + '.txt'
    fl_Mismatch = createFile(str_MM_FileName)
    fl_Summary = createFile(outPath + '\\Cube_Compare_Summary.txt')

    x = 0
    df_LEFT = pd.read_csv(file1, sep=delim, header=None, dtype='unicode')
    df_RIGHT = pd.read_csv(file2, sep=delim, header=None, dtype='unicode')
    df_LEFT.columns = df_LEFT.iloc[0]  # Get the columns from the 1st index
    df_LEFT.columns = df_LEFT.columns.str.strip()  # Remove extra spaces on both ends
    df_LEFT.columns = df_LEFT.columns.str.replace(' ', '_')  # Replace space in between strings with underscofe ('_')

    df_RIGHT.columns = df_RIGHT.iloc[0]
    df_RIGHT.columns = df_RIGHT.columns.str.strip()  # Remove extra spaces on both ends
    df_RIGHT.columns = df_RIGHT.columns.str.replace(' ', '_')  # Replace space in between strings with underscofe ('_')

    df_LEFT = df_LEFT[1:]  # Set the initial/start value from the second index
    df_RIGHT = df_RIGHT[1:]  # Set the initial/start value from the second index

    df_LEFT.reset_index(drop=True, inplace=True)
    df_RIGHT.reset_index(drop=True, inplace=True)

    pkeys = []
    if pkey.find(',') != -1:
        pkeys = pkey.split(',')
    else:
        pkeys.append(pkey)

    pkeys = [x.replace(' ', '_') for x in pkeys]  # Replace all spaces to underscore

    col_index_LEFT = []
    for key in pkeys:
        col_index_LEFT.append(df_LEFT.columns.get_loc(key))

    x = 0
    lstMismatchValues = []
    for row_LEFT in df_LEFT.itertuples():
        df_RIGHT.index = pd.RangeIndex(len(df_RIGHT.index))  # reset indices
        left_PKs = []
        left_PKs_str = []
        for col_idx in col_index_LEFT:
            left_PKs.append(row_LEFT[col_idx + 1])
            left_PKs_str.append(str(row_LEFT[col_idx + 1]))

        sql = [str(pkeys[idx]) + ' == ' + "'" + str(left_PKs[idx]) + "'" for idx, val in enumerate(pkeys)]
        sqlval = ' & '.join(sql)
        row_RIGHT_Val = df_RIGHT.query(sqlval)
        if len(row_RIGHT_Val) == 0:
            strError = 'Record: ' + ''.join(left_PKs_str)
        else:
            row_LEFT_Val = df_LEFT.iloc[x]  # Get the row values from LEFT data, 1 row at a time
            lstVal_LEFT = [v for v in row_LEFT_Val]  # Put the values in a List
            lstVal_RIGHT = [v for v in row_RIGHT_Val.iloc[0]]  # Put the values in a List
            if lstVal_LEFT == lstVal_RIGHT:
                strMatchStat = True
            else:
                strMatchStat = False
                y = 0
                columns_RIGHT = [x for x in df_RIGHT.columns]
                for val_LEFT in lstVal_LEFT:  # Get value comparison status per field.
                    val_RIGHT = lstVal_RIGHT[y]
                    try:
                        isNAN = math.isnan(val_LEFT) and math.isnan(val_RIGHT)
                    except:
                        isNAN = False
                    val_PKs = ','.join(left_PKs_str)
                    if val_LEFT != val_RIGHT and not isNAN:
                        lstMismatchValues.append(
                            val_PKs + ',' + str(columns_RIGHT[y]) + ',' + str(val_LEFT) + ',' + str(val_RIGHT))
                    y += 1
        x += 1
    fl_Mismatch.write(','.join(pkeys) + ',' + 'Mismatch Column' + ',' + 'SYSDM Value' + ',' + 'TD Value' + '\n')
    fl_Mismatch.write('\n'.join(lstMismatchValues))
    fl_Mismatch.close()
    end_time = time.time()
    print('Elapsed Time: ' + printRuntime(end_time - tr_start))
    print('End time: ' + time.strftime("%H:%M:%S"))

def closeWindow():
    root.destroy()
# --------------------------------------
# Windows GUI Creation
# --------------------------------------

root = tk.Tk()
canvas = tk.Canvas(root, height=140, width=500)
canvas.pack(side='top')

# File 1
btnFile1 = tk.Button(root, text = "Browse", command=lambda: openFile(1))
btnFile1.place(height=20, width=50, relx=0.85, rely=0.05)

var = tk.StringVar()
lblFile1 = tk.Label(root, textvariable = var)
var.set('File 1: ')
lblFile1.place(height=20, width=50, relx=0.02, rely=0.05)

vEntFile1 = tk.StringVar()
entFile1 = tk.Entry(root, textvariable=vEntFile1, bg='white')
entFile1.place(height=20, width=350, relx=0.13, rely=0.05)

# File 2
btnFile2 = tk.Button(root, text = "Browse", command=lambda: openFile(2))
btnFile2.place(height=20, width=50, relx=0.85, rely=0.23)

var = tk.StringVar()
lblFile2 = tk.Label(root, textvariable = var)
var.set('File 2: ')
lblFile2.place(height=20, width=50, relx=0.02, rely=0.23)

vEntFile2 = tk.StringVar()
entFile2 = tk.Entry(root, textvariable=vEntFile2, bg='white')
entFile2.place(height=20, width=350, relx=0.13, rely=0.23)

# Delimiter
varDelim = tk.StringVar()
lblDelim = tk.Label(root, textvariable = varDelim)
varDelim.set('Delimiter: ')
lblDelim.place(height=20, width=60, relx=0.02, rely=0.41)

varEntDelim = tk.StringVar()
entDelim = tk.Entry(root, textvariable=varEntDelim, bg='white')
entDelim.place(height=20, width=340, relx=0.15, rely=0.41)

# Primary Key
varPK = tk.StringVar()
lblPK = tk.Label(root, textvariable = varPK)
varPK.set('Primary Key(s): ')
lblPK.place(height=20, width=90, relx=0.02, rely=0.59)

varEntPK = tk.StringVar()
entPK = tk.Entry(root, textvariable=varEntPK, bg='white')
entPK.place(height=20, width=310, relx=0.21, rely=0.59)


# Button Compare and Close
btnCompare = tk.Button(root, text = "Compare", command=fileCompare)
btnCompare.place(height=30, width=70, relx=0.30, rely=0.76)

btnClose = tk.Button(root, text = "Close", command=closeWindow)
btnClose.place(height=30, width=70, relx=0.50, rely=0.76)



root.mainloop()