import csv
import datetime
import glob
import configparser
import os
import sys
import time
import pandas as pd
from chardet import detect


def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg
# --------------------------------------
# Function to convert the file to UTF-8
# --------------------------------------
def convert_encoding_type(srcfile, trgfile):
    with open(srcfile, 'rb') as f:
        rawdata = f.read()
        from_codec = detect(rawdata)['encoding']

    # add try: except block for reliability
    try:
        with open(srcfile, 'r', encoding=from_codec) as f, open(trgfile, 'w+', encoding='utf-8') as e:
            text = f.read() # for small files, for big use chunks
            e.write(text)
        os.remove(srcfile) # remove old encoding file
        os.rename(trgfile, srcfile) # rename new encoding
    except UnicodeDecodeError:
        print('Decode Error')
    except UnicodeEncodeError:
        print('Encode Error')

# Main Program
def main_prog():
    cwd = sys.path[0]  # Get current working directory
    # --------------------------------------
    # Parse config.txt file and get the values.
    # --------------------------------------
    config = configparser.RawConfigParser()
    config.read(cwd + "/Config.txt")
    in_directory = config.get("Default", "input_directory")
    st_time = time.time()
    print('Start time: ' + time.strftime("%H:%M:%S"))
    # --------------------------------------
    # Get all the CSV files from the  input folder.
    # --------------------------------------
    in_files = glob.glob(in_directory + '/*.csv')
    # --------------------------------------
    # Check if no CS file found, close the script.
    # --------------------------------------
    if len(in_files) == 0: print('No csv files found.'); sys.exit(0)
    rangeLines_tmp = []
    # --------------------------------------
    # Loop through each filein in_files list
    # --------------------------------------
    for in_file in in_files:
        # --------------------------------------
        # Before reading and processing the, file, we need  to convert the file first using the function convert_encoding_type
        # --------------------------------------
        convert_encoding_type(in_file, in_directory + '/Converted_File.csv')
        # --------------------------------------
        # Open the converted file and parse the contents.
        # --------------------------------------
        with open(in_file, mode='r', encoding="utf-8", errors='ignore') as f_input:
            index = 0
            st_idx = 0
            end_idx = 0
            # --------------------------------------
            # Loop through each line of the file and check where the line and end index of strings "Enabked User" and "Disabled User"
            # --------------------------------------
            for line in f_input:
                if line.strip() == 'Enabled Users':
                    st_idx = index + 1
                if line.strip() == 'Disabled Users':
                    end_idx = index - 1
                    break
                index += 1
            f_input.seek(0,0) # Reset the index after reading all lines so that it will start from 0 index in the next file.
            # --------------------------------------
            # Will get the start and end line data based on start and end index and put it into the list.
            # --------------------------------------
            rangeLines_tmp.append(f_input.readlines()[st_idx:end_idx])
    rangeLines = []
    # --------------------------------------
    # Read each line in the list
    # --------------------------------------
    for line1 in rangeLines_tmp:
        for line2 in line1:
            rangeLines.append(line2) # Add each list value into a list
    csv_data = csv.reader(rangeLines, delimiter=',') # Read the list using csv reader and put it into csv_data variable
    # --------------------------------------
    # Create a dataframe based on the list we created above.
    # --------------------------------------
    df = pd.DataFrame(csv_data, columns=['License Type', 'Enabled Users'])
    df.columns = df.iloc[0]
    df = df[1:]
    df.columns = df.columns.str.replace(' ', '_')
    now = datetime.datetime.now()
    strDate = now.strftime("%m%d%Y_%H%M%S")
    # --------------------------------------
    # Assign values for each column in a dataframe
    # --------------------------------------
    df['AID'] = df['Enabled_Users'].str.extract(r"\((.*?)\)", expand=False)
    df['Enabled_Users'] = df['Enabled_Users'].str.replace(r'\(.*\)', '')
    df['Cnt'] = '1'
    df['License_Mgr_Run_TS'] = strDate
    # --------------------------------------
    # Create a filter for users where Enabled User != "-"
    # --------------------------------------
    df_final = df.query('Enabled_Users != "-"')
    # --------------------------------------
    # Save to csv
    # --------------------------------------
    df_final.to_csv(cwd + '/Step1_Auditing_report.csv', header=True, index=False, encoding='utf-8')
    end_time = time.time()
    print('End time: ' + time.strftime("%H:%M:%S"))
    print('Elapsed Time: ' + printRuntime(end_time - st_time))
main_prog()