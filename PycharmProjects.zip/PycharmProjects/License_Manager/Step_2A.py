import sys
import configparser
import pyodbc
import pandas as pd
import datetime
import time
import teradata

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

cwd = sys.path[0]  # Get current working directory
st_time = time.time()
print('Start time: ' + time.strftime("%H:%M:%S"))
# --------------------------------------
# Parse Config.txt and extract the values.
# --------------------------------------
config = configparser.RawConfigParser()
config.read(cwd + "/Config.txt")
td_username = config.get('Default', 'TD_username')
td_password = config.get('Default', 'TD_password')
# --------------------------------------
# Get the SQL file to use when running the SQL statement.
# --------------------------------------
strSTep2A_Query = ' '.join(open(cwd + '/Part2A_TD_Active_Employees.sql').readlines())
# --------------------------------------
# Connect to Teradata database
# --------------------------------------
TD_conn = pyodbc.connect('DSN=TDTest64;uid=' + td_username + ';pwd=' + td_password) # UID=' + uname + ';PWD=' + pwd)
# --------------------------------------
# Extract the results and put it into the datafrane variable.
# --------------------------------------
df = pd.read_sql(strSTep2A_Query, TD_conn)
# --------------------------------------
# Save result to CSV file.
# --------------------------------------
df.to_csv(cwd + '/Step2A_TD_Active_emp.csv', sep=',', encoding='utf-8', index=False)
TD_conn.close
end_time = time.time()
print('End time: ' + time.strftime("%H:%M:%S"))
print('Elapsed Time: ' + printRuntime(end_time - st_time))
