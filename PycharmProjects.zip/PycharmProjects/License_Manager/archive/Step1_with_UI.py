import datetime
import csv
import glob
import subprocess
import os
import sys
import time
import pandas as pd
import lxml.etree
from tkinter.filedialog import askdirectory, askopenfilename
import tkinter as tk
from tkinter import messagebox

def checkFileAndDelete(fn):
    time_to_wait = 10
    time_counter = 0
    reachedLimit = False
    while not os.path.exists(fn):
        time.sleep(1)
        time_counter += 1
        if time_counter > time_to_wait:
            reachedLimit = True
            break
    if not reachedLimit:
        os.remove(fn)
    else:
        print('File not found.')

def createFile(PathFilename):
    crFile = open(PathFilename, "w+", encoding="utf-8")
    return crFile

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

def find(name, path):
    result = []
    for root, dirs, files in os.walk(path):
        if name in files:
            result.append(os.path.join(root, name))
    return result

def openFile(btn):
    global fn
    # ftypes = [('All files', '*')]
    # fn = askdirectory()
    fn = askopenfilename(initialdir=cwd,
                           filetypes =(("CSV File", "*.csv"),),
                           title = "Choose a file."
                           )
    print(fn)
    if btn == 1:
        vEntFile1.set(fn)

def closeWindow():
    root.destroy()

# Main Program
def main_prog():
    # cwd = sys.path[0]  # Get current working directory
    st_time = time.time()
    # strSourceDir = vEntFile1.get()
    # strOutDir = vEntFile2.get()
    print('Start time: ' + time.strftime("%H:%M:%S"))
    # files = glob.glob(fn)
    if len(entFile1.get()) != 0:
        with open(entFile1.get(), 'r') as f_input:
            lst_lines = []
            index = 0
            st_idx = 0
            end_idx = 0
            for line in f_input:
                if line.strip() == 'Enabled Users':
                    st_idx = index + 1
                if line.strip() == 'Disabled Users':
                    end_idx = index - 1
                    break
                index += 1
            f_input.seek(0,0)
            rangeLines = f_input.readlines()[st_idx:end_idx]
            csv_data = csv.reader(rangeLines, delimiter=',')
            df = pd.DataFrame(csv_data, columns=['License Type', 'Enabled Users'])
            df.columns = df.iloc[0]
            df = df[1:]
            # df['AID'] = df['Enabled Users']
            df['AID'] = df['Enabled Users'].str.extract(r"\((.*?)\)", expand=False)
            df['Enabled Users'] = df['Enabled Users'].str.replace(r'\(.*\)', '')
            df['Cnt'] = '1'

            now = datetime.datetime.now()
            strDate = now.strftime("%m%d%Y_%H%M%S")
            df.to_csv(cwd + '/Step1_Auditing_report.csv', header=True, index=False, encoding='utf-8')
        end_time = time.time()
        print('End time: ' + time.strftime("%H:%M:%S"))
        print('Elapsed Time: ' + printRuntime(end_time - st_time))
        messagebox.showinfo('License Manager Report Complete', 'Successfully generated License Manager Summary report. \nElapsed Time: ' + printRuntime(end_time - st_time))
        closeWindow()
    else:
        messagebox.showinfo('File not found', 'File not selected.')


# main_prog()
# --------------------------------------
# Windows GUI Creation
# --------------------------------------
fn = ''
cwd = sys.path[0]  # Get current working directory
root = tk.Tk() # create the root window instance
root.title('IM Summary Report') # add title to the window
root.resizable(0,0) # will disable the maximize button in the upper right window
canvas = tk.Canvas(root, height=100, width=500) # create the window canvas/form
canvas.pack(side='top') # pack the form so that it will be visible

# File 1
btnFile1 = tk.Button(root, text = "...", command=lambda: openFile(1)) # create the button for browsing folder
btnFile1.place(height=20, width=50, relx=0.85, rely=0.10) # place the button to the window using the relx and rely positioning

var = tk.StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
lblFile1 = tk.Label(root, textvariable = var)
var.set('Input File: ')
lblFile1.place(height=20, width=100, relx=0.02, rely=0.10)

vEntFile1 = tk.StringVar()
entFile1 = tk.Entry(root, textvariable=vEntFile1, bg='white')
entFile1.place(height=20, width=320, relx=0.20, rely=0.10)
vEntFile1.set('')

# Button Generate and Close
btnCompare = tk.Button(root, text = "Generate", command=main_prog)
btnCompare.place(height=30, width=70, relx=0.30, rely=0.60)

btnClose = tk.Button(root, text = "Close", command=closeWindow)
btnClose.place(height=30, width=70, relx=0.50, rely=0.60)

root.mainloop()