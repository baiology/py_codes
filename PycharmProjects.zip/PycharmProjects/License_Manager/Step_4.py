import os
import sys
import pandas as pd
import time

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

cwd = sys.path[0]  # Get current working directory
st_time = time.time()
print('Start time: ' + time.strftime("%H:%M:%S"))
# --------------------------------------
# Load 3 CSV files and put it into a variable
# --------------------------------------
step2A_fn = cwd + '/Step2A_TD_Active_emp.csv'
step2B_fn = cwd + '/Step2B_MSTR_EntMgr.csv'
# --------------------------------------
# Extract and put values in a dataframe.
# --------------------------------------
df_step2a = pd.read_csv(step2A_fn)
df_step2b = pd.read_csv(step2B_fn)
# --------------------------------------
# Merge and left join using AID as the joining key
# --------------------------------------
df_final = df_step2a[~df_step2a['AID'].isin(df_step2b['AID'])]
xlsxFile = os.path.normpath(cwd + '\\Step4_Final.xlsx')
# --------------------------------------
# Export the output to an excel file.
# --------------------------------------
writer = pd.ExcelWriter(xlsxFile, engine='xlsxwriter')
df_final.to_excel(writer, 'Step_4', index=False)
writer.save()
end_time = time.time()
print('End time: ' + time.strftime("%H:%M:%S"))
print('Elapsed Time: ' + printRuntime(end_time - st_time))