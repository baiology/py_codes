import configparser
import sys
import pyodbc
import pandas as pd
import time

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

cwd = sys.path[0]  # Get current working directory
st_time = time.time()
print('Start time: ' + time.strftime("%H:%M:%S"))
# --------------------------------------
# Parse Config.txt and extract the values.
# --------------------------------------
config = configparser.RawConfigParser()
config.read(cwd + "/Config.txt")
SQLSS_Server = config.get("Default", 'server_sqls')
SQLSS_DB = config.get('Default', 'db_sqls')
# --------------------------------------
# Get the SQL file to use when running the SQL statement.
# --------------------------------------
strQueryUser_SQLSS = ''.join(open(cwd + '/Part2B_MSTR_EntMgr.sql').readlines())
# --------------------------------------
# Connect to SQL Server database
# --------------------------------------
conn_SQLSS = pyodbc.connect('Driver={SQL Server};' +
                      'Server=' + SQLSS_Server + ';' +
                      'Database=' + SQLSS_DB + ';' +
                      'Trusted_Connection=yes;')
# --------------------------------------
# Extract the results and put it into the datafrane variable.
# --------------------------------------
result_SQLSS = pd.read_sql(strQueryUser_SQLSS, conn_SQLSS)
# --------------------------------------
# Save result to CSV file.
# --------------------------------------
result_SQLSS.to_csv(cwd + '/Step2B_MSTR_EntMgr.csv', sep=',', encoding='utf-8', index=False)
end_time = time.time()
print('End time: ' + time.strftime("%H:%M:%S"))
print('Elapsed Time: ' + printRuntime(end_time - st_time))
