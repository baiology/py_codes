select
a.em_user_abbrev as AID,
--a.EM_USER_NAME,
--A.EM_USER_DESC,
/* wjxbfs1 user_active_ind,
"User Last First Name (ID)" ,
"User Email (ID)",
"User Job Title (ID)" ,
"User Job Group (ID)" ,
"User Branch (ID)" ,
"Business Area (ID)" ,
case 
when a.em_user_abbrev in ( 'A12868','A12984','A9280','A5535','A3263','A5925','A12616','A2096') then 'Claims' 
when a.em_user_abbrev in ( 'A1786') then 'Underwriting' 
when a.em_user_abbrev in ( 'A3636') then 'CIS' 
when a.em_user_abbrev in ( 'A10192') then 'CIS' 
when a.em_user_abbrev in ('VisixMstratSVC') then 'Claims'
when a.em_user_abbrev in ( 'CSI') then 'CIS' 
when a.em_user_abbrev in ( 'A15955','A15661','A14092') then 'Claims' 
when a.em_user_abbrev in ( 'A1786') then 'Actuary' 
else "Business Area Revised (ID)"
end "Business Area Revised (ID)" , */
convert(date,Z.is_connect_ts) last_logged_on_date,
datediff(day,Z.is_connect_ts,CONVERT(date, getdate()))DAYS_SINCE_last_logon,
CASE WHEN is_connect_ts IS NULL THEN 1 ELSE 0 END NEVER_LOGGED_ON_IND
,CURRENT_TIMESTAMP as MSTR_data_retrieval_TS
----,max(z.day_id) as  MSTR_data_retrieval_TS
from (
SELECT UPPER(EM_USER_ABBREV)EM_USER_ABBREV,EM_USER_NAME,EM_USER_DESC
 FROM EM_USER
WHERE EM_EXISTS_ID=1 and em_enabled=1 and EM_USER_NAME not in ('Administrator','audit','test','user')
)a 
left outer join current_emp b
on a.EM_USER_ABBREV=b."Microstrategy User ID (ID)"
left outer join (Select distinct	a11.EM_USER_ID  EM_USER_ID,
	max(a13.EM_USER_NAME)  EM_USER_NAME,
	max(a13.EM_USER_ABBREV)  EM_USER_ABBREV,
	max(a13.EM_ENABLED)  EM_ENABLED,
	max(a11.IS_CONNECT_TS)  is_connect_ts,
		max(a11.day_id)  day_id
from	IS_SESSION	a11
	join	EM_USER	a13
	  on 	(a11.EM_USER_ID = a13.EM_USER_ID)
where	((exists (select	*
	from	IS_PROJECT_FACT	c21
	where	c21.EM_USER_ID = a11.EM_USER_ID))
 and a13.EM_ENABLED = 1 and a13.EM_USER_ABBREV<>'Administrator' 
and a13.em_exists_id=1
 )
group by	a11.EM_USER_ID)z
on  a.EM_USER_ABBREV=z.EM_USER_ABBREV
group by
a.em_user_abbrev,
convert(date,Z.is_connect_ts),
datediff(day,Z.is_connect_ts,CONVERT(date, getdate())),
CASE WHEN is_connect_ts IS NULL THEN 1 ELSE 0 END
