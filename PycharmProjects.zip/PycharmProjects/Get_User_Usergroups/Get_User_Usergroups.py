import json
import sys
import pandas as pd
import requests

user_GUID = '6C4A7B1B4ED2AF9C323D0AB8540F93C2'  # this is my GUID for user t033270 as an example
api_username = 't033270'
api_pwd = 'test'
cwd = sys.path[0]
url = 'http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api'  # wcmsenwqa01, homsenwprd01
response = requests.post(url + '/auth/login', data={'username': api_username, 'password': api_pwd, 'loginMode': 1})
authToken = response.headers['X-MSTR-AuthToken']
cookies = dict(response.cookies)
# Get Users' Usergroups
usergroup_response = requests.get(url + '/users/' + user_GUID,
                             headers={'X-MSTR-AuthToken': authToken},
                             params={'id': user_GUID},
                             cookies=cookies)
# Content type
user_group_json = json.loads(usergroup_response.text)
list_memberships = user_group_json['memberships']
list_groups = [group['name'] for group in list_memberships]
df = pd.DataFrame(list_groups, columns=['USER_GROUP'])
df.to_csv(cwd + '/user_group.txt', index=False)
response.close()
