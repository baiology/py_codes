import ibm_db_dbi as db
import datetime
import csv
import os
import sys
import time
import pandas as pd
import tkinter as tk
from subprocess import Popen, PIPE
from tkinter.filedialog import askdirectory
from tkinter import filedialog
from tkinter import messagebox

def createFile(PathFilename):
    crFile = open(PathFilename, "w+", encoding="utf-8")
    return crFile

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

def find(name, path):
    result = []
    for root, dirs, files in os.walk(path):
        if name in files:
            result.append(os.path.join(root, name))
    return result

def openFile(btn):
    global fn
    # ftypes = [('All files', '*')]
    # fn = filedialog.askopenfilename(initialdir='/', title='Select file', filetypes=(('Text', '*.txt'), ('CSV', '*.csv')))
    fn = askdirectory()
    print(fn)
    if btn == 1:
        vEntFile1.set(fn)
    else:
        vEntFile2.set(fn)

def closeWindow():
    root.destroy()

# Main Program
def main_prog():
    st_time = time.time()
    strInputFilePath = vEntFile1.get()
    strTPTFilePath = vEntFile2.get()
    strDB = vEntDB.get()
    # create_TPT_File_And_Load(strInputFilePath, strDB, strTPTFilePath)
    if os.path.isdir(strInputFilePath): # if Directory
        # do this
        print(strInputFilePath)
    else:
        # do this
        print(strInputFilePath)

    strDatabase = listVar.get()
    print('Start time: ' + time.strftime("%H:%M:%S"))

    end_time = time.time()
    print('End time: ' + time.strftime("%H:%M:%S"))
    print('Elapsed Time: ' + printRuntime(end_time - st_time))
    messagebox.showinfo('Data Load Complete', 'Successfully loaded data to ' + strDatabase + ' database.\nElapsed Time: ' + printRuntime(end_time - st_time))
    closeWindow()

cwd = sys.path[0]  # Get current working directory
strUser_Name = 't033270'
strPassword = 'Welcome6^'
strDB2_Server = 'HODWDBTST01'
strPort = '50002'
strDatabase = 'QADM'
strMSTR_Server= 'HOMSENIDEV01'
df = pd.read_excel(cwd + '/create_user_list.xlsx')
# df_req = pd.read_csv(cwd + '/create_user_list.txt')
lst_user_list = df['AID'].tolist()
lst_req_group_list = df['Requested_Group'].tolist()
lst_users = ','.join(["'" + x + "'" for x in lst_user_list])

# DB2 Connection
DB2_conn = db.connect("DATABASE=SYSDM;HOSTNAME=" + strDB2_Server + ";PORT=" + strPort + ";PROTOCOL=TCPIP;UID=" + strUser_Name + ";PWD=" + strPassword + ";", "", "")
strQuery_DB2 = '''select --distinct a11.USER_AID_KEY  USER_AID_KEY,
 trim(a11.USER_AID)  USER_AID,
 --a12.USER_NAME_KEY  USER_NAME_KEY,
 rtrim(a15.USER_LAST_NAME) concat ', ' concat rtrim(a15.USER_FIRST_NAME)  LAST_FIRST_NAME,
 --a13.USER_BRANCH_ID  USER_BRANCH_ID,
 RTRIM(a13.USER_BRANCH)  USER_BRANCH,
 --RTRIM(a13.USER_CLAIM_BRANCH_ABBR)  USER_CLAIM_BRANCH_ABBR,
 trim(a14.USER_EMAIL)  USER_EMAIL
from AMDBTBL.D_USER_AID a11
 join AMDBTBL.F_USER a12
   on  (a11.USER_AID_KEY = a12.USER_AID_KEY)
 join AMDBTBL.D_USER_BRANCH a13
   on  (a12.USER_BRANCH_KEY = a13.USER_BRANCH_KEY)
 join amdbtbl.D_USER_CONTACT a14
   on  (a12.USER_CONTACT_KEY = a14.USER_CONTACT_KEY)
 join AMDBTBL.D_USER_NAME a15
   on  (a12.USER_NAME_KEY = a15.USER_NAME_KEY)
where  A12.USER_CURRENT_IND_KEY = 1
and a11.USER_AID'''
strQuery_DB2 = strQuery_DB2 + ' IN(' + lst_users + ')'
df_DB2 = pd.read_sql(strQuery_DB2,DB2_conn)
create_user_list = []
add_address_list = []
for index, row in df_DB2.head().iterrows():
    req_group = df.loc[df['AID'] == row['USER_AID']].iat[0,1]
    create_user_list.append('CREATE USER ' + '"' + row['USER_AID'] + '"' + ' FULLNAME ' + '"' + row['LAST_FIRST_NAME'] + '"' + ' DESCRIPTION "Learning And Talent Development" NTLINK "\\\\Amica.com\\' + row['USER_AID'] + '" IN GROUP ' + '"' + req_group + '"')
    add_address_list.append('ADD ADDRESS ' + '"' + row['LAST_FIRST_NAME'] + '"' + ' PHYSICALADDRESS ' + '"' + row['USER_EMAIL'] + '"' + ' DELIVERYTYPE EMAIL DEVICE "Generic Email" SETASDEFAULT TRUE TO USER ' + '"' + row['USER_AID'] + '"')

now = datetime.datetime.now()
strDate = now.strftime("%m%d%Y_%H%M%S")
cmdManager = createFile(cwd + '/CmdMgr_Create_User_' + strDate + '.scp')
cmdManager.write('CONNECT SERVER "HOMSENIDEV01" USER "administrator>" PASSWORD "micro";')
cmdManager.write('\n')
cmdManager.write('\n'.join(create_user_list))
cmdManager.write('\n')
cmdManager.write('\n'.join(add_address_list))
cmdManager.write('\n')
cmdManager.write('DISCONNECT SERVER;')
cmdManager.close()
# # -------------------------------------------------------------------------------------------------- #
# # -------------------------------------- Windows GUI Creation -------------------------------------- #
# # -------------------------------------------------------------------------------------------------- #
# cwd = sys.path[0]  # Get current working directory
# root = tk.Tk() # create the root window instance
# root.title('Data Load:') # add title to the window
# root.resizable(0,0) # will disable the maximize button in the upper right window
# canvas = tk.Canvas(root, height=150, width=500) # create the window canvas/form
# canvas.pack(side='top') # pack the form so that it will be visible
#
# #====================== Input File ======================#
# var = tk.StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
# lblFile1 = tk.Label(root, textvariable = var)
# var.set('Input File: ')
# lblFile1.place(height=20, width=100, relx=0.02, rely=0.10)
#
# vEntFile1 = tk.StringVar()
# entFile1 = tk.Entry(root, textvariable=vEntFile1, bg='white')
# entFile1.place(height=20, width=320, relx=0.20, rely=0.10)
#
# btnFile1 = tk.Button(root, text = "...", command=lambda: openFile(1)) # create the button for browsing folder
# btnFile1.place(height=20, width=50, relx=0.85, rely=0.10) # place the button to the window using the relx and rely positioning
#
# #====================== TPT Path ======================#
# varTPT = tk.StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
# lblFileTPT = tk.Label(root, textvariable = varTPT)
# varTPT.set('TPT File Path: ')
# lblFileTPT.place(height=20, width=100, relx=0.02, rely=0.27)
#
# vEntFile2 = tk.StringVar()
# entFile2 = tk.Entry(root, textvariable=vEntFile2, bg='white')
# entFile2.place(height=20, width=320, relx=0.20, rely=0.27)
#
# btnFile2 = tk.Button(root, text = "...", command=lambda: openFile(2)) # create the button for browsing folder
# btnFile2.place(height=20, width=50, relx=0.85, rely=0.27) # place the button to the window using the relx and rely positioning
#
# #====================== Dropdown list box ======================#
# varDD = tk.StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
# lblFileDD = tk.Label(root, textvariable = varDD)
# varDD.set('Target Database: ')
# lblFileDD.place(height=30, width=100, relx=0.01, rely=0.44)
#
# list = ['Teradata', 'SQL Server']
# listVar = tk.StringVar()
# listVar.set(list[0])
# dropdown = tk.OptionMenu(root, listVar, *list)
# dropdown.place(height=30, width=100, relx=0.20, rely=0.44)
#
# varDB = tk.StringVar() # create a StringVar to use in label so that it can be changed anywhere using the variable
# lblFileDB = tk.Label(root, textvariable = varDB)
# varDB.set('Database Name: ')
# lblFileDB.place(height=20, width=100, relx=0.40, rely=0.44)
#
# vEntDB = tk.StringVar()
# entDB = tk.Entry(root, textvariable=vEntDB, bg='white')
# entDB.place(height=20, width=120, relx=0.60, rely=0.44)
#
#
# # Button Generate and Close
# btnCompare = tk.Button(root, text = "Generate", command=main_prog)
# btnCompare.place(height=30, width=70, relx=0.30, rely=0.70)
#
# btnClose = tk.Button(root, text = "Close", command=closeWindow)
# btnClose.place(height=30, width=70, relx=0.50, rely=0.70)
#
# root.mainloop()