import ibm_db_dbi as db
import datetime
import csv
import os
import sys
import time
import pandas as pd
import tkinter as tk
from subprocess import Popen, PIPE
from tkinter.filedialog import askdirectory
from tkinter import filedialog
from tkinter import messagebox

import pyodbc


def createFile(PathFilename):
    crFile = open(PathFilename, "w+", encoding="utf-8")
    return crFile

def printRuntime(seconds):
    seconds = int(seconds)
    msg = "[%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600 // 60), (seconds % 60 // 1)) + ']'
    return msg

cwd = sys.path[0]  # Get current working directory
CMDMGR_Server = 'HOMSENIDEV01'
CMDMGR_user = 'administrator'
CMDMGR_pwd = 'micro'
df = pd.read_excel(cwd + '/create_user_list.xlsx')
df.columns =[column.replace(" ", "_") for column in df.columns]
df.iloc[:,0] = df.iloc[:,0].str.strip()

# df_req = pd.read_csv(cwd + '/create_user_list.txt')
lst_user_list = df['AID'].tolist()
lst_req_group_list = df['Requested_Group'].tolist()
lst_users = ','.join(["'" + x + "'" for x in lst_user_list])

# TD Connection
conn_TD = pyodbc.connect('DSN=TDTest64;Trusted_Connection=yes;')
strQuery_TD = '''select trim(a11.USER_AID) USER_AID,
                rtrim(a15.USER_LAST_NAME)||', '||rtrim(a15.USER_FIRST_NAME) LAST_FIRST_NAME,
                RTRIM(a13.USER_BRANCH) USER_BRANCH,
                trim(a14.USER_EMAIL) USER_EMAIL
                from DMSD2V_CLM_MSTR.D_USER_AID a11
                join DMSD2V_CLM_MSTR.F_USER a12
                on (a11.USER_AID_KEY = a12.USER_AID_KEY)
                join DMSD2V_CLM_MSTR.D_USER_BRANCH a13
                on (a12.USER_BRANCH_KEY = a13.USER_BRANCH_KEY)
                join DMSD2V_CLM_MSTR.D_USER_CONTACT a14
                on (a12.USER_CONTACT_KEY = a14.USER_CONTACT_KEY)
                join DMSD2V_CLM_MSTR.D_USER_NAME a15
                on (a12.USER_NAME_KEY = a15.USER_NAME_KEY)
                where A12.USER_CURRENT_IND_KEY = 1
                and a11.USER_AID'''
strQuery_TD = strQuery_TD + ' IN(' + lst_users + ')'
df_TD = pd.read_sql(strQuery_TD, conn_TD)
df_TD.columns =[column.replace(" ", "_") for column in df_TD.columns]

create_user_list = []
add_address_list = []
for index, row in df_TD.iterrows():
    row_val = row['USER_AID']
    df_res = df.loc[df['AID'] == row_val]
    req_group = df_res.iat[0,1] # Get the Group Name
    create_user_list.append('CREATE USER ' + '"' + row['USER_AID'] + '"' + ' FULLNAME ' + '"' + row['LAST_FIRST_NAME'] + '"' + ' DESCRIPTION "' + row['USER_BRANCH'] + '" NTLINK "\\\\Amica.com\\' + row['USER_AID'] + '" IN GROUP ' + '"' + req_group + '"')
    add_address_list.append('ADD ADDRESS ' + '"' + row['LAST_FIRST_NAME'] + '"' + ' PHYSICALADDRESS ' + '"' + row['USER_EMAIL'] + '"' + ' DELIVERYTYPE EMAIL DEVICE "Generic Email" SETASDEFAULT TRUE TO USER ' + '"' + row['USER_AID'] + '"')

now = datetime.datetime.now()
strDate = now.strftime("%m%d%Y_%H%M%S")
strFileName = cwd + '/CmdMgr_Create_User_' + strDate + '.scp'
# cmdManager = createFile(cwd + '/CmdMgr_Create_User_' + strDate + '.scp')
with open(strFileName, "w+", encoding="utf-8") as cmdManager:
    cmdManager.write('CONNECT SERVER "' + CMDMGR_Server + '" USER "' + CMDMGR_user + '" PASSWORD "' + CMDMGR_pwd + '";')
    cmdManager.write('\n')
    cmdManager.write('\n'.join(create_user_list))
    cmdManager.write('\n')
    cmdManager.write('\n'.join(add_address_list))
    cmdManager.write('\n')
    cmdManager.write('DISCONNECT SERVER;')
    cmdManager.close()