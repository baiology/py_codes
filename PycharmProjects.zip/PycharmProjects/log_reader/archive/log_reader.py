import datetime

import pandas as pd
import os
import sys

# path = sys.path[0]
# path = '//amica.com/files/ctm/sysout/aim-microstrategy'
# path='//amica.com/files/ctm/sysout/aimjobs'

cwd = sys.path[0] # read current folder
now = datetime.datetime.now()
strDateTS = now.strftime("%m%d%Y_%H%M%S")
# directories = [os.path.join(cwd, x) for x in next(os.walk(cwd))[1]] # read current folder and check for the sub-folders where the logs are stored.
directories = ['//amica.com/files/ctm/sysout/aim-microstrategy', '//amica.com/files/ctm/sysout/aimjobs','//amica.com/files/ctm/sysout/AIMJobs-DM','//amica.com/files/ctm/sysout/AIMJobs-Teradata']
file_data = []
ctr = 1
for directory in directories:
    files = [x for x in os.listdir(directory) if x.endswith('.log')]
    for file in files:
        file_split = file.split('_')[:-1]
        file_split.insert(0, ctr)
        file_split.insert(len(file_split), strDateTS)
        file_split[3] = file_split[3].replace(file_split[3], datetime.datetime.strptime(file_split[3], '%H%M%S').strftime('%I:%M:%S %p'))
        file_split[4] = file_split[4].replace('Run', '')
        file_data.append(file_split)
        ctr += 1

df_cols = ['ID', 'Job_Name', 'Date', 'Completion_Time', 'Run', 'Server', 'Run_TS']
df = pd.DataFrame(file_data, columns=df_cols)
xlsxFile = os.path.normpath(cwd + '\\LogFile_Data_' + strDateTS + '.xlsx')
writer = pd.ExcelWriter(xlsxFile, engine='xlsxwriter')
df.to_excel(writer, 'Result_Summary', index=False)
writer.save()

