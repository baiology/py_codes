from datetime import datetime
import time
from zipfile import ZipFile

import pandas as pd
import os
import sys

def get_FileData_List(file, dt_ts, directory):
    global ctr
    fname_ini = os.path.splitext(os.path.basename(file))[0]
    fname_f = fname_ini.split('_')[:-1]
    fname = '_'.join(fname_f)
    file_split = fname.rsplit('_', 4)
    file_split.insert(0, ctr)
    file_split.insert(len(file_split), dt_ts)
    file_split.insert(len(file_split), os.path.normpath(directory))
    time_ts = file_split[3]
    # file_split[3] = time_ts.replace(time_ts, datetime.datetime.strptime(time_ts, '%H%M%S').strftime('%I:%M:%S %p'))
    file_split[3] = datetime.strptime(time_ts, '%H%M%S').strftime('%I:%M:%S %p')
    file_split[4] = file_split[4].replace('Run', '')
    ctr += 1
    return file_split

# path = sys.path[0]
# path = '//amica.com/files/ctm/sysout/aim-microstrategy'
# path='//amica.com/files/ctm/sysout/aimjobs'

cwd = sys.path[0] # read current folder
now = datetime.now()
strDateTS = now.strftime("%m%d%Y_%H%M%S")
directories = [os.path.join(cwd, x) for x in next(os.walk(cwd))[1]] # read current folder and check for the sub-folders where the logs are stored.
# directories = ['//amica.com/files/ctm/sysout/aim-microstrategy', '//amica.com/files/ctm/sysout/aimjobs','//amica.com/files/ctm/sysout/AIMJobs-DM','//amica.com/files/ctm/sysout/AIMJobs-Teradata']
directories = [r'\\hofile02\microstrategy\Teradata\Misc\Python\Control_M\AIMJobs']
#directories = [r'\\hofile02\microstrategy\Teradata\Misc\Python\Control_M\AIMJobs', r'\\hofile02\microstrategy\Teradata\Misc\Python\Control_M\AIMJobs-DM', r'\\hofile02\microstrategy\Teradata\Misc\Python\Control_M\AIMJobs-Teradata', r'\\hofile02\microstrategy\Teradata\Misc\Python\Control_M\AIM-MicroStrategy']
all_data = []
ctr = 1
for directory in directories:
    print("Processing folder: " + directory)
    files_list = [x for x in os.listdir(directory) if x.endswith('.log')]
    zip_files = [x for x in os.listdir(directory) if x.endswith('.zip')]
    file_data = [get_FileData_List(file, strDateTS, directory) for file in files_list]
    zip_file_data = []
    counter = 1
    zip_count = len(zip_files)
    for zip_file in zip_files:
        print('Reading zip file: [' + str(counter) + '] ' + zip_file)
        archive = ZipFile(os.path.join(directory, zip_file), 'r')
        zip_logfiles_list = [name for name in archive.namelist() if name.endswith('.log')]
        zip_file_data = [get_FileData_List(file, strDateTS, directory + '/' + zip_file) for file in zip_logfiles_list]
        counter += 1
    if len(file_data) > 0:
        all_data.extend(file_data)
    if len(zip_file_data) > 0:
        all_data.extend(zip_file_data)

xlsx_Output = cwd + '\\LogFile_Data_' + strDateTS + '.xlsx'
print('\nProcessing Complete. \nWriting output to file: ' + xlsx_Output)
# all_data = sum(file_data, zip_file_data)
df_cols = ['ID', 'Job_Name', 'Date', 'Completion_Time', 'Run', 'Server', 'Run_TS', 'Source_Directory']
df = pd.DataFrame(all_data, columns=df_cols)
xlsxFile = os.path.normpath(xlsx_Output)
writer = pd.ExcelWriter(xlsxFile, engine='xlsxwriter')
df.to_excel(writer, 'Result_Summary', index=False)
writer.save()
