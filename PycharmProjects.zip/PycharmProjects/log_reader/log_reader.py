from datetime import datetime
import time
from zipfile import ZipFile

import pandas as pd
import os
import sys

def get_FileData_List(file, dt_ts, directory):
    global ctr
    fname_ini = os.path.splitext(os.path.basename(file))[0]
    fname_f = fname_ini.split('_')[:-1]
    fname = '_'.join(fname_f)
    file_split = fname.rsplit('_', 4)
    file_split.insert(0, ctr)
    file_split.insert(len(file_split), dt_ts)
    file_split.insert(len(file_split), os.path.normpath(directory))
    time_ts = file_split[3]
    # file_split[3] = time_ts.replace(time_ts, datetime.datetime.strptime(time_ts, '%H%M%S').strftime('%I:%M:%S %p'))
    file_split[2] = datetime.strptime(file_split[2], '%Y%m%d').strftime('%m/%d/%Y')
    file_split[3] = datetime.strptime(time_ts, '%H%M%S').strftime('%I:%M:%S %p')
    file_split[4] = file_split[4].replace('Run', '')
    ctr += 1
    return file_split

# path = sys.path[0]
# path = '//amica.com/files/ctm/sysout/aim-microstrategy'
# path='//amica.com/files/ctm/sysout/aimjobs'

cwd = sys.path[0] # read current folder
now = datetime.now()
strDateTS = now.strftime("%m%d%Y_%H%M%S")
directories = [os.path.join(cwd, x) for x in next(os.walk(cwd))[1]] # read current folder and check for the sub-folders where the logs are stored.
# directories = ['//amica.com/files/ctm/sysout/aim-microstrategy', '//amica.com/files/ctm/sysout/aimjobs','//amica.com/files/ctm/sysout/AIMJobs-DM','//amica.com/files/ctm/sysout/AIMJobs-Teradata']
# directories = [r'C:\Users\t033270\PycharmProjects\log_reader\sample_logs_AIM', r'C:\Users\t033270\PycharmProjects\log_reader\sample_logs_MSTR', r'C:\Users\t033270\PycharmProjects\log_reader\AIMJobs']
# directories = [r'\\hofile02\microstrategy\Teradata\Misc\Python\Control_M\AIMJobs', r'\\hofile02\microstrategy\Teradata\Misc\Python\Control_M\AIMJobs-DM', r'\\hofile02\microstrategy\Teradata\Misc\Python\Control_M\AIMJobs-Teradata', r'\\hofile02\microstrategy\Teradata\Misc\Python\Control_M\AIM-MicroStrategy']
directories = [r'\\hofile02\microstrategy\Teradata\Misc\Python\Control_M\AIM-MicroStrategy']
dir_count = len(directories)
dir_file_ctr = []
for idx, directory in enumerate(directories):
    ctr = 1
    all_data = []
    dir_name = os.path.basename(directory).replace(' ','_')
    print("Processing folder: " + directory)
    files_list = [x for x in os.listdir(directory) if x.endswith('.log')]
    files_count = len(files_list)
    zip_files = [x for x in os.listdir(directory) if x.endswith('.zip')]
    zip_count = len(zip_files)
    file_data = [get_FileData_List(file, now, directory) for file in files_list] # read each file and get the log details
    print('Log File Count: ' + str(files_count))
    print('Zip File Count: ' + str(zip_count))
    if len(file_data) > 0:
        all_data.extend(file_data)
    zip_file_data = []
    counter = 1
    # Read each zip file in every folder
    for zip_file in zip_files:
        archive = ZipFile(os.path.join(directory, zip_file), 'r')
        zip_logfiles_list = [name for name in archive.namelist() if name.endswith('.log')]
        zip_logfiles_count = len(zip_logfiles_list)
        ctr_zip = 1
        # read each file and get the log details
        for z_idx, file in enumerate(zip_logfiles_list):
            z_idx += 1
            if z_idx == zip_logfiles_count:
                print('\r\t\t> Reading zip file: [COMPLETE]                                          ', end='', flush=True)
            else:
                print('\r\t\t> Reading zip file: [' + str(counter) + '] ' + zip_file + ' (File ' + str(z_idx) + ' / ' + str(zip_logfiles_count) + ')', end='', flush=True)
            zip_file_data.append(get_FileData_List(file, now, directory + '/' + zip_file))
        counter += 1
    if len(zip_file_data) > 0:
        all_data.extend(zip_file_data)
    print('\n\t\t# of Files Read: ' + str(len(all_data)))
    print('\n')
    dir_file_ctr.append(len(all_data))
    # Save to excel file
    xlsx_Output = cwd + '\\' + dir_name + '.xlsx'
    print('Processing Complete. \nWriting output to file: ' + xlsx_Output + '\n')
    df_cols = ['ID', 'Job_Name', 'Date', 'Completion_Time', 'Run', 'Server', 'Run_TS', 'Source_Directory']
    df = pd.DataFrame(all_data, columns=df_cols)
    xlsxFile = os.path.normpath(xlsx_Output)
    writer = pd.ExcelWriter(xlsxFile, engine='xlsxwriter')
    df.to_excel(writer, 'LogFile_Data', index=False)
    writer.save()
print('\nTotal Files Read: ' + str(sum(dir_file_ctr)))
# csv_Output = cwd + '\\LogFile_Data_' + strDateTS + '.csv'
# df.insert(loc=0, column='ID_A', value=df.index + 1)
# df.to_csv(csv_Output, index=False)
