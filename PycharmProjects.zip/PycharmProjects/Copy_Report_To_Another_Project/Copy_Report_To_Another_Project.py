import requests
import io
import pandas as pd
import json
from mstrio import microstrategy
# from mstrio.api import

def logout(url, auth_token, cookies):
    """
    Close all existing sessions for the authenticated user.
    :param connection: MicroStrategy REST API connection object
    :param verbose: Verbosity of request response; defaults to False
    :return: Complete HTTP response object
    """
    response = requests.post(url=url + '/auth/logout',
                             headers={'X-MSTR-AuthToken': auth_token},
                             cookies=cookies)
    return response

# Variable
str_io = io.StringIO()
report_id = '9DADD1FC4E19A91AEC182A9FBE021DE1' #'9DADD1FC4E19A91AEC182A9FBE021DE1' # QA - '9DADD1FC4E19A91AEC182A9FBE021DE1'
project_id = '28B29F88423461E8F73511915E7FD9A2' #'EE20C1884DA2A79F1366FD964FC668B6'
project_name = "Claims Management Reporting"
api_username = 't033270'
api_password = 'test'
# Connect
base_url = 'http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api' # wcmsenwqa01, homsenwprd01

response = requests.post(base_url + '/auth/login', data={'username': api_username, 'password': api_password, 'loginMode': 1})
authToken = response.headers['X-MSTR-AuthToken']
cookies = dict(response.cookies)
# Report details
report = requests.get(base_url + '/reports/' + report_id, headers={'X-MSTR-AuthToken': authToken, 'X-MSTR-ProjectID': project_id}, json={'reportId': report_id}, cookies=cookies)
if report.ok == False: # Error: (Unsupported template structure. Please check your design (only template metrics are allowed on column axis, for example).)
    err_msg_json = json.loads(report.text)
    err_msg = err_msg_json['message']
    print('Unable to extract data from the report. \n' + err_msg)
else:
    # Get Report Name
    r = report.json()
    strReport_name = r.get('name')
    # Get Report snd export to HTML
    pd.options.display.float_format = '{:,.0f}'.format  # without dollar sign
    conn = microstrategy.Connection(base_url=base_url, username=api_username, password=api_password, project_name=project_name)
    conn.connect()
    df_ReportData = conn.get_report(report_id=report_id)
    print(df_ReportData)
