import requests
import io
import pandas as pd
import json
from mstrio import microstrategy
# from mstrio.api import

def logout(url, auth_token, cookies):
    """
    Close all existing sessions for the authenticated user.
    :param connection: MicroStrategy REST API connection object
    :param verbose: Verbosity of request response; defaults to False
    :return: Complete HTTP response object
    """
    response = requests.post(url=url + '/auth/logout',
                             headers={'X-MSTR-AuthToken': auth_token},
                             cookies=cookies)
    return response

# Variable
str_io = io.StringIO()
report_id = '9DADD1FC4E19A91AEC182A9FBE021DE1' #'9DADD1FC4E19A91AEC182A9FBE021DE1' # QA - '9DADD1FC4E19A91AEC182A9FBE021DE1'
group_id = '9C85683043584D67ABE75CA56A7C195B'
recipient_id = "6C4A7B1B4ED2AF9C323D0AB8540F93C2"
project_id = 'E37C06B844EC13D226F6428AF6133DEA' #'EE20C1884DA2A79F1366FD964FC668B6'
project_name = "Claims Management Reporting"
username = 't033270'
password = 'test'
subject = 'Email: '
# Connect
url = 'http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api' # wcmsenwqa01, homsenwprd01

response = requests.post(url + '/auth/login', data={'username': 't033270', 'password': 'test', 'loginMode': 1})

authToken = response.headers['X-MSTR-AuthToken']
cookies = dict(response.cookies)
print("Token: " + authToken)

# Get project
proj_response = requests.get(url + '/projects',
                             headers={'X-MSTR-AuthToken': authToken},
                             cookies=cookies)
# Content type
content_type = proj_response.headers['content-type']

# Report details
report = requests.get(url + '/reports/' + report_id,
                                  headers={'X-MSTR-AuthToken': authToken,
                                           'X-MSTR-ProjectID': project_id},
                                    json={'reportId': report_id}, cookies=cookies)

if report.ok == False: # Error: (Unsupported template structure. Please check your design (only template metrics are allowed on column axis, for example).)
    err_msg_json = json.loads(report.text)
    err_msg = err_msg_json['message']
    print('Unable to extract data. \n' + err_msg)
else:
    # Get Report Name
    r = report.json()
    report_name = r.get('name')

    # Get Report snd export to HTML
    # pd.options.display.float_format = '{:.0f}'.format
    # pd.options.display.float_format = '${:,.0f}'.format # dollar sign
    pd.options.display.float_format = '{:,.0f}'.format  # without dollar sign
    conn_TD = microstrategy.Connection(base_url=url, username=username, password=password, project_name=project_name)
    conn_TD.connect()
    print('Connection established.')
    print('Capturing the records from MSTR Project.')
    report_TD = conn_TD.get_report(report_id=report_id)
    report_str = report_TD.to_html(buf=str_io, classes='table table-striped', index=False)
    html_str = str_io.getvalue()
    # cwd = sys.path[0]  # Get current working directory
    # report_TD.to_csv(cwd + '/report.csv', index=False) # save to CSV

# User details
user = requests.get(url + '/users/' + recipient_id,
                                  headers={'X-MSTR-AuthToken': authToken,
                                           'id': recipient_id}, cookies=cookies)

d = user.json()
user_name = d.get('name')

# User Group Info details
group_info = requests.get(url + '/usergroups/' + group_id,
                                  headers={'X-MSTR-AuthToken': authToken,
                                           'id': group_id}, cookies=cookies)

group_info_json = json.loads(group_info.text)
group_name = group_info_json['name']

# User Group Member details
group_member = requests.get(url + '/usergroups/' + group_id + '/members',
                                  headers={'X-MSTR-AuthToken': authToken,
                                           'id': group_id}, cookies=cookies)

group_json = json.loads(group_member.text)
group_members_list = []
if type(group_json) is list:
    for j in group_json:
        group_members_list.append(j['id'])
else:
    group_members_list.append(group_json['id'])

user_guids = ','.join(group_members_list)
# Email
html = """
<html>
<head>
<style> 
  body {{font-family: Arial; font-size: 15px; }}
  table, th, td {{border: 1px solid black; border-collapse: collapse; }}
  th, td {{font-family: Arial; font-size: 15px; padding: 5px; }}
</style>
</head>
<body><p>Hi {}, </p>
<p>Report Name: {}</p>
{}
<p>Regards,</p>
<p>MSTR Admin</p>
</body></html>
"""

html = html.format(group_name,  report_name, html_str) # recipient_name.split(',')[1]
subject = subject + str(report_name)
head = {"X-MSTR-AuthToken": authToken}
f = open("\\\\HOFILE04\\USERS_M\\T033270\\Amica\\automation\\test.txt", 'rb')
files = {"file": ("\\\\HOFILE04\\USERS_M\\T033270\\Amica\\automation\\test.txt", f)}
data = {"notificationType": "1", "userIds": group_members_list, "subject": subject, "content": html, "isHTML": True, "extraProperties": {}}
send_email = requests.post(url + '/emails', json=data, headers=head, cookies=cookies)

print(send_email)

logout(url, authToken, cookies)

# # Cube list
# folder_id_sysdm = '825A8CE349CE0998294147AD69E02263'
# cube_list = requests.get(url + '/folders/' + folder_id_sysdm,
#                                   headers={'X-MSTR-AuthToken': authToken,
#                                            'X-MSTR-ProjectID': '2BE28F58425E8C5026EC0DB3E1D5AADA',
#                                            'id': folder_id_sysdm}, cookies=cookies)

# cube_name = json.dumps(cube_list.text)
# print(cube_name)
# for i in cube_name:
#     val = cube_name[i]
#     print(val)
# print(cube_name['name'])

