import datetime
import glob
import sys
import subprocess
import os
import pandas as pd
import shutil
import requests
import time
import xml.etree.ElementTree as ET

def remove_file_or_folder(path):
    """ param <path> could either be relative or absolute. """
    if os.path.isfile(path) or os.path.islink(path):
        os.remove(path)  # remove the file
    elif os.path.isdir(path):
        shutil.rmtree(path)  # remove dir and all contains
    else:
        raise ValueError("file {} is not a file or dir.".format(path))

def wait_for_file(max_wait_in_secs, file_path):
    time_counter = 0
    while not os.listdir(file_path):
        time.sleep(1)
        time_counter += 1
        if time_counter > max_wait_in_secs:
            break
    time.sleep(1)

# Variable
report_id = '9DADD1FC4E19A91AEC182A9FBE021DE1'
project_id = '28B29F88423461E8F73511915E7FD9A2'
project_name = "Policy Management Reporting"
api_username = 't033270'
api_password = 'test'
MSTR_Server = 'homseniprd01'
cmd_user = 'administrator'
cmd_pwd = 'micro'

base_url = 'http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api'
response = requests.post(base_url + '/auth/login', data={'username': api_username, 'password': api_password, 'loginMode': 1})
authToken = response.headers['X-MSTR-AuthToken']
cookies = dict(response.cookies)
# Using RestAPI
# Object details
# full_url = base_url + '/objects/' + report_id + '?type=3'
# object_details = requests.get(full_url,
#                                 headers={'X-MSTR-AuthToken': authToken,
#                                          'X-MSTR-ProjectID': project_id},
#                                 json={'id': report_id, 'type': '3'},
#                                 cookies=cookies)
#
# r = object_details.json()
# acl_list = r.get('acl')
# for index, acl in enumerate(acl_list):
#     print(index, acl['trusteeId'], acl['trusteeName'])

# Using XML extract
cwd = sys.path[0]  # Get current working directory
src_folder = cwd + '/src'  # Get the source folder where XMLs are stored
files_list = [src_folder + '/' + x for x in os.listdir(src_folder) if
              x.endswith('.xml')]  # Create a list of files with file path
row_data = []
header_count = 0
headers = []
print('  XML Parse in-progress...')
row_data = []
for file in files_list:
    tree = ET.parse(file)
    root = tree.getroot()
    project_name = os.path.splitext(os.path.basename(file))[0]
    # Get Row headers
    record_count = len(root.findall('.//Row'))
    old_header_count = 0
    for row in root.findall('.//Row'):
        print(row.tag)
        row_data_temp = []
        for e in row:
            if e.tag == 'Name':
                project_name = e.text
                row_data_temp.append(project_name)
            if e.tag == 'Trustee':
                trustee_name = e.text
                row_data_temp.append(trustee_name)
        row_data.append(row_data_temp)
        del row_data_temp
df = pd.DataFrame(row_data, columns=['Project Name', 'Trustee Name'])
print(df)