import requests
import time
import json
import sys

def logout(url, auth_token, cookies):
    response = requests.post(url=url + '/auth/logout', headers={'X-MSTR-AuthToken': auth_token}, cookies=cookies)
    return response

def send_email(api_username, api_password, user_or_group_guid, msg_body):
    subject = 'Email: Text Found in File.'
    # Connect
    url = 'http://homsenwprd01.amica.com:8080/MicroStrategyLibrary/api' # wcmsenwqa01, homsenwprd01
    response = requests.post(url + '/auth/login', data={'username': api_username, 'password': api_password, 'loginMode': 1})
    authToken = response.headers['X-MSTR-AuthToken']
    cookies = dict(response.cookies)
    for guid in user_or_group_guid:
        user_response = requests.get(url + '/objects/' + guid, headers={'X-MSTR-AuthToken': authToken}, params={'id': guid, 'type': '34'}, cookies=cookies)
        user_json = json.loads(user_response.text)
        user_name = user_json['name']
        subtype = user_json['subtype']
        if subtype != 8705:
            lname, fname = user_name.split(',')
            user_name = fname.strip() + ' ' + lname.strip()
        print(user_name)
        html = """
        <html>
        <head>
        <style> 
          body {{font-family: Arial; font-size: 15px; }}
          table, th, td {{border: 1px solid black; border-collapse: collapse; }}
          th, td {{font-family: Arial; font-size: 15px; padding: 5px; }}
        </style>
        </head>
        <body><p>Hi {}, </p>
        <p>{}</p>
        <p>Regards,</p>
        <p>MSTR Admin</p>
        </body></html>
        """
        html = html.format(user_name,  msg_body)
        subject = subject
        head = {"X-MSTR-AuthToken": authToken} # 6C4A7B1B4ED2AF9C323D0AB8540F93C2  3 022D56E1488CCDE025DCBDAEBDE977DC
        data = {"notificationType": "1", "userIds": user_or_group_guid, "subject": subject, "content": html, "isHTML": True, "extraProperties": {}}
        send_email = requests.post(url + '/emails', json=data, headers=head, cookies=cookies)
    print(send_email)
    logout(url, authToken, cookies)
# Main Program
api_username = 't033270'
api_password = 'test'
text_to_find_list = ['Andrew']
cwd = sys.path[0]  # Get current working directory
user_or_group_guid = ['6C4A7B1B4ED2AF9C323D0AB8540F93C2', '022D56E1488CCDE025DCBDAEBDE977DC']
ctr_found = 0
with open(cwd + '/sample.log') as infile:
    for line in infile:
        line = line.rstrip('\n')
        for text in text_to_find_list:
            if text in line:
                ctr_found += 1
    if ctr_found > 0:
        print('Sending email...')
        msg_body = 'Found ' + str(ctr_found) + ' occurrence(s) of ' + ''.join(text_to_find_list) + ' in the file.'
        send_email(api_username, api_password, user_or_group_guid, msg_body)
        time.sleep(3)
    else:
        print('Text "' + text + '" not found in file.')
        time.sleep(3)
        sys.exit(0)
