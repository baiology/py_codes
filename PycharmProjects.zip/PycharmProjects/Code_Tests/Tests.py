import pandas as pd

df = pd.DataFrame({'A': ['60003405234', '60003405234'],
                   'B': ['1', '2'],
                   'C': ['3', '4']})
print(df)
df = df.set_index(['A'], drop=False)
row_RIGHT_Val = df.loc['60003405234']
print(df.loc['60003405234'])
print(row_RIGHT_Val)
