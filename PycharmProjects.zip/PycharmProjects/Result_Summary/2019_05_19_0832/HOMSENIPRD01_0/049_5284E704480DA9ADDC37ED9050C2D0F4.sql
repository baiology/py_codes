Tables Accessed:
Table25	[L_MTH]:	Mth, 		LOOKUP_TABLE	
Table47	[F_MAIN_INDEX]:	Current Mth, Current Yr, Current Yr/Qrt, Current Date, Current Yr/Mth, CEA Indicator, ADR Exists Ind, CAT Ind, Days in Year, File Type, Suit Exists Ind, Covrg Party Cd, IA First Assign Ind, Claim Type, ClaimCenter Ind, TotalLoss Cd, Company, LOB, Coverage Question Ind, Qrt, Fatality, Acct Cov Grp 1, Acct Cov Grp 2, File Prefix Cd, Detail LOB, Mth, Common JO, Year, Rolling 12, CAT Begin Mth, Detail Claim Type, CAT Begin Yr, Oper Claim Type, Acct Cov Grp 1 Detail, Yr/Qrt, Common Branch, Policy State, State, Cov, Loss State, Covrg Desc, Covrg Cd, Sub Peril, Yr/Mth, CAT Begin Dt, CAT Name, CAT ID, 	Clms Out by Mth, Clm Cnt Exp Lwst Lvl, Out Rsv by Yr End, Suits Out by Mth, Out Rsv by Yr YTD, Clms Clsd No Pay, Clms Pd Bef Clsd Br, Suits Opn, Suits Out by Yr End, Clm Cnt Exp - Y,M,B, Salv Exps, Clms Settl, Clms Clsd, Clm Cnt Loss Arb Forum, Clm Cnt Exp - Y,B, Subro Recov Clms, Clms Out by Yr YTD Ser, Loss Clsd Clms, CountBranch, Subro Exps, Suits Clsd, Loss Clsd Clms Pd Bef Cls, Clms Out by Qrt, Clms Out by Yr, Clm Cnt Loss - Y,B, Clms Out by Yr YTD, Clms Pd Bef Clsd CW, Clsd Clms Cnt with Exp CW, Suits Out by Qrt, CountQrt, Salv Recv, Suits Out by Yr, Loss Clsd Clms Pd Aft Cls, Clms Out by Qrt Ser, Clms Out by Yr End, Suits Out by Yr YTD, CountMth, Loss, Subro Recv, Out Rsv by Qrt, Exps, Clm Cnt Loss, Clms Rpt, Out Rsv by Mth, Clms Out by Mth Ser, Clms Out by Yr Ser, Clsd Clms Cnt with Exp, Clms Pd after Clsd Br, Clms Pd after Clsd CW, Out Rsv by Yr, Clm Cnt Loss - Y,M,B, Exps Clsd Clms, Clms Out by Yr End Ser, Clsd Clms Cnt with Exp Br, 	FACT_TABLE	




select	[LOB]@[CustCol_71],
	[Qrt]@[QUARTER],
	[Year]@[CustCol_8],
	[Mth]@[MONTH_NUMBER],
	[Mth]@[CustCol_44],
	[Mth]@[CustCol_184],
	sum([[F_MAIN_INDEX].Clms Out by Mth])@{[LOB],[Mth],[Year]} as [Clms Out by Mth],
	sum([[F_MAIN_INDEX].Clms Out by Qrt])@{[LOB],[Mth],[Year]} as [Clms Out by Qrt],
	sum([[F_MAIN_INDEX].Clms Out by Yr End])@{[LOB],[Mth],[Year]} as [Clms Out by Yr End],
	sum([[F_MAIN_INDEX].Clms Out by Yr YTD])@{[LOB],[Mth],[Year]} as [Clms Out by Yr YTD],
	IF([[F_MAIN_INDEX].CountMth] is null, 0, 1) as [CountMth],
	IF([[F_MAIN_INDEX].CountQrt] is null, 0, 1) as [CountQrt]
from	Overall Claims Report Cube
with Table Join Tree: 	[F_MAIN_INDEX]<([Detail Claim Type]@[CustCol_7] in ('BI All     ', 'BIR        ', 'MP All     ', 'PIP All    ')
 and [Current Yr/Mth]@[CustCol_122] <> [Yr/Mth]@[MONTH_DATE])>

[Analytical engine calculation steps:
	1.  Calculate metric: <Clms Out> at original data level
	2.  Calculate subtotal: <Total> 
	3.  Calculate metric: <Clms Out> at subtotal levels
	4.  Perform cross-tabbing
]
