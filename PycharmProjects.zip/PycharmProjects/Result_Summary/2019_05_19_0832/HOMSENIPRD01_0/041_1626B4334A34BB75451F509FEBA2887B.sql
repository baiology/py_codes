Tables Accessed:
Table25	[L_MTH]:	Mth, 		LOOKUP_TABLE	
Table35	[L_COMMON_BRANCH]:	Common Branch, 		LOOKUP_TABLE	
Table43	[L_YR/MTH]:	Yr/Mth, 		LOOKUP_TABLE	
Table47	[F_MAIN_INDEX]:	Current Mth, Current Yr, Current Yr/Qrt, Current Date, Current Yr/Mth, CEA Indicator, ADR Exists Ind, CAT Ind, Days in Year, File Type, Suit Exists Ind, Covrg Party Cd, IA First Assign Ind, Claim Type, ClaimCenter Ind, TotalLoss Cd, Company, LOB, Coverage Question Ind, Qrt, Fatality, Acct Cov Grp 1, Acct Cov Grp 2, File Prefix Cd, Detail LOB, Mth, Common JO, Year, Rolling 12, CAT Begin Mth, Detail Claim Type, CAT Begin Yr, Oper Claim Type, Acct Cov Grp 1 Detail, Yr/Qrt, Common Branch, Policy State, State, Cov, Loss State, Covrg Desc, Covrg Cd, Sub Peril, Yr/Mth, CAT Begin Dt, CAT Name, CAT ID, 	Clms Out by Mth, Clm Cnt Exp Lwst Lvl, Out Rsv by Yr End, Suits Out by Mth, Out Rsv by Yr YTD, Clms Clsd No Pay, Clms Pd Bef Clsd Br, Suits Opn, Suits Out by Yr End, Clm Cnt Exp - Y,M,B, Salv Exps, Clms Settl, Clms Clsd, Clm Cnt Loss Arb Forum, Clm Cnt Exp - Y,B, Subro Recov Clms, Clms Out by Yr YTD Ser, Loss Clsd Clms, CountBranch, Subro Exps, Suits Clsd, Loss Clsd Clms Pd Bef Cls, Clms Out by Qrt, Clms Out by Yr, Clm Cnt Loss - Y,B, Clms Out by Yr YTD, Clms Pd Bef Clsd CW, Clsd Clms Cnt with Exp CW, Suits Out by Qrt, CountQrt, Salv Recv, Suits Out by Yr, Loss Clsd Clms Pd Aft Cls, Clms Out by Qrt Ser, Clms Out by Yr End, Suits Out by Yr YTD, CountMth, Loss, Subro Recv, Out Rsv by Qrt, Exps, Clm Cnt Loss, Clms Rpt, Out Rsv by Mth, Clms Out by Mth Ser, Clms Out by Yr Ser, Clsd Clms Cnt with Exp, Clms Pd after Clsd Br, Clms Pd after Clsd CW, Out Rsv by Yr, Clm Cnt Loss - Y,M,B, Exps Clsd Clms, Clms Out by Yr End Ser, Clsd Clms Cnt with Exp Br, 	FACT_TABLE	




select	[TotalLoss Cd]@[D_Total_loss_ind],
	[Detail Claim Type]@[CustCol_7],
	[Yr/Mth]@[MONTH_DATE],
	[Yr/Mth]@[CustCol_135],
	[Yr/Mth]@[MONTH_OF_YEAR],
	[Year]@[CustCol_8],
	[Loss State]@[CustCol_168],
	[Common Branch]@[BRANCH_ID],
	[Common Branch]@[CLAIM_BRANCH_ABBR],
	[Mth]@[MONTH_NUMBER],
	[Mth]@[CustCol_44],
	sum([[F_MAIN_INDEX].Clms Out by Mth])@{[Common Branch],[Detail Claim Type],[Loss State],[Mth],[TotalLoss Cd],[Year],[Yr/Mth]} as [Clms Out by Mth],
	sum([[F_MAIN_INDEX].Clms Pd Bef Clsd Br])@{[Common Branch],[Detail Claim Type],[Loss State],[Mth],[TotalLoss Cd],[Year],[Yr/Mth]} as [Clms Pd Bef Clsd Br],
	sum([[F_MAIN_INDEX].Clms Pd Bef Clsd CW])@{[Detail Claim Type],[Loss State],[Mth],[TotalLoss Cd],[Year],[Yr/Mth]} as [Clms Pd Bef Clsd CW],
	sum([[F_MAIN_INDEX].Clms Pd after Clsd Br])@{[Common Branch],[Detail Claim Type],[Loss State],[Mth],[TotalLoss Cd],[Year],[Yr/Mth]} as [Clms Pd after Clsd Br],
	sum([[F_MAIN_INDEX].Clms Pd after Clsd CW])@{[Detail Claim Type],[Loss State],[Mth],[TotalLoss Cd],[Year],[Yr/Mth]} as [Clms Pd after Clsd CW],
	sum([[F_MAIN_INDEX].Clms Rpt])@{[Common Branch],[Detail Claim Type],[Loss State],[Mth],[TotalLoss Cd],[Year],[Yr/Mth]} as [Clms Rpt],
	IF([[F_MAIN_INDEX].CountBranch] is null, 0, 1) as [CountBranch],
	sum([[F_MAIN_INDEX].Exps])@{[Common Branch],[Detail Claim Type],[Loss State],[Mth],[TotalLoss Cd],[Year],[Yr/Mth]} as [Exps],
	sum([[F_MAIN_INDEX].Loss])@{[Common Branch],[Detail Claim Type],[Loss State],[Mth],[TotalLoss Cd],[Year],[Yr/Mth]} as [Loss],
	sum([[F_MAIN_INDEX].Out Rsv by Mth])@{[Common Branch],[Detail Claim Type],[Loss State],[Mth],[TotalLoss Cd],[Year],[Yr/Mth]} as [Out Rsv by Mth]
from	Overall Claims Report Cube
with Table Join Tree: 	[F_MAIN_INDEX]<([LOB]@[CustCol_71] in ('Auto     ')
 and [Detail Claim Type]@[CustCol_7] in ('Coll All   ', 'OTC All    ', 'PD All     ')
 and [Cov]@[CLAIM_COV_SCREEN_CD] not in ('TOW  ')
 and [Yr/Mth]@[MONTH_DATE] <> [Current Yr/Mth]@[CustCol_122])>

[Analytical engine calculation steps:
	1.  Calculate metric: <Pd Clm Cnt - Cls Dt>
	2.  Perform cross-tabbing
]
