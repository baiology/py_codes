Tables Accessed:
Table25	[L_MTH]:	Mth, 		LOOKUP_TABLE	
Table47	[F_MAIN_INDEX]:	Current Mth, Current Yr, Current Yr/Qrt, Current Date, Current Yr/Mth, CEA Indicator, ADR Exists Ind, CAT Ind, Days in Year, File Type, Suit Exists Ind, Covrg Party Cd, IA First Assign Ind, Claim Type, ClaimCenter Ind, TotalLoss Cd, Company, LOB, Coverage Question Ind, Qrt, Fatality, Acct Cov Grp 1, Acct Cov Grp 2, File Prefix Cd, Detail LOB, Mth, Common JO, Year, Rolling 12, CAT Begin Mth, Detail Claim Type, CAT Begin Yr, Oper Claim Type, Acct Cov Grp 1 Detail, Yr/Qrt, Common Branch, Policy State, State, Cov, Loss State, Covrg Desc, Covrg Cd, Sub Peril, Yr/Mth, CAT Begin Dt, CAT Name, CAT ID, 	Clms Out by Mth, Clm Cnt Exp Lwst Lvl, Out Rsv by Yr End, Suits Out by Mth, Out Rsv by Yr YTD, Clms Clsd No Pay, Clms Pd Bef Clsd Br, Suits Opn, Suits Out by Yr End, Clm Cnt Exp - Y,M,B, Salv Exps, Clms Settl, Clms Clsd, Clm Cnt Loss Arb Forum, Clm Cnt Exp - Y,B, Subro Recov Clms, Clms Out by Yr YTD Ser, Loss Clsd Clms, CountBranch, Subro Exps, Suits Clsd, Loss Clsd Clms Pd Bef Cls, Clms Out by Qrt, Clms Out by Yr, Clm Cnt Loss - Y,B, Clms Out by Yr YTD, Clms Pd Bef Clsd CW, Clsd Clms Cnt with Exp CW, Suits Out by Qrt, CountQrt, Salv Recv, Suits Out by Yr, Loss Clsd Clms Pd Aft Cls, Clms Out by Qrt Ser, Clms Out by Yr End, Suits Out by Yr YTD, CountMth, Loss, Subro Recv, Out Rsv by Qrt, Exps, Clm Cnt Loss, Clms Rpt, Out Rsv by Mth, Clms Out by Mth Ser, Clms Out by Yr Ser, Clsd Clms Cnt with Exp, Clms Pd after Clsd Br, Clms Pd after Clsd CW, Out Rsv by Yr, Clm Cnt Loss - Y,M,B, Exps Clsd Clms, Clms Out by Yr End Ser, Clsd Clms Cnt with Exp Br, 	FACT_TABLE	




select	[Year]@[CustCol_8],
	max([Year]@[CustCol_8]) as [Embedded metric:2084C7BD4500DB1C07D67B9A1C3AE053]
from	Overall Claims Report Cube
with Table Join Tree: 	[F_MAIN_INDEX]
having	[Year]@[CustCol_8] >=  ([Embedded metric:2084C7BD4500DB1C07D67B9A1C3AE053] - 1.0)
Save As TempTable48	





select	[Qrt]@[QUARTER],
	[Year]@[CustCol_8],
	[Mth]@[MONTH_NUMBER],
	[Mth]@[CustCol_44],
	sum([[F_MAIN_INDEX].Clms Out by Mth])@{[Mth],[Year]} as [Clms Out by Mth],
	sum([[F_MAIN_INDEX].Clms Out by Qrt])@{[Mth],[Year]} as [Clms Out by Qrt],
	sum([[F_MAIN_INDEX].Clms Out by Yr End])@{[Mth],[Year]} as [Clms Out by Yr End],
	sum([[F_MAIN_INDEX].Clms Out by Yr YTD])@{[Mth],[Year]} as [Clms Out by Yr YTD],
	IF([[F_MAIN_INDEX].CountMth] is null, 0, 1) as [CountMth],
	IF([[F_MAIN_INDEX].CountQrt] is null, 0, 1) as [CountQrt],
	sum([[F_MAIN_INDEX].Out Rsv by Mth])@{[Mth],[Year]} as [Out Rsv by Mth],
	sum([[F_MAIN_INDEX].Out Rsv by Qrt])@{[Mth],[Year]} as [Out Rsv by Qrt],
	sum([[F_MAIN_INDEX].Out Rsv by Yr End])@{[Mth],[Year]} as [Out Rsv by Yr End],
	sum([[F_MAIN_INDEX].Out Rsv by Yr YTD])@{[Mth],[Year]} as [Out Rsv by Yr YTD]
from	Overall Claims Report Cube
with Table Join Tree: 	[F_MAIN_INDEX]<([LOB]@[CustCol_71] in ('Auto     ')
 and [Current Yr/Mth]@[CustCol_122] > [Yr/Mth]@[MONTH_DATE])>
	 Join TempTable48 with output level Tuple([ADR Exists Ind]@[ADR_EXISTS_KEY], [Acct Cov Grp 1]@[ACCT_COV_GRP_1], [Acct Cov Grp 1 Detail]@[ACCT_COV_GRP_1_DETAIL], [Acct Cov Grp 2]@[ACCT_COV_GRP_2], [CAT Begin Dt]@[DATE], [CAT ID]@[CAT_GUIDEWIRE_NO_KEY], [CEA Indicator]@[EQ_KEY], [Claim Type]@[CLAIM_COV_CLAIM_TYPE], [ClaimCenter Ind]@[GUIDEWIRE_IND], [Common Branch]@[BRANCH_ID], [Company]@[COMPANY], [Cov]@[CLAIM_COV_SCREEN_CD], [Coverage Question Ind]@[COVERAGE_QUESTION_IND], [Covrg Cd]@[CLAIM_COVERAGE_CD], [Covrg Desc]@[CLAIM_COVERAGE], [Covrg Party Cd]@[CLAIM_COV_PARTY_CD], [Current Date]@[CustCol_82], [Detail Claim Type]@[CustCol_7], [Detail LOB]@[CLAIM_COV_DETAIL_LINE_OF_BUS], [Fatality]@[FATALITY], [File Prefix Cd]@[FILE_PREFIX_CD], [File Type]@[CustCol_141], [IA First Assign Ind]@[Y_N], [LOB]@[CustCol_71], [Loss State]@[CustCol_168], [Mth]@[MONTH_NUMBER], [Oper Claim Type]@[OPER_CLAIM_TYPE], [Policy State]@[STATE_KEY], [Qrt]@[QUARTER], [State]@[STATE_ID], [Sub Peril]@[GW_SUB_PERIL_NAME], [Suit Exists Ind]@[SUIT_EXISTS_KEY], [TotalLoss Cd]@[D_Total_loss_ind], [Year]@[CustCol_8], [Yr/Mth]@[MONTH_DATE], [Yr/Qrt]@[QUARTER_KEY])

[Analytical engine calculation steps:
	1.  Calculate metric: <Clms Out>
	2.  Calculate metric: <Avg Rsv>
	3.  Calculate metric limit(s)
	4.  Perform cross-tabbing
]
